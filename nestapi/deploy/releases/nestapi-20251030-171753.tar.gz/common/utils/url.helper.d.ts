import { ConfigService } from '@nestjs/config';
export declare class UrlHelper {
    private configService;
    private customDomain;
    private cosHost;
    constructor(configService: ConfigService);
    private initializeConfig;
    generateUrl(fileKey: string): string;
    generateUrls(fileKeys: string[]): string[];
    extractKeyFromUrl(url: string): string;
    getAccessDomain(): string;
}
