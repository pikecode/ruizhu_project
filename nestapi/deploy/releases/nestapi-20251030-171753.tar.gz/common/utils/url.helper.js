"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UrlHelper = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
let UrlHelper = class UrlHelper {
    configService;
    customDomain;
    cosHost;
    constructor(configService) {
        this.configService = configService;
        this.initializeConfig();
    }
    initializeConfig() {
        const bucket = this.configService.get('COS_BUCKET', 'ruizhu-1256655507');
        const region = this.configService.get('COS_REGION', 'ap-guangzhou');
        this.customDomain = this.configService.get('COS_CUSTOM_DOMAIN') || null;
        this.cosHost = `https://${bucket}.cos.${region}.myqcloud.com`;
    }
    generateUrl(fileKey) {
        if (!fileKey) {
            return '';
        }
        const normalizedKey = fileKey.startsWith('/') ? fileKey.substring(1) : fileKey;
        if (this.customDomain) {
            return `${this.customDomain}/${normalizedKey}`;
        }
        return `${this.cosHost}/${normalizedKey}`;
    }
    generateUrls(fileKeys) {
        return fileKeys.map(key => this.generateUrl(key));
    }
    extractKeyFromUrl(url) {
        if (!url) {
            return '';
        }
        if (this.customDomain && url.includes(this.customDomain)) {
            const domain = this.customDomain.replace(/https?:\/\//, '');
            return url.split(domain)[1]?.substring(1) || '';
        }
        else if (url.includes(this.cosHost)) {
            return url.substring(this.cosHost.length + 1);
        }
        return url;
    }
    getAccessDomain() {
        return this.customDomain || this.cosHost;
    }
};
exports.UrlHelper = UrlHelper;
exports.UrlHelper = UrlHelper = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], UrlHelper);
//# sourceMappingURL=url.helper.js.map