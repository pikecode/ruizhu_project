"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CosService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const COS = require('cos-nodejs-sdk-v5');
let CosService = class CosService {
    configService;
    cos;
    bucket;
    region;
    cosHost;
    customDomain;
    constructor(configService) {
        this.configService = configService;
        this.initializeCOS();
    }
    initializeCOS() {
        const secretId = this.configService.get('COS_SECRET_ID');
        const secretKey = this.configService.get('COS_SECRET_KEY');
        this.bucket = this.configService.get('COS_BUCKET', 'ruizhu-1256655507');
        this.region = this.configService.get('COS_REGION', 'ap-guangzhou');
        this.customDomain = this.configService.get('COS_CUSTOM_DOMAIN') || null;
        this.cosHost = `https://${this.bucket}.cos.${this.region}.myqcloud.com`;
        if (!secretId || !secretKey) {
            console.warn('COS credentials not configured');
            return;
        }
        this.cos = new COS({
            SecretId: secretId,
            SecretKey: secretKey,
        });
    }
    async uploadFile(buffer, originalname, folder = 'products') {
        if (!buffer) {
            throw new common_1.BadRequestException('No file buffer provided');
        }
        try {
            const timestamp = Date.now();
            const randomStr = Math.random().toString(36).substring(7);
            const ext = this.getFileExtension(originalname);
            const fileName = `${timestamp}-${randomStr}${ext}`;
            const fileKey = `${folder}/${fileName}`;
            if (this.cos) {
                await this.uploadFileToCOS(fileKey, buffer, this.getMimeType(originalname));
            }
            return {
                key: fileKey,
                size: buffer.length,
                domain: this.customDomain || this.cosHost,
            };
        }
        catch (error) {
            console.error('COS upload error:', error);
            throw new common_1.BadRequestException(`Failed to upload file to COS: ${error.message}`);
        }
    }
    async deleteFile(urlOrKey) {
        if (!urlOrKey) {
            console.warn('No file URL or key provided for deletion');
            return;
        }
        try {
            const fileKey = this.extractKeyFromUrl(urlOrKey);
            if (this.cos) {
                await this.deleteFileFromCOS(fileKey);
            }
            console.log(`File deleted successfully: ${fileKey}`);
        }
        catch (error) {
            console.error('Delete file error:', error);
        }
    }
    generateUrl(fileKey) {
        if (this.customDomain) {
            return `${this.customDomain}/${fileKey}`;
        }
        return `${this.cosHost}/${fileKey}`;
    }
    getAccessDomain() {
        return this.customDomain || this.cosHost;
    }
    extractKeyFromUrl(urlOrKey) {
        if (urlOrKey.startsWith('http')) {
            if (urlOrKey.includes(this.cosHost)) {
                return urlOrKey.substring(this.cosHost.length + 1);
            }
            else if (this.customDomain && urlOrKey.includes(this.customDomain)) {
                return urlOrKey.substring(this.customDomain.length + 1);
            }
        }
        return urlOrKey;
    }
    uploadFileToCOS(key, body, contentType) {
        return new Promise((resolve, reject) => {
            this.cos.putObject({
                Bucket: this.bucket,
                Region: this.region,
                Key: key,
                Body: body,
                ContentType: contentType,
                onProgress: (progressData) => {
                    console.log(`[COS Upload] ${key}: ${Math.round(progressData.percent * 100)}%`);
                },
            }, (err, data) => {
                if (err) {
                    reject(err);
                }
                else {
                    console.log(`[COS Upload Success] ${key} - Location: ${data.Location}`);
                    resolve();
                }
            });
        });
    }
    deleteFileFromCOS(key) {
        return new Promise((resolve, reject) => {
            this.cos.deleteObject({
                Bucket: this.bucket,
                Region: this.region,
                Key: key,
            }, (err, data) => {
                if (err) {
                    reject(err);
                }
                else {
                    console.log(`[COS Delete Success] ${key}`);
                    resolve();
                }
            });
        });
    }
    getMimeType(filename) {
        const ext = filename.toLowerCase().split('.').pop() || '';
        const mimeTypes = {
            jpg: 'image/jpeg',
            jpeg: 'image/jpeg',
            png: 'image/png',
            gif: 'image/gif',
            webp: 'image/webp',
            svg: 'image/svg+xml',
            mp4: 'video/mp4',
            webm: 'video/webm',
            mov: 'video/quicktime',
            avi: 'video/x-msvideo',
            mpeg: 'video/mpeg',
            pdf: 'application/pdf',
            zip: 'application/zip',
        };
        return mimeTypes[ext] || 'application/octet-stream';
    }
    getFileExtension(filename) {
        const lastDot = filename.lastIndexOf('.');
        if (lastDot === -1) {
            return '';
        }
        return filename.substring(lastDot);
    }
};
exports.CosService = CosService;
exports.CosService = CosService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService])
], CosService);
//# sourceMappingURL=cos.service.js.map