import { ConfigService } from '@nestjs/config';
export interface CosUploadResult {
    key: string;
    size: number;
    domain?: string;
}
export declare class CosService {
    private configService;
    private cos;
    private bucket;
    private region;
    private cosHost;
    private customDomain;
    constructor(configService: ConfigService);
    private initializeCOS;
    uploadFile(buffer: Buffer, originalname: string, folder?: string): Promise<CosUploadResult>;
    deleteFile(urlOrKey: string): Promise<void>;
    generateUrl(fileKey: string): string;
    getAccessDomain(): string;
    private extractKeyFromUrl;
    private uploadFileToCOS;
    private deleteFileFromCOS;
    private getMimeType;
    private getFileExtension;
}
