export declare class AppModule {
}
