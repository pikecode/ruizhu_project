"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDatabaseConfig = void 0;
const product_entity_1 = require("../entities/product.entity");
const category_entity_1 = require("../entities/category.entity");
const collection_entity_1 = require("../entities/collection.entity");
const collection_product_entity_1 = require("../entities/collection-product.entity");
const array_collection_entity_1 = require("../entities/array-collection.entity");
const array_collection_item_entity_1 = require("../entities/array-collection-item.entity");
const array_collection_item_product_entity_1 = require("../entities/array-collection-item-product.entity");
const banner_entity_1 = require("../entities/banner.entity");
const user_entity_1 = require("../entities/user.entity");
const getDatabaseConfig = () => {
    const dbHost = process.env.DB_HOST;
    const dbPort = parseInt(process.env.DB_PORT || '3306', 10);
    const dbUsername = process.env.DB_USER;
    const dbPassword = process.env.DB_PASSWORD;
    const dbDatabase = process.env.DB_NAME;
    const nodeEnv = process.env.NODE_ENV || 'development';
    if (!dbHost || !dbUsername || !dbPassword || !dbDatabase) {
        console.error('❌ 缺少必需的数据库环境变量');
        console.error('   需要: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME');
        throw new Error('缺少必需的数据库环境变量: DB_HOST, DB_USER, DB_PASSWORD, DB_NAME');
    }
    const isTencentCloud = dbHost.includes('tencentcdb.com');
    console.log('');
    console.log('═══════════════════════════════════════════════════');
    console.log('  数据库连接配置');
    console.log('═══════════════════════════════════════════════════');
    console.log(`  主机: ${dbHost}`);
    console.log(`  端口: ${dbPort}`);
    console.log(`  用户: ${dbUsername}`);
    console.log(`  数据库: ${dbDatabase}`);
    console.log(`  环境: ${nodeEnv}`);
    if (isTencentCloud) {
        console.log('  类型: 腾讯云 CDB MySQL ✓');
    }
    console.log('═══════════════════════════════════════════════════');
    console.log('');
    const config = {
        type: 'mysql',
        host: dbHost,
        port: dbPort,
        username: dbUsername,
        password: dbPassword,
        database: dbDatabase,
        entities: [
            user_entity_1.User,
            category_entity_1.Category,
            product_entity_1.Product,
            product_entity_1.ProductImage,
            product_entity_1.ProductAttribute,
            product_entity_1.ProductDetails,
            product_entity_1.ProductTag,
            product_entity_1.ProductReview,
            product_entity_1.CartItem,
            product_entity_1.Order,
            product_entity_1.OrderItem,
            product_entity_1.OrderRefund,
            collection_entity_1.Collection,
            collection_product_entity_1.CollectionProduct,
            array_collection_entity_1.ArrayCollection,
            array_collection_item_entity_1.ArrayCollectionItem,
            array_collection_item_product_entity_1.ArrayCollectionItemProduct,
            banner_entity_1.Banner,
        ],
        synchronize: false,
        logging: nodeEnv === 'development' ? ['query', 'error'] : ['error'],
        logger: 'advanced-console',
        poolSize: 10,
        maxQueryExecutionTime: 60000,
        extra: {
            connectionLimit: 20,
            waitForConnections: true,
            enableExitEvent: true,
            ...(isTencentCloud && {
                charset: 'utf8mb4',
                enableKeepAlive: true,
                keepAliveInitialDelaySeconds: 0,
            }),
            connectTimeout: 20000,
            acquireTimeout: 30000,
            idleTimeout: 300000,
            reapIntervalMillis: 5000,
        },
        ssl: false,
    };
    return config;
};
exports.getDatabaseConfig = getDatabaseConfig;
//# sourceMappingURL=database.config.js.map