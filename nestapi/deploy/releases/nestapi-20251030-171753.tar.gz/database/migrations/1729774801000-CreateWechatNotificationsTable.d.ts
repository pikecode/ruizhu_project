import { MigrationInterface, QueryRunner } from 'typeorm';
export declare class CreateWechatNotificationsTable1729774801000 implements MigrationInterface {
    up(queryRunner: QueryRunner): Promise<void>;
    down(queryRunner: QueryRunner): Promise<void>;
}
