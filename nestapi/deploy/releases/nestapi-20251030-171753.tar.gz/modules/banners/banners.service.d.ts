import { Repository } from 'typeorm';
import { Banner } from '../../entities/banner.entity';
import { CreateBannerDto, UpdateBannerDto, BannerResponseDto, BannerListResponseDto } from './dto/banner.dto';
import { ConfigService } from '@nestjs/config';
import { MediaService } from '../media/media.service';
import { UrlHelper } from '../../common/utils/url.helper';
export declare class BannersService {
    private bannerRepository;
    private configService;
    private mediaService;
    private urlHelper;
    constructor(bannerRepository: Repository<Banner>, configService: ConfigService, mediaService: MediaService, urlHelper: UrlHelper);
    getBannerList(page?: number, limit?: number, onlyActive?: boolean, pageType?: 'home' | 'custom'): Promise<BannerListResponseDto>;
    getBannerById(id: number): Promise<BannerResponseDto>;
    getHomeBanners(pageType?: 'home' | 'custom'): Promise<BannerResponseDto[]>;
    createBanner(createBannerDto: CreateBannerDto): Promise<BannerResponseDto>;
    updateBanner(id: number, updateBannerDto: UpdateBannerDto): Promise<BannerResponseDto>;
    deleteBanner(id: number): Promise<void>;
    uploadImage(bannerId: number, file: Express.Multer.File): Promise<BannerResponseDto>;
    uploadVideo(bannerId: number, file: Express.Multer.File): Promise<BannerResponseDto>;
    private convertVideoToWebp;
    private extractVideoThumbnail;
    private cleanupTempDir;
    private mapToResponseDto;
}
