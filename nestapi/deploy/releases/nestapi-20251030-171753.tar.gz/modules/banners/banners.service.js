"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BannersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const banner_entity_1 = require("../../entities/banner.entity");
const config_1 = require("@nestjs/config");
const media_service_1 = require("../media/media.service");
const url_helper_1 = require("../../common/utils/url.helper");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let BannersService = class BannersService {
    bannerRepository;
    configService;
    mediaService;
    urlHelper;
    constructor(bannerRepository, configService, mediaService, urlHelper) {
        this.bannerRepository = bannerRepository;
        this.configService = configService;
        this.mediaService = mediaService;
        this.urlHelper = urlHelper;
    }
    async getBannerList(page = 1, limit = 10, onlyActive = false, pageType = 'home') {
        const skip = (page - 1) * limit;
        let query = this.bannerRepository.createQueryBuilder('banner');
        query = query.where('banner.pageType = :pageType', { pageType });
        if (onlyActive) {
            query = query.andWhere('banner.isActive = :isActive', { isActive: true });
        }
        const [items, total] = await query
            .orderBy('banner.sortOrder', 'ASC')
            .addOrderBy('banner.createdAt', 'DESC')
            .skip(skip)
            .take(limit)
            .getManyAndCount();
        const pages = Math.ceil(total / limit);
        return {
            items: items.map(item => this.mapToResponseDto(item)),
            total,
            page,
            limit,
            pages,
        };
    }
    async getBannerById(id) {
        const banner = await this.bannerRepository.findOne({ where: { id } });
        if (!banner) {
            throw new common_1.NotFoundException(`Banner with ID ${id} not found`);
        }
        return this.mapToResponseDto(banner);
    }
    async getHomeBanners(pageType = 'home') {
        const banners = await this.bannerRepository.find({
            where: { isActive: true, pageType },
            order: {
                sortOrder: 'ASC',
                createdAt: 'DESC',
            },
        });
        return banners.map(item => this.mapToResponseDto(item));
    }
    async createBanner(createBannerDto) {
        const banner = this.bannerRepository.create(createBannerDto);
        const savedBanner = await this.bannerRepository.save(banner);
        return this.mapToResponseDto(savedBanner);
    }
    async updateBanner(id, updateBannerDto) {
        const banner = await this.bannerRepository.findOne({ where: { id } });
        if (!banner) {
            throw new common_1.NotFoundException(`Banner with ID ${id} not found`);
        }
        Object.assign(banner, updateBannerDto);
        const updatedBanner = await this.bannerRepository.save(banner);
        return this.mapToResponseDto(updatedBanner);
    }
    async deleteBanner(id) {
        const banner = await this.bannerRepository.findOne({ where: { id } });
        if (!banner) {
            throw new common_1.NotFoundException(`Banner with ID ${id} not found`);
        }
        if (banner.imageUrl) {
            await this.mediaService.deleteMedia(banner.imageUrl);
        }
        if (banner.videoUrl) {
            await this.mediaService.deleteMedia(banner.videoUrl);
        }
        if (banner.videoThumbnailUrl) {
            await this.mediaService.deleteMedia(banner.videoThumbnailUrl);
        }
        await this.bannerRepository.remove(banner);
    }
    async uploadImage(bannerId, file) {
        const banner = await this.bannerRepository.findOne({ where: { id: bannerId } });
        if (!banner) {
            throw new common_1.NotFoundException(`Banner with ID ${bannerId} not found`);
        }
        const allowedMimeTypes = ['image/jpeg', 'image/png', 'image/webp'];
        if (!allowedMimeTypes.includes(file.mimetype)) {
            throw new common_1.BadRequestException('Only JPEG, PNG, and WebP images are allowed');
        }
        if (banner.imageKey) {
            await this.mediaService.deleteMedia(banner.imageKey);
        }
        const result = await this.mediaService.uploadMedia(file, 'image');
        banner.imageKey = result.key;
        banner.imageUrl = null;
        banner.type = 'image';
        const updatedBanner = await this.bannerRepository.save(banner);
        return this.mapToResponseDto(updatedBanner);
    }
    async uploadVideo(bannerId, file) {
        const banner = await this.bannerRepository.findOne({ where: { id: bannerId } });
        if (!banner) {
            throw new common_1.NotFoundException(`Banner with ID ${bannerId} not found`);
        }
        const allowedMimeTypes = ['video/mp4', 'video/quicktime', 'video/x-msvideo', 'video/mpeg'];
        if (!allowedMimeTypes.includes(file.mimetype)) {
            throw new common_1.BadRequestException('Only MP4, MOV, AVI, and MPEG videos are allowed');
        }
        if (banner.videoUrl) {
            await this.mediaService.deleteMedia(banner.videoUrl);
        }
        if (banner.videoThumbnailUrl) {
            await this.mediaService.deleteMedia(banner.videoThumbnailUrl);
        }
        const tempDir = path.join('/tmp', `banner-${bannerId}-${Date.now()}`);
        fs.mkdirSync(tempDir, { recursive: true });
        try {
            const originalPath = path.join(tempDir, `original${path.extname(file.originalname)}`);
            fs.writeFileSync(originalPath, file.buffer);
            const webmPath = path.join(tempDir, 'video.webm');
            await this.convertVideoToWebp(originalPath, webmPath);
            const thumbnailPath = path.join(tempDir, 'thumbnail.jpg');
            await this.extractVideoThumbnail(originalPath, thumbnailPath);
            const webmBuffer = fs.readFileSync(webmPath);
            const thumbnailBuffer = fs.readFileSync(thumbnailPath);
            const webmFile = {
                fieldname: 'video',
                originalname: 'video.webm',
                encoding: '7bit',
                mimetype: 'video/webm',
                size: webmBuffer.length,
                destination: tempDir,
                filename: 'video.webm',
                path: webmPath,
                buffer: webmBuffer,
            };
            const videoResult = await this.mediaService.uploadMedia(webmFile, 'video');
            const thumbnailFile = {
                fieldname: 'thumbnail',
                originalname: 'thumbnail.jpg',
                encoding: '7bit',
                mimetype: 'image/jpeg',
                size: thumbnailBuffer.length,
                destination: tempDir,
                filename: 'thumbnail.jpg',
                path: thumbnailPath,
                buffer: thumbnailBuffer,
            };
            const thumbnailResult = await this.mediaService.uploadMedia(thumbnailFile, 'image');
            banner.videoKey = videoResult.key;
            banner.videoUrl = null;
            banner.videoThumbnailKey = thumbnailResult.key;
            banner.videoThumbnailUrl = null;
            banner.type = 'video';
            const updatedBanner = await this.bannerRepository.save(banner);
            return this.mapToResponseDto(updatedBanner);
        }
        finally {
            this.cleanupTempDir(tempDir);
        }
    }
    async convertVideoToWebp(inputPath, outputPath) {
        const { exec } = require('child_process');
        const { promisify } = require('util');
        const execAsync = promisify(exec);
        try {
            const webmPath = outputPath.replace(/\.webp$/, '.webm');
            await execAsync(`ffmpeg -i "${inputPath}" -c:v libvpx-vp9 -crf 28 -b:v 0 -c:a libopus -b:a 128k "${webmPath}"`);
        }
        catch (error) {
            throw new common_1.BadRequestException(`Failed to convert video to WebM format. Make sure FFmpeg is installed. Error: ${error.message}`);
        }
    }
    async extractVideoThumbnail(videoPath, outputPath) {
        const { exec } = require('child_process');
        const { promisify } = require('util');
        const execAsync = promisify(exec);
        try {
            await execAsync(`ffmpeg -i "${videoPath}" -ss 2 -vframes 1 -q:v 2 "${outputPath}"`);
        }
        catch (error) {
            throw new common_1.BadRequestException(`Failed to extract video thumbnail. Error: ${error.message}`);
        }
    }
    cleanupTempDir(tempDir) {
        try {
            if (fs.existsSync(tempDir)) {
                fs.rmSync(tempDir, { recursive: true, force: true });
            }
        }
        catch (error) {
            console.error(`Failed to cleanup temp directory: ${tempDir}`, error);
        }
    }
    mapToResponseDto(banner) {
        return {
            id: banner.id,
            mainTitle: banner.mainTitle,
            subtitle: banner.subtitle,
            description: banner.description,
            type: banner.type,
            imageUrl: banner.imageKey ? this.urlHelper.generateUrl(banner.imageKey) : banner.imageUrl,
            videoUrl: banner.videoKey ? this.urlHelper.generateUrl(banner.videoKey) : banner.videoUrl,
            videoThumbnailUrl: banner.videoThumbnailKey
                ? this.urlHelper.generateUrl(banner.videoThumbnailKey)
                : banner.videoThumbnailUrl,
            pageType: banner.pageType,
            isActive: banner.isActive,
            sortOrder: banner.sortOrder,
            linkType: banner.linkType,
            linkValue: banner.linkValue,
            createdAt: banner.createdAt,
            updatedAt: banner.updatedAt,
        };
    }
};
exports.BannersService = BannersService;
exports.BannersService = BannersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(banner_entity_1.Banner)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService,
        media_service_1.MediaService,
        url_helper_1.UrlHelper])
], BannersService);
//# sourceMappingURL=banners.service.js.map