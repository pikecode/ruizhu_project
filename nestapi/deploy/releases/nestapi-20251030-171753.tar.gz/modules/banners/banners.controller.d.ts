import { BannersService } from './banners.service';
import { CreateBannerDto, UpdateBannerDto, BannerResponseDto, BannerListResponseDto } from './dto/banner.dto';
export declare class BannersController {
    private bannersService;
    constructor(bannersService: BannersService);
    getBannerList(page?: number, limit?: number, pageType?: 'home' | 'custom'): Promise<{
        code: number;
        message: string;
        data: BannerListResponseDto;
    }>;
    getHomeBanners(pageType?: 'home' | 'custom'): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto[];
    }>;
    getBannerById(id: number): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto;
    }>;
    createBanner(createBannerDto: CreateBannerDto): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto;
    }>;
    updateBanner(id: number, updateBannerDto: UpdateBannerDto): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto;
    }>;
    deleteBanner(id: number): Promise<{
        code: number;
        message: string;
    }>;
    uploadImage(id: number, file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto;
    }>;
    uploadVideo(id: number, file: Express.Multer.File): Promise<{
        code: number;
        message: string;
        data: BannerResponseDto;
    }>;
}
