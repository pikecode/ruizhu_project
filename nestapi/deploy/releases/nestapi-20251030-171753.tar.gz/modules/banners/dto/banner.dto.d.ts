export declare class CreateBannerDto {
    mainTitle: string;
    subtitle?: string;
    description?: string;
    type?: 'image' | 'video';
    pageType?: 'home' | 'custom';
    sortOrder?: number;
    isActive?: boolean;
    linkType?: 'none' | 'product' | 'category' | 'collection' | 'url';
    linkValue?: string;
}
export declare class UpdateBannerDto {
    mainTitle?: string;
    subtitle?: string | null;
    description?: string | null;
    type?: 'image' | 'video';
    pageType?: 'home' | 'custom';
    sortOrder?: number;
    isActive?: boolean;
    linkType?: 'none' | 'product' | 'category' | 'collection' | 'url';
    linkValue?: string | null;
}
export declare class UploadBannerMediaDto {
    type: 'image' | 'video';
}
export declare class BannerResponseDto {
    id: number;
    mainTitle: string;
    subtitle?: string | null;
    description?: string | null;
    type: 'image' | 'video';
    imageUrl?: string | null;
    videoUrl?: string | null;
    videoThumbnailUrl?: string | null;
    pageType: 'home' | 'custom';
    isActive: boolean;
    sortOrder: number;
    linkType: 'none' | 'product' | 'category' | 'collection' | 'url';
    linkValue?: string | null;
    createdAt: Date;
    updatedAt: Date;
}
export declare class BannerListResponseDto {
    items: BannerResponseDto[];
    total: number;
    page: number;
    limit: number;
    pages: number;
}
