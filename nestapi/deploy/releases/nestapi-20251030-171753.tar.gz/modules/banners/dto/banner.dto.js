"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BannerListResponseDto = exports.BannerResponseDto = exports.UploadBannerMediaDto = exports.UpdateBannerDto = exports.CreateBannerDto = void 0;
const class_validator_1 = require("class-validator");
class CreateBannerDto {
    mainTitle;
    subtitle;
    description;
    type;
    pageType;
    sortOrder;
    isActive;
    linkType;
    linkValue;
}
exports.CreateBannerDto = CreateBannerDto;
__decorate([
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "mainTitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "subtitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['image', 'video']),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['home', 'custom']),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "pageType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateBannerDto.prototype, "sortOrder", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateBannerDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['none', 'product', 'category', 'collection', 'url']),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "linkType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateBannerDto.prototype, "linkValue", void 0);
class UpdateBannerDto {
    mainTitle;
    subtitle;
    description;
    type;
    pageType;
    sortOrder;
    isActive;
    linkType;
    linkValue;
}
exports.UpdateBannerDto = UpdateBannerDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateBannerDto.prototype, "mainTitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateBannerDto.prototype, "subtitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateBannerDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['image', 'video']),
    __metadata("design:type", String)
], UpdateBannerDto.prototype, "type", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['home', 'custom']),
    __metadata("design:type", String)
], UpdateBannerDto.prototype, "pageType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateBannerDto.prototype, "sortOrder", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateBannerDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsEnum)(['none', 'product', 'category', 'collection', 'url']),
    __metadata("design:type", String)
], UpdateBannerDto.prototype, "linkType", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", Object)
], UpdateBannerDto.prototype, "linkValue", void 0);
class UploadBannerMediaDto {
    type;
}
exports.UploadBannerMediaDto = UploadBannerMediaDto;
__decorate([
    (0, class_validator_1.IsEnum)(['image', 'video']),
    __metadata("design:type", String)
], UploadBannerMediaDto.prototype, "type", void 0);
class BannerResponseDto {
    id;
    mainTitle;
    subtitle;
    description;
    type;
    imageUrl;
    videoUrl;
    videoThumbnailUrl;
    pageType;
    isActive;
    sortOrder;
    linkType;
    linkValue;
    createdAt;
    updatedAt;
}
exports.BannerResponseDto = BannerResponseDto;
class BannerListResponseDto {
    items;
    total;
    page;
    limit;
    pages;
}
exports.BannerListResponseDto = BannerListResponseDto;
//# sourceMappingURL=banner.dto.js.map