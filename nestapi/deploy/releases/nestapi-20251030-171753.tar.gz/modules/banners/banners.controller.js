"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BannersController = void 0;
const common_1 = require("@nestjs/common");
const platform_express_1 = require("@nestjs/platform-express");
const swagger_1 = require("@nestjs/swagger");
const banners_service_1 = require("./banners.service");
const banner_dto_1 = require("./dto/banner.dto");
let BannersController = class BannersController {
    bannersService;
    constructor(bannersService) {
        this.bannersService = bannersService;
    }
    async getBannerList(page = 1, limit = 10, pageType = 'home') {
        const data = await this.bannersService.getBannerList(page, limit, false, pageType);
        return {
            code: 200,
            message: 'Successfully retrieved banner list',
            data,
        };
    }
    async getHomeBanners(pageType = 'home') {
        const data = await this.bannersService.getHomeBanners(pageType);
        return {
            code: 200,
            message: 'Successfully retrieved home banners',
            data,
        };
    }
    async getBannerById(id) {
        const data = await this.bannersService.getBannerById(id);
        return {
            code: 200,
            message: 'Successfully retrieved banner',
            data,
        };
    }
    async createBanner(createBannerDto) {
        const data = await this.bannersService.createBanner(createBannerDto);
        return {
            code: 201,
            message: 'Banner created successfully',
            data,
        };
    }
    async updateBanner(id, updateBannerDto) {
        const data = await this.bannersService.updateBanner(id, updateBannerDto);
        return {
            code: 200,
            message: 'Banner updated successfully',
            data,
        };
    }
    async deleteBanner(id) {
        await this.bannersService.deleteBanner(id);
        return {
            code: 200,
            message: 'Banner deleted successfully',
        };
    }
    async uploadImage(id, file) {
        const data = await this.bannersService.uploadImage(id, file);
        return {
            code: 200,
            message: 'Image uploaded successfully',
            data,
        };
    }
    async uploadVideo(id, file) {
        const data = await this.bannersService.uploadVideo(id, file);
        return {
            code: 200,
            message: 'Video uploaded and converted to WebP successfully',
            data,
        };
    }
};
exports.BannersController = BannersController;
__decorate([
    (0, common_1.Get)(),
    (0, swagger_1.ApiOperation)({ summary: 'Get banners list with pagination' }),
    (0, swagger_1.ApiQuery)({ name: 'page', required: false, type: Number, description: 'Page number' }),
    (0, swagger_1.ApiQuery)({ name: 'limit', required: false, type: Number, description: 'Items per page' }),
    (0, swagger_1.ApiQuery)({ name: 'pageType', required: false, enum: ['home', 'custom'], description: 'Banner page type' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully retrieved banner list' }),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __param(2, (0, common_1.Query)('pageType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number, String]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "getBannerList", null);
__decorate([
    (0, common_1.Get)('home'),
    (0, swagger_1.ApiOperation)({ summary: 'Get home banners (active only)' }),
    (0, swagger_1.ApiQuery)({ name: 'pageType', required: false, enum: ['home', 'custom'], description: 'Banner page type' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully retrieved home banners' }),
    __param(0, (0, common_1.Query)('pageType')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "getHomeBanners", null);
__decorate([
    (0, common_1.Get)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Get banner by ID' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, description: 'Banner ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Successfully retrieved banner' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "getBannerById", null);
__decorate([
    (0, common_1.Post)(),
    (0, swagger_1.ApiOperation)({ summary: 'Create a new banner' }),
    (0, swagger_1.ApiResponse)({ status: 201, description: 'Banner created successfully' }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [banner_dto_1.CreateBannerDto]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "createBanner", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Update banner' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, description: 'Banner ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Banner updated successfully' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, banner_dto_1.UpdateBannerDto]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "updateBanner", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, swagger_1.ApiOperation)({ summary: 'Delete banner' }),
    (0, swagger_1.ApiParam)({ name: 'id', type: Number, description: 'Banner ID' }),
    (0, swagger_1.ApiResponse)({ status: 200, description: 'Banner deleted successfully' }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "deleteBanner", null);
__decorate([
    (0, common_1.Post)(':id/upload-image'),
    (0, common_1.HttpCode)(200),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "uploadImage", null);
__decorate([
    (0, common_1.Post)(':id/upload-video'),
    (0, common_1.HttpCode)(200),
    (0, common_1.UseInterceptors)((0, platform_express_1.FileInterceptor)('file')),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __param(1, (0, common_1.UploadedFile)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Object]),
    __metadata("design:returntype", Promise)
], BannersController.prototype, "uploadVideo", null);
exports.BannersController = BannersController = __decorate([
    (0, swagger_1.ApiTags)('Banners'),
    (0, common_1.Controller)('banners'),
    __metadata("design:paramtypes", [banners_service_1.BannersService])
], BannersController);
//# sourceMappingURL=banners.controller.js.map