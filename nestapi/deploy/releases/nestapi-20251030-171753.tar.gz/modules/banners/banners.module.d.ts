export declare class BannersModule {
}
