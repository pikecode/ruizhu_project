import { ArrayCollectionsService } from './array-collections.service';
import { CreateArrayCollectionDto } from './dto/create-array-collection.dto';
import { UpdateArrayCollectionDto } from './dto/update-array-collection.dto';
import { CreateItemDto } from './dto/create-item.dto';
import { AddProductsToItemDto, RemoveProductsFromItemDto, UpdateItemProductsSortDto } from './dto/manage-products.dto';
export declare class ArrayCollectionsController {
    private readonly service;
    constructor(service: ArrayCollectionsService);
    createArrayCollection(createDto: CreateArrayCollectionDto): Promise<import("../../entities/array-collection.entity").ArrayCollection>;
    getArrayCollectionsList(page?: number, limit?: number): Promise<import("./dto/array-collection-response.dto").ArrayCollectionListResponseDto>;
    getArrayCollectionDetail(id: number): Promise<import("./dto/array-collection-response.dto").ArrayCollectionDetailResponseDto>;
    updateArrayCollection(id: number, updateDto: UpdateArrayCollectionDto): Promise<import("../../entities/array-collection.entity").ArrayCollection>;
    deleteArrayCollection(id: number): Promise<void>;
    createItem(arrayCollectionId: number, createDto: CreateItemDto): Promise<import("../../entities/array-collection-item.entity").ArrayCollectionItem>;
    updateItem(itemId: number, updateDto: CreateItemDto): Promise<import("../../entities/array-collection-item.entity").ArrayCollectionItem>;
    deleteItem(itemId: number): Promise<void>;
    addProductsToItem(itemId: number, addDto: AddProductsToItemDto): Promise<{
        message: string;
    }>;
    removeProductsFromItem(itemId: number, removeDto: RemoveProductsFromItemDto): Promise<void>;
    updateItemProductsSort(itemId: number, updateDto: UpdateItemProductsSortDto): Promise<{
        message: string;
    }>;
}
