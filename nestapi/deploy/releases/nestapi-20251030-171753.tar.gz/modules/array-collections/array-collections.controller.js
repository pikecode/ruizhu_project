"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArrayCollectionsController = void 0;
const common_1 = require("@nestjs/common");
const array_collections_service_1 = require("./array-collections.service");
const create_array_collection_dto_1 = require("./dto/create-array-collection.dto");
const update_array_collection_dto_1 = require("./dto/update-array-collection.dto");
const create_item_dto_1 = require("./dto/create-item.dto");
const manage_products_dto_1 = require("./dto/manage-products.dto");
let ArrayCollectionsController = class ArrayCollectionsController {
    service;
    constructor(service) {
        this.service = service;
    }
    async createArrayCollection(createDto) {
        return await this.service.createArrayCollection(createDto);
    }
    async getArrayCollectionsList(page, limit) {
        return await this.service.getArrayCollectionsList(page, limit);
    }
    async getArrayCollectionDetail(id) {
        return await this.service.getArrayCollectionDetail(id);
    }
    async updateArrayCollection(id, updateDto) {
        return await this.service.updateArrayCollection(id, updateDto);
    }
    async deleteArrayCollection(id) {
        await this.service.deleteArrayCollection(id);
    }
    async createItem(arrayCollectionId, createDto) {
        return await this.service.createItem(arrayCollectionId, createDto);
    }
    async updateItem(itemId, updateDto) {
        return await this.service.updateItem(itemId, updateDto);
    }
    async deleteItem(itemId) {
        await this.service.deleteItem(itemId);
    }
    async addProductsToItem(itemId, addDto) {
        await this.service.addProductsToItem(itemId, addDto);
        return { message: '商品已添加' };
    }
    async removeProductsFromItem(itemId, removeDto) {
        await this.service.removeProductsFromItem(itemId, removeDto);
    }
    async updateItemProductsSort(itemId, updateDto) {
        await this.service.updateItemProductsSort(itemId, updateDto);
        return { message: '排序已更新' };
    }
};
exports.ArrayCollectionsController = ArrayCollectionsController;
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_array_collection_dto_1.CreateArrayCollectionDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "createArrayCollection", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "getArrayCollectionsList", null);
__decorate([
    (0, common_1.Get)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "getArrayCollectionDetail", null);
__decorate([
    (0, common_1.Put)(':id'),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, update_array_collection_dto_1.UpdateArrayCollectionDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "updateArrayCollection", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "deleteArrayCollection", null);
__decorate([
    (0, common_1.Post)(':arrayCollectionId/items'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Param)('arrayCollectionId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, create_item_dto_1.CreateItemDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "createItem", null);
__decorate([
    (0, common_1.Put)('items/:itemId'),
    __param(0, (0, common_1.Param)('itemId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, create_item_dto_1.CreateItemDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "updateItem", null);
__decorate([
    (0, common_1.Delete)('items/:itemId'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    __param(0, (0, common_1.Param)('itemId')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "deleteItem", null);
__decorate([
    (0, common_1.Post)('items/:itemId/products'),
    (0, common_1.HttpCode)(common_1.HttpStatus.CREATED),
    __param(0, (0, common_1.Param)('itemId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, manage_products_dto_1.AddProductsToItemDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "addProductsToItem", null);
__decorate([
    (0, common_1.Delete)('items/:itemId/products'),
    (0, common_1.HttpCode)(common_1.HttpStatus.NO_CONTENT),
    __param(0, (0, common_1.Param)('itemId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, manage_products_dto_1.RemoveProductsFromItemDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "removeProductsFromItem", null);
__decorate([
    (0, common_1.Put)('items/:itemId/products/sort'),
    __param(0, (0, common_1.Param)('itemId')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, manage_products_dto_1.UpdateItemProductsSortDto]),
    __metadata("design:returntype", Promise)
], ArrayCollectionsController.prototype, "updateItemProductsSort", null);
exports.ArrayCollectionsController = ArrayCollectionsController = __decorate([
    (0, common_1.Controller)('array-collections'),
    __metadata("design:paramtypes", [array_collections_service_1.ArrayCollectionsService])
], ArrayCollectionsController);
//# sourceMappingURL=array-collections.controller.js.map