export declare class ArrayCollectionsModule {
}
