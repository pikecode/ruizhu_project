"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArrayCollectionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const array_collection_entity_1 = require("../../entities/array-collection.entity");
const array_collection_item_entity_1 = require("../../entities/array-collection-item.entity");
const array_collection_item_product_entity_1 = require("../../entities/array-collection-item-product.entity");
let ArrayCollectionsService = class ArrayCollectionsService {
    arrayCollectionRepository;
    itemRepository;
    itemProductRepository;
    dataSource;
    constructor(arrayCollectionRepository, itemRepository, itemProductRepository, dataSource) {
        this.arrayCollectionRepository = arrayCollectionRepository;
        this.itemRepository = itemRepository;
        this.itemProductRepository = itemProductRepository;
        this.dataSource = dataSource;
    }
    async createArrayCollection(createDto) {
        const collection = this.arrayCollectionRepository.create(createDto);
        return await this.arrayCollectionRepository.save(collection);
    }
    async updateArrayCollection(id, updateDto) {
        const collection = await this.arrayCollectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`数组集合 ID ${id} 不存在`);
        }
        Object.assign(collection, updateDto);
        return await this.arrayCollectionRepository.save(collection);
    }
    async getArrayCollectionsList(page = 1, limit = 10) {
        const [items, total] = await this.arrayCollectionRepository.findAndCount({
            order: { sortOrder: 'ASC', createdAt: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        const pages = Math.ceil(total / limit);
        const itemsWithDetails = await Promise.all(items.map((collection) => this.getArrayCollectionDetail(collection.id)));
        return {
            items: itemsWithDetails,
            total,
            page,
            limit,
            pages,
        };
    }
    async getArrayCollectionDetail(id) {
        const collection = await this.arrayCollectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`数组集合 ID ${id} 不存在`);
        }
        const items = await this.getCollectionItems(id);
        return {
            id: collection.id,
            title: collection.title,
            description: collection.description,
            sortOrder: collection.sortOrder,
            isActive: collection.isActive,
            remark: collection.remark,
            items,
            itemCount: items.length,
            createdAt: collection.createdAt,
            updatedAt: collection.updatedAt,
        };
    }
    async deleteArrayCollection(id) {
        const collection = await this.arrayCollectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`数组集合 ID ${id} 不存在`);
        }
        await this.arrayCollectionRepository.remove(collection);
    }
    async createItem(arrayCollectionId, createDto) {
        const collection = await this.arrayCollectionRepository.findOne({
            where: { id: arrayCollectionId },
        });
        if (!collection) {
            throw new common_1.NotFoundException(`数组集合 ID ${arrayCollectionId} 不存在`);
        }
        const item = this.itemRepository.create({
            ...createDto,
            arrayCollectionId,
        });
        return await this.itemRepository.save(item);
    }
    async updateItem(itemId, updateDto) {
        const item = await this.itemRepository.findOne({ where: { id: itemId } });
        if (!item) {
            throw new common_1.NotFoundException(`项目 ID ${itemId} 不存在`);
        }
        Object.assign(item, updateDto);
        return await this.itemRepository.save(item);
    }
    async deleteItem(itemId) {
        const item = await this.itemRepository.findOne({ where: { id: itemId } });
        if (!item) {
            throw new common_1.NotFoundException(`项目 ID ${itemId} 不存在`);
        }
        await this.itemRepository.remove(item);
    }
    async getCollectionItems(collectionId, limit) {
        const query = this.itemRepository
            .createQueryBuilder('item')
            .where('item.arrayCollectionId = :collectionId', { collectionId })
            .orderBy('item.sortOrder', 'ASC')
            .addOrderBy('item.createdAt', 'DESC');
        if (limit) {
            query.limit(limit);
        }
        const items = await query.getMany();
        const itemsWithProducts = [];
        for (const item of items) {
            const products = await this.getItemProducts(item.id);
            itemsWithProducts.push({
                id: item.id,
                title: item.title,
                description: item.description,
                coverImageUrl: item.coverImageUrl,
                sortOrder: item.sortOrder,
                products,
                createdAt: item.createdAt,
                updatedAt: item.updatedAt,
            });
        }
        return itemsWithProducts;
    }
    async getItemProducts(itemId) {
        const query = this.dataSource
            .createQueryBuilder()
            .select('p.id', 'id')
            .addSelect('p.name', 'name')
            .addSelect('p.subtitle', 'subtitle')
            .addSelect('p.sku', 'sku')
            .addSelect('p.cover_image_url', 'coverImageUrl')
            .addSelect('p.is_new', 'isNew')
            .addSelect('p.is_sale_on', 'isSaleOn')
            .addSelect('p.is_out_of_stock', 'isOutOfStock')
            .addSelect('p.stock_quantity', 'stockQuantity')
            .addSelect('p.current_price', 'currentPrice')
            .addSelect('p.original_price', 'originalPrice')
            .addSelect('p.discount_rate', 'discountRate')
            .from('array_collection_item_products', 'acip')
            .innerJoin('products', 'p', 'acip.product_id = p.id')
            .where('acip.array_collection_item_id = :itemId', { itemId })
            .orderBy('acip.sort_order', 'ASC')
            .addOrderBy('acip.created_at', 'DESC');
        const products = await query.getRawMany();
        const productsWithTags = [];
        for (const product of products) {
            const tags = await this.dataSource
                .createQueryBuilder()
                .select('tag_name')
                .from('product_tags', 'pt')
                .where('pt.product_id = :productId', { productId: product.id })
                .getRawMany();
            productsWithTags.push({
                ...product,
                tags: tags.map((t) => t.tag_name),
            });
        }
        return productsWithTags;
    }
    async addProductsToItem(itemId, addDto) {
        const item = await this.itemRepository.findOne({ where: { id: itemId } });
        if (!item) {
            throw new common_1.NotFoundException(`项目 ID ${itemId} 不存在`);
        }
        const maxSortOrder = await this.dataSource
            .createQueryBuilder()
            .select('MAX(sort_order)', 'maxSortOrder')
            .from('array_collection_item_products', 'acip')
            .where('acip.array_collection_item_id = :itemId', { itemId })
            .getRawOne();
        const startSortOrder = addDto.startSortOrder ?? ((maxSortOrder?.maxSortOrder ?? -1) + 1);
        const itemProducts = addDto.productIds.map((productId, index) => ({
            arrayCollectionItemId: itemId,
            productId,
            sortOrder: startSortOrder + index,
        }));
        const query = this.dataSource
            .createQueryBuilder()
            .insert()
            .into(array_collection_item_product_entity_1.ArrayCollectionItemProduct)
            .values(itemProducts);
        await query.orIgnore().execute();
    }
    async removeProductsFromItem(itemId, removeDto) {
        const item = await this.itemRepository.findOne({ where: { id: itemId } });
        if (!item) {
            throw new common_1.NotFoundException(`项目 ID ${itemId} 不存在`);
        }
        await this.itemProductRepository.delete({
            arrayCollectionItemId: itemId,
            productId: removeDto.productIds,
        });
    }
    async updateItemProductsSort(itemId, updateDto) {
        const item = await this.itemRepository.findOne({ where: { id: itemId } });
        if (!item) {
            throw new common_1.NotFoundException(`项目 ID ${itemId} 不存在`);
        }
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            for (const product of updateDto.products) {
                await queryRunner.manager.update(array_collection_item_product_entity_1.ArrayCollectionItemProduct, {
                    arrayCollectionItemId: itemId,
                    productId: product.productId,
                }, {
                    sortOrder: product.sortOrder,
                });
            }
            await queryRunner.commitTransaction();
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            throw error;
        }
        finally {
            await queryRunner.release();
        }
    }
};
exports.ArrayCollectionsService = ArrayCollectionsService;
exports.ArrayCollectionsService = ArrayCollectionsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(array_collection_entity_1.ArrayCollection)),
    __param(1, (0, typeorm_1.InjectRepository)(array_collection_item_entity_1.ArrayCollectionItem)),
    __param(2, (0, typeorm_1.InjectRepository)(array_collection_item_product_entity_1.ArrayCollectionItemProduct)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.DataSource])
], ArrayCollectionsService);
//# sourceMappingURL=array-collections.service.js.map