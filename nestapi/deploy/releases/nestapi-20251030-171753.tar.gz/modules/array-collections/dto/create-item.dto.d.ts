export declare class CreateItemDto {
    title: string;
    description?: string;
    coverImageUrl?: string;
    sortOrder?: number;
}
