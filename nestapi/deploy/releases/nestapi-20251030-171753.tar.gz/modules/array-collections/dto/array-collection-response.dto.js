"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ArrayCollectionListResponseDto = exports.ArrayCollectionDetailResponseDto = exports.ArrayCollectionItemDto = exports.ArrayCollectionItemProductDto = void 0;
class ArrayCollectionItemProductDto {
    id;
    name;
    subtitle;
    sku;
    coverImageUrl;
    isNew;
    isSaleOn;
    isOutOfStock;
    stockQuantity;
    currentPrice;
    originalPrice;
    discountRate;
    tags;
}
exports.ArrayCollectionItemProductDto = ArrayCollectionItemProductDto;
class ArrayCollectionItemDto {
    id;
    title;
    description;
    coverImageUrl;
    sortOrder;
    products;
    createdAt;
    updatedAt;
}
exports.ArrayCollectionItemDto = ArrayCollectionItemDto;
class ArrayCollectionDetailResponseDto {
    id;
    title;
    description;
    sortOrder;
    isActive;
    items;
    itemCount;
    remark;
    createdAt;
    updatedAt;
}
exports.ArrayCollectionDetailResponseDto = ArrayCollectionDetailResponseDto;
class ArrayCollectionListResponseDto {
    items;
    total;
    page;
    limit;
    pages;
}
exports.ArrayCollectionListResponseDto = ArrayCollectionListResponseDto;
//# sourceMappingURL=array-collection-response.dto.js.map