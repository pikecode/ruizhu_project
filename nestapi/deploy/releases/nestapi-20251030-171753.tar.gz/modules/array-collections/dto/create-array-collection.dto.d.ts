export declare class CreateArrayCollectionDto {
    title: string;
    description?: string;
    sortOrder?: number;
    isActive?: boolean;
    remark?: string;
}
