export declare class AddProductsToItemDto {
    productIds: number[];
    startSortOrder?: number;
}
export declare class RemoveProductsFromItemDto {
    productIds: number[];
}
export declare class UpdateItemProductsSortDto {
    products: SortOrderItem[];
}
export declare class SortOrderItem {
    productId: number;
    sortOrder: number;
}
