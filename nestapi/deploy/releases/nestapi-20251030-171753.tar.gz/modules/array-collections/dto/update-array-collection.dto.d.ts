export declare class UpdateArrayCollectionDto {
    title?: string;
    description?: string;
    sortOrder?: number;
    isActive?: boolean;
    remark?: string;
}
