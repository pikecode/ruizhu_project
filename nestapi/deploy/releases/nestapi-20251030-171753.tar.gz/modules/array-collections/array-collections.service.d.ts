import { Repository, DataSource } from 'typeorm';
import { ArrayCollection } from '../../entities/array-collection.entity';
import { ArrayCollectionItem } from '../../entities/array-collection-item.entity';
import { ArrayCollectionItemProduct } from '../../entities/array-collection-item-product.entity';
import { CreateArrayCollectionDto } from './dto/create-array-collection.dto';
import { UpdateArrayCollectionDto } from './dto/update-array-collection.dto';
import { CreateItemDto } from './dto/create-item.dto';
import { ArrayCollectionDetailResponseDto, ArrayCollectionListResponseDto } from './dto/array-collection-response.dto';
import { AddProductsToItemDto, RemoveProductsFromItemDto, UpdateItemProductsSortDto } from './dto/manage-products.dto';
export declare class ArrayCollectionsService {
    private readonly arrayCollectionRepository;
    private readonly itemRepository;
    private readonly itemProductRepository;
    private readonly dataSource;
    constructor(arrayCollectionRepository: Repository<ArrayCollection>, itemRepository: Repository<ArrayCollectionItem>, itemProductRepository: Repository<ArrayCollectionItemProduct>, dataSource: DataSource);
    createArrayCollection(createDto: CreateArrayCollectionDto): Promise<ArrayCollection>;
    updateArrayCollection(id: number, updateDto: UpdateArrayCollectionDto): Promise<ArrayCollection>;
    getArrayCollectionsList(page?: number, limit?: number): Promise<ArrayCollectionListResponseDto>;
    getArrayCollectionDetail(id: number): Promise<ArrayCollectionDetailResponseDto>;
    deleteArrayCollection(id: number): Promise<void>;
    createItem(arrayCollectionId: number, createDto: CreateItemDto): Promise<ArrayCollectionItem>;
    updateItem(itemId: number, updateDto: CreateItemDto): Promise<ArrayCollectionItem>;
    deleteItem(itemId: number): Promise<void>;
    private getCollectionItems;
    private getItemProducts;
    addProductsToItem(itemId: number, addDto: AddProductsToItemDto): Promise<void>;
    removeProductsFromItem(itemId: number, removeDto: RemoveProductsFromItemDto): Promise<void>;
    updateItemProductsSort(itemId: number, updateDto: UpdateItemProductsSortDto): Promise<void>;
}
