export declare class CollectionsModule {
}
