import { CollectionsService } from './collections.service';
import { CreateCollectionDto } from './dto/create-collection.dto';
import { UpdateCollectionDto } from './dto/update-collection.dto';
import { AddProductsToCollectionDto, RemoveProductsFromCollectionDto, UpdateCollectionProductsSortDto } from './dto/manage-products.dto';
export declare class CollectionsController {
    private readonly collectionsService;
    constructor(collectionsService: CollectionsService);
    getHomeCollections(productsPerCollection?: number): Promise<{
        code: number;
        message: string;
        data: import("./dto/collection-response.dto").CollectionListItemDto[];
    }>;
    getCollectionBySlug(slug: string): Promise<{
        code: number;
        message: string;
        data: import("./dto/collection-response.dto").CollectionDetailResponseDto;
    }>;
    createCollection(createDto: CreateCollectionDto): Promise<{
        code: number;
        message: string;
        data: import("../../entities/collection.entity").Collection;
    }>;
    getCollectionsList(page?: number, limit?: number): Promise<{
        code: number;
        message: string;
        data: import("./dto/collection-response.dto").CollectionListResponseDto;
    }>;
    updateCollection(id: string, updateDto: UpdateCollectionDto): Promise<{
        code: number;
        message: string;
        data: import("../../entities/collection.entity").Collection;
    }>;
    getCollectionDetail(id: string): Promise<{
        code: number;
        message: string;
        data: import("./dto/collection-response.dto").CollectionDetailResponseDto;
    }>;
    deleteCollection(id: string): Promise<{
        code: number;
        message: string;
    }>;
    addProductsToCollection(id: string, addDto: AddProductsToCollectionDto): Promise<{
        code: number;
        message: string;
    }>;
    removeProductsFromCollection(id: string, removeDto: RemoveProductsFromCollectionDto): Promise<{
        code: number;
        message: string;
    }>;
    updateProductsSort(id: string, updateDto: UpdateCollectionProductsSortDto): Promise<{
        code: number;
        message: string;
    }>;
}
