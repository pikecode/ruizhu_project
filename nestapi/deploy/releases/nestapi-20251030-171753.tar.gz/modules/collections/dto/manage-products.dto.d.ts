export declare class CollectionProductSortItemDto {
    productId: number;
    sortOrder: number;
}
export declare class UpdateCollectionProductsSortDto {
    products: CollectionProductSortItemDto[];
}
export declare class AddProductsToCollectionDto {
    productIds: number[];
    startSortOrder?: number;
}
export declare class RemoveProductsFromCollectionDto {
    productIds: number[];
}
