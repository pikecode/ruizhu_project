export declare class CollectionProductItemDto {
    id: number;
    name: string;
    subtitle?: string;
    currentPrice: number;
    originalPrice: number;
    discountRate: number;
    coverImageUrl?: string | null;
    isNew: boolean;
    isSaleOn: boolean;
    isOutOfStock: boolean;
    stockQuantity: number;
    tags?: string[];
}
export declare class CollectionDetailResponseDto {
    id: number;
    name: string;
    slug: string;
    description?: string;
    coverImageUrl?: string | null;
    iconUrl?: string | null;
    sortOrder: number;
    isActive: boolean;
    isFeatured: boolean;
    remark?: string;
    products?: CollectionProductItemDto[];
    productCount: number;
    createdAt: Date;
    updatedAt: Date;
}
export declare class CollectionListItemDto {
    id: number;
    name: string;
    slug: string;
    description?: string;
    coverImageUrl?: string | null;
    iconUrl?: string | null;
    sortOrder: number;
    productCount: number;
    featuredProducts?: CollectionProductItemDto[];
}
export declare class CollectionListResponseDto {
    items: CollectionListItemDto[];
    total: number;
    page: number;
    limit: number;
    pages: number;
}
