export declare class CreateCollectionDto {
    name: string;
    slug: string;
    description?: string;
    coverImageUrl?: string;
    iconUrl?: string;
    sortOrder?: number;
    isActive?: boolean;
    isFeatured?: boolean;
    remark?: string;
}
