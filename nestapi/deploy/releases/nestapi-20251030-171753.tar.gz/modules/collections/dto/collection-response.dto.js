"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionListResponseDto = exports.CollectionListItemDto = exports.CollectionDetailResponseDto = exports.CollectionProductItemDto = void 0;
class CollectionProductItemDto {
    id;
    name;
    subtitle;
    currentPrice;
    originalPrice;
    discountRate;
    coverImageUrl;
    isNew;
    isSaleOn;
    isOutOfStock;
    stockQuantity;
    tags;
}
exports.CollectionProductItemDto = CollectionProductItemDto;
class CollectionDetailResponseDto {
    id;
    name;
    slug;
    description;
    coverImageUrl;
    iconUrl;
    sortOrder;
    isActive;
    isFeatured;
    remark;
    products;
    productCount;
    createdAt;
    updatedAt;
}
exports.CollectionDetailResponseDto = CollectionDetailResponseDto;
class CollectionListItemDto {
    id;
    name;
    slug;
    description;
    coverImageUrl;
    iconUrl;
    sortOrder;
    productCount;
    featuredProducts;
}
exports.CollectionListItemDto = CollectionListItemDto;
class CollectionListResponseDto {
    items;
    total;
    page;
    limit;
    pages;
}
exports.CollectionListResponseDto = CollectionListResponseDto;
//# sourceMappingURL=collection-response.dto.js.map