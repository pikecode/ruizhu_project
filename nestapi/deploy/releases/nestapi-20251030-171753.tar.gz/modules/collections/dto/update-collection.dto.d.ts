export declare class UpdateCollectionDto {
    name?: string;
    description?: string;
    coverImageUrl?: string;
    iconUrl?: string;
    sortOrder?: number;
    isActive?: boolean;
    isFeatured?: boolean;
    remark?: string;
}
