"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RemoveProductsFromCollectionDto = exports.AddProductsToCollectionDto = exports.UpdateCollectionProductsSortDto = exports.CollectionProductSortItemDto = void 0;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class CollectionProductSortItemDto {
    productId;
    sortOrder;
}
exports.CollectionProductSortItemDto = CollectionProductSortItemDto;
__decorate([
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CollectionProductSortItemDto.prototype, "productId", void 0);
__decorate([
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CollectionProductSortItemDto.prototype, "sortOrder", void 0);
class UpdateCollectionProductsSortDto {
    products;
}
exports.UpdateCollectionProductsSortDto = UpdateCollectionProductsSortDto;
__decorate([
    (0, class_validator_1.IsArray)(),
    (0, class_validator_1.ValidateNested)({ each: true }),
    (0, class_transformer_1.Type)(() => CollectionProductSortItemDto),
    __metadata("design:type", Array)
], UpdateCollectionProductsSortDto.prototype, "products", void 0);
class AddProductsToCollectionDto {
    productIds;
    startSortOrder = 0;
}
exports.AddProductsToCollectionDto = AddProductsToCollectionDto;
__decorate([
    (0, class_validator_1.IsArray)({ message: '产品ID列表必须是数组' }),
    (0, class_validator_1.IsNumber)({}, { each: true, message: '每个产品ID必须是数字' }),
    __metadata("design:type", Array)
], AddProductsToCollectionDto.prototype, "productIds", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], AddProductsToCollectionDto.prototype, "startSortOrder", void 0);
class RemoveProductsFromCollectionDto {
    productIds;
}
exports.RemoveProductsFromCollectionDto = RemoveProductsFromCollectionDto;
__decorate([
    (0, class_validator_1.IsArray)({ message: '产品ID列表必须是数组' }),
    (0, class_validator_1.IsNumber)({}, { each: true, message: '每个产品ID必须是数字' }),
    __metadata("design:type", Array)
], RemoveProductsFromCollectionDto.prototype, "productIds", void 0);
//# sourceMappingURL=manage-products.dto.js.map