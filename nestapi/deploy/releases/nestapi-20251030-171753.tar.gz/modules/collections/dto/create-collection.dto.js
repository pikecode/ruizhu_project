"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CreateCollectionDto = void 0;
const class_validator_1 = require("class-validator");
const collection_slugs_1 = require("../../../constants/collection-slugs");
class CreateCollectionDto {
    name;
    slug;
    description;
    coverImageUrl;
    iconUrl;
    sortOrder = 0;
    isActive = true;
    isFeatured = false;
    remark;
}
exports.CreateCollectionDto = CreateCollectionDto;
__decorate([
    (0, class_validator_1.IsString)({ message: '集合名称必须是字符串' }),
    (0, class_validator_1.Length)(1, 100, { message: '集合名称长度必须在1-100之间' }),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsString)({ message: 'slug必须是字符串' }),
    (0, class_validator_1.IsIn)(collection_slugs_1.VALID_COLLECTION_SLUGS, {
        message: `slug 必须是以下值之一: ${collection_slugs_1.VALID_COLLECTION_SLUGS.join(', ')}`,
    }),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "slug", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(0, 500),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(0, 500, { message: '封面图片URL长度不能超过500' }),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "coverImageUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.Length)(0, 255, { message: '图标URL长度不能超过255' }),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "iconUrl", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], CreateCollectionDto.prototype, "sortOrder", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateCollectionDto.prototype, "isActive", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], CreateCollectionDto.prototype, "isFeatured", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], CreateCollectionDto.prototype, "remark", void 0);
//# sourceMappingURL=create-collection.dto.js.map