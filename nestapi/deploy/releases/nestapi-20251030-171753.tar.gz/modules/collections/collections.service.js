"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const collection_entity_1 = require("../../entities/collection.entity");
const collection_product_entity_1 = require("../../entities/collection-product.entity");
let CollectionsService = class CollectionsService {
    collectionRepository;
    collectionProductRepository;
    dataSource;
    constructor(collectionRepository, collectionProductRepository, dataSource) {
        this.collectionRepository = collectionRepository;
        this.collectionProductRepository = collectionProductRepository;
        this.dataSource = dataSource;
    }
    async createCollection(createDto) {
        const existingCollection = await this.collectionRepository.findOne({
            where: { slug: createDto.slug },
        });
        if (existingCollection) {
            throw new common_1.BadRequestException(`Slug "${createDto.slug}" 已经存在`);
        }
        const collection = this.collectionRepository.create(createDto);
        return await this.collectionRepository.save(collection);
    }
    async updateCollection(id, updateDto) {
        const collection = await this.collectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${id} 不存在`);
        }
        Object.assign(collection, updateDto);
        return await this.collectionRepository.save(collection);
    }
    async getCollectionDetail(id) {
        const collection = await this.collectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${id} 不存在`);
        }
        const products = await this.getCollectionProducts(id);
        return {
            ...collection,
            products,
            productCount: products.length,
        };
    }
    async getCollectionsList(page = 1, limit = 10) {
        const [items, total] = await this.collectionRepository.findAndCount({
            order: { sortOrder: 'ASC', createdAt: 'DESC' },
            skip: (page - 1) * limit,
            take: limit,
        });
        const pages = Math.ceil(total / limit);
        return {
            items: items,
            total,
            page,
            limit,
            pages,
        };
    }
    async getFeaturedCollectionsForHomepage(productsPerCollection = 6) {
        const collections = await this.collectionRepository.find({
            where: { isFeatured: true, isActive: true },
            order: { sortOrder: 'ASC' },
        });
        const result = [];
        for (const collection of collections) {
            const productCount = await this.collectionProductRepository.count({
                where: { collectionId: collection.id },
            });
            const featuredProducts = await this.getCollectionProducts(collection.id, productsPerCollection);
            result.push({
                id: collection.id,
                name: collection.name,
                slug: collection.slug,
                description: collection.description,
                coverImageUrl: collection.coverImageUrl,
                iconUrl: collection.iconUrl,
                sortOrder: collection.sortOrder,
                productCount,
                featuredProducts,
            });
        }
        return result;
    }
    async deleteCollection(id) {
        const collection = await this.collectionRepository.findOne({ where: { id } });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${id} 不存在`);
        }
        await this.collectionRepository.remove(collection);
    }
    async getCollectionProducts(collectionId, limit) {
        const query = this.dataSource
            .createQueryBuilder()
            .select('p.id', 'id')
            .addSelect('p.name', 'name')
            .addSelect('p.subtitle', 'subtitle')
            .addSelect('p.cover_image_url', 'coverImageUrl')
            .addSelect('p.is_new', 'isNew')
            .addSelect('p.is_sale_on', 'isSaleOn')
            .addSelect('p.is_out_of_stock', 'isOutOfStock')
            .addSelect('p.stock_quantity', 'stockQuantity')
            .addSelect('p.current_price', 'currentPrice')
            .addSelect('p.original_price', 'originalPrice')
            .addSelect('p.discount_rate', 'discountRate')
            .from('collection_products', 'cp')
            .innerJoin('products', 'p', 'cp.product_id = p.id')
            .where('cp.collection_id = :collectionId', { collectionId })
            .orderBy('cp.sort_order', 'ASC')
            .addOrderBy('cp.created_at', 'DESC');
        if (limit) {
            query.limit(limit);
        }
        const products = await query.getRawMany();
        const productsWithTags = [];
        for (const product of products) {
            const tags = await this.dataSource
                .createQueryBuilder()
                .select('tag_name')
                .from('product_tags', 'pt')
                .where('pt.product_id = :productId', { productId: product.id })
                .getRawMany();
            productsWithTags.push({
                ...product,
                tags: tags.map((t) => t.tag_name),
            });
        }
        return productsWithTags;
    }
    async addProductsToCollection(collectionId, addDto) {
        const collection = await this.collectionRepository.findOne({
            where: { id: collectionId },
        });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${collectionId} 不存在`);
        }
        const maxSortOrder = await this.dataSource
            .createQueryBuilder()
            .select('MAX(sort_order)', 'maxSortOrder')
            .from('collection_products', 'cp')
            .where('cp.collection_id = :collectionId', { collectionId })
            .getRawOne();
        const startSortOrder = addDto.startSortOrder ??
            ((maxSortOrder?.maxSortOrder ?? -1) + 1);
        const collectionProducts = addDto.productIds.map((productId, index) => ({
            collectionId,
            productId,
            sortOrder: startSortOrder + index,
        }));
        const query = this.dataSource
            .createQueryBuilder()
            .insert()
            .into(collection_product_entity_1.CollectionProduct)
            .values(collectionProducts);
        await query.orIgnore().execute();
    }
    async removeProductsFromCollection(collectionId, removeDto) {
        const collection = await this.collectionRepository.findOne({
            where: { id: collectionId },
        });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${collectionId} 不存在`);
        }
        await this.collectionProductRepository.delete({
            collectionId,
            productId: removeDto.productIds,
        });
    }
    async updateProductsSort(collectionId, updateDto) {
        const collection = await this.collectionRepository.findOne({
            where: { id: collectionId },
        });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 ID ${collectionId} 不存在`);
        }
        const queryRunner = this.dataSource.createQueryRunner();
        await queryRunner.connect();
        await queryRunner.startTransaction();
        try {
            for (const item of updateDto.products) {
                await queryRunner.manager.update(collection_product_entity_1.CollectionProduct, {
                    collectionId,
                    productId: item.productId,
                }, {
                    sortOrder: item.sortOrder,
                });
            }
            await queryRunner.commitTransaction();
        }
        catch (error) {
            await queryRunner.rollbackTransaction();
            throw error;
        }
        finally {
            await queryRunner.release();
        }
    }
    async getCollectionBySlug(slug) {
        const collection = await this.collectionRepository.findOne({
            where: { slug },
        });
        if (!collection) {
            throw new common_1.NotFoundException(`集合 "${slug}" 不存在`);
        }
        const products = await this.getCollectionProducts(collection.id);
        return {
            ...collection,
            products,
            productCount: products.length,
        };
    }
};
exports.CollectionsService = CollectionsService;
exports.CollectionsService = CollectionsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(collection_entity_1.Collection)),
    __param(1, (0, typeorm_1.InjectRepository)(collection_product_entity_1.CollectionProduct)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.DataSource])
], CollectionsService);
//# sourceMappingURL=collections.service.js.map