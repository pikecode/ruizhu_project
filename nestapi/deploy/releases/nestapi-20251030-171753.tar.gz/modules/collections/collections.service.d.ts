import { Repository, DataSource } from 'typeorm';
import { Collection } from '../../entities/collection.entity';
import { CollectionProduct } from '../../entities/collection-product.entity';
import { CreateCollectionDto } from './dto/create-collection.dto';
import { UpdateCollectionDto } from './dto/update-collection.dto';
import { CollectionDetailResponseDto, CollectionListResponseDto, CollectionListItemDto } from './dto/collection-response.dto';
import { AddProductsToCollectionDto, RemoveProductsFromCollectionDto, UpdateCollectionProductsSortDto } from './dto/manage-products.dto';
export declare class CollectionsService {
    private readonly collectionRepository;
    private readonly collectionProductRepository;
    private readonly dataSource;
    constructor(collectionRepository: Repository<Collection>, collectionProductRepository: Repository<CollectionProduct>, dataSource: DataSource);
    createCollection(createDto: CreateCollectionDto): Promise<Collection>;
    updateCollection(id: number, updateDto: UpdateCollectionDto): Promise<Collection>;
    getCollectionDetail(id: number): Promise<CollectionDetailResponseDto>;
    getCollectionsList(page?: number, limit?: number): Promise<CollectionListResponseDto>;
    getFeaturedCollectionsForHomepage(productsPerCollection?: number): Promise<CollectionListItemDto[]>;
    deleteCollection(id: number): Promise<void>;
    private getCollectionProducts;
    addProductsToCollection(collectionId: number, addDto: AddProductsToCollectionDto): Promise<void>;
    removeProductsFromCollection(collectionId: number, removeDto: RemoveProductsFromCollectionDto): Promise<void>;
    updateProductsSort(collectionId: number, updateDto: UpdateCollectionProductsSortDto): Promise<void>;
    getCollectionBySlug(slug: string): Promise<CollectionDetailResponseDto>;
}
