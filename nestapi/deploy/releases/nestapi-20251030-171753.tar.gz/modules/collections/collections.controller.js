"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionsController = void 0;
const common_1 = require("@nestjs/common");
const collections_service_1 = require("./collections.service");
const create_collection_dto_1 = require("./dto/create-collection.dto");
const update_collection_dto_1 = require("./dto/update-collection.dto");
const manage_products_dto_1 = require("./dto/manage-products.dto");
let CollectionsController = class CollectionsController {
    collectionsService;
    constructor(collectionsService) {
        this.collectionsService = collectionsService;
    }
    async getHomeCollections(productsPerCollection) {
        const collections = await this.collectionsService.getFeaturedCollectionsForHomepage(productsPerCollection || 6);
        return {
            code: 200,
            message: 'Success',
            data: collections,
        };
    }
    async getCollectionBySlug(slug) {
        if (!slug || slug.length === 0) {
            throw new common_1.BadRequestException('slug参数不能为空');
        }
        const collection = await this.collectionsService.getCollectionBySlug(slug);
        return {
            code: 200,
            message: 'Success',
            data: collection,
        };
    }
    async createCollection(createDto) {
        const collection = await this.collectionsService.createCollection(createDto);
        return {
            code: 200,
            message: 'Collection created successfully',
            data: collection,
        };
    }
    async getCollectionsList(page = 1, limit = 10) {
        const result = await this.collectionsService.getCollectionsList(page, limit);
        return {
            code: 200,
            message: 'Success',
            data: result,
        };
    }
    async updateCollection(id, updateDto) {
        const collectionId = parseInt(id, 10);
        const collection = await this.collectionsService.updateCollection(collectionId, updateDto);
        return {
            code: 200,
            message: 'Collection updated successfully',
            data: collection,
        };
    }
    async getCollectionDetail(id) {
        const collectionId = parseInt(id, 10);
        const collection = await this.collectionsService.getCollectionDetail(collectionId);
        return {
            code: 200,
            message: 'Success',
            data: collection,
        };
    }
    async deleteCollection(id) {
        const collectionId = parseInt(id, 10);
        await this.collectionsService.deleteCollection(collectionId);
        return {
            code: 200,
            message: 'Collection deleted successfully',
        };
    }
    async addProductsToCollection(id, addDto) {
        const collectionId = parseInt(id, 10);
        await this.collectionsService.addProductsToCollection(collectionId, addDto);
        return {
            code: 200,
            message: 'Products added to collection successfully',
        };
    }
    async removeProductsFromCollection(id, removeDto) {
        const collectionId = parseInt(id, 10);
        await this.collectionsService.removeProductsFromCollection(collectionId, removeDto);
        return {
            code: 200,
            message: 'Products removed from collection successfully',
        };
    }
    async updateProductsSort(id, updateDto) {
        const collectionId = parseInt(id, 10);
        await this.collectionsService.updateProductsSort(collectionId, updateDto);
        return {
            code: 200,
            message: 'Products sort order updated successfully',
        };
    }
};
exports.CollectionsController = CollectionsController;
__decorate([
    (0, common_1.Get)('home'),
    __param(0, (0, common_1.Query)('productsPerCollection')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "getHomeCollections", null);
__decorate([
    (0, common_1.Get)(':slug'),
    __param(0, (0, common_1.Param)('slug')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "getCollectionBySlug", null);
__decorate([
    (0, common_1.Post)(),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [create_collection_dto_1.CreateCollectionDto]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "createCollection", null);
__decorate([
    (0, common_1.Get)(),
    __param(0, (0, common_1.Query)('page')),
    __param(1, (0, common_1.Query)('limit')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number, Number]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "getCollectionsList", null);
__decorate([
    (0, common_1.Put)(':id'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, update_collection_dto_1.UpdateCollectionDto]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "updateCollection", null);
__decorate([
    (0, common_1.Get)(':id/detail'),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "getCollectionDetail", null);
__decorate([
    (0, common_1.Delete)(':id'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Param)('id')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "deleteCollection", null);
__decorate([
    (0, common_1.Post)(':id/products/add'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, manage_products_dto_1.AddProductsToCollectionDto]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "addProductsToCollection", null);
__decorate([
    (0, common_1.Delete)(':id/products/remove'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, manage_products_dto_1.RemoveProductsFromCollectionDto]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "removeProductsFromCollection", null);
__decorate([
    (0, common_1.Put)(':id/products/sort'),
    (0, common_1.HttpCode)(200),
    __param(0, (0, common_1.Param)('id')),
    __param(1, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, manage_products_dto_1.UpdateCollectionProductsSortDto]),
    __metadata("design:returntype", Promise)
], CollectionsController.prototype, "updateProductsSort", null);
exports.CollectionsController = CollectionsController = __decorate([
    (0, common_1.Controller)('collections'),
    __metadata("design:paramtypes", [collections_service_1.CollectionsService])
], CollectionsController);
//# sourceMappingURL=collections.controller.js.map