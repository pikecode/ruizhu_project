"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatModule = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const config_1 = require("@nestjs/config");
const wechat_payment_entity_1 = require("./entities/wechat-payment.entity");
const wechat_notification_entity_1 = require("./entities/wechat-notification.entity");
const wechat_payment_service_1 = require("./services/wechat-payment.service");
const wechat_notification_service_1 = require("./services/wechat-notification.service");
const wechat_payment_controller_1 = require("./controllers/wechat-payment.controller");
const wechat_notification_controller_1 = require("./controllers/wechat-notification.controller");
let WechatModule = class WechatModule {
};
exports.WechatModule = WechatModule;
exports.WechatModule = WechatModule = __decorate([
    (0, common_1.Module)({
        imports: [
            config_1.ConfigModule,
            typeorm_1.TypeOrmModule.forFeature([wechat_payment_entity_1.WechatPaymentEntity, wechat_notification_entity_1.WechatNotificationEntity]),
        ],
        providers: [wechat_payment_service_1.WechatPaymentService, wechat_notification_service_1.WechatNotificationService],
        controllers: [wechat_payment_controller_1.WechatPaymentController, wechat_notification_controller_1.WechatNotificationController],
        exports: [wechat_payment_service_1.WechatPaymentService, wechat_notification_service_1.WechatNotificationService],
    })
], WechatModule);
//# sourceMappingURL=wechat.module.js.map