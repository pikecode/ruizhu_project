"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPaymentEntity = void 0;
const typeorm_1 = require("typeorm");
let WechatPaymentEntity = class WechatPaymentEntity {
    id;
    openid;
    outTradeNo;
    transactionId;
    prepayId;
    totalFee;
    body;
    detail;
    notifyUrl;
    status;
    payTime;
    metadata;
    paymentMethod;
    wechatCallback;
    remark;
    createdAt;
    updatedAt;
};
exports.WechatPaymentEntity = WechatPaymentEntity;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], WechatPaymentEntity.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100 }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "openid", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, unique: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "outTradeNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "transactionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "prepayId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], WechatPaymentEntity.prototype, "totalFee", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255 }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "body", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "detail", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "notifyUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'enum', enum: ['pending', 'success', 'failed', 'cancelled'], default: 'pending' }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'datetime', nullable: true }),
    __metadata("design:type", Date)
], WechatPaymentEntity.prototype, "payTime", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true }),
    __metadata("design:type", Object)
], WechatPaymentEntity.prototype, "metadata", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, default: 'wechat' }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "paymentMethod", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true }),
    __metadata("design:type", Object)
], WechatPaymentEntity.prototype, "wechatCallback", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], WechatPaymentEntity.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)(),
    __metadata("design:type", Date)
], WechatPaymentEntity.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)(),
    __metadata("design:type", Date)
], WechatPaymentEntity.prototype, "updatedAt", void 0);
exports.WechatPaymentEntity = WechatPaymentEntity = __decorate([
    (0, typeorm_1.Entity)('wechat_payments'),
    (0, typeorm_1.Index)(['openid']),
    (0, typeorm_1.Index)(['outTradeNo']),
    (0, typeorm_1.Index)(['prepayId']),
    (0, typeorm_1.Index)(['transactionId'])
], WechatPaymentEntity);
//# sourceMappingURL=wechat-payment.entity.js.map