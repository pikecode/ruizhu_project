export declare class WechatNotificationEntity {
    id: number;
    openid: string;
    notificationType: 'template' | 'subscribe' | 'uniform';
    templateId: string;
    title: string;
    content: string;
    data: Record<string, any>;
    page: string;
    status: 'pending' | 'sent' | 'failed' | 'read';
    businessId: string;
    businessType: string;
    msgId: string;
    wechatResponse: Record<string, any>;
    errorMessage: string;
    sentAt: Date;
    scheduledAt: Date;
    readAt: Date;
    retryCount: number;
    maxRetries: number;
    remark: string;
    createdAt: Date;
    updatedAt: Date;
}
