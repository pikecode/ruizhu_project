export declare class WechatPaymentEntity {
    id: number;
    openid: string;
    outTradeNo: string;
    transactionId: string;
    prepayId: string;
    totalFee: number;
    body: string;
    detail: string;
    notifyUrl: string;
    status: 'pending' | 'success' | 'failed' | 'cancelled';
    payTime: Date;
    metadata: Record<string, any>;
    paymentMethod: string;
    wechatCallback: Record<string, any>;
    remark: string;
    createdAt: Date;
    updatedAt: Date;
}
