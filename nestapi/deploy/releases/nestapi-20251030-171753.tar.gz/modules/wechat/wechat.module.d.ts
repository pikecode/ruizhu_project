export declare class WechatModule {
}
