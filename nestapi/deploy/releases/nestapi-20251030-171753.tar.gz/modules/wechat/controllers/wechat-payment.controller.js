"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var WechatPaymentController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPaymentController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const wechat_payment_service_1 = require("../services/wechat-payment.service");
const wechat_payment_dto_1 = require("../dto/wechat-payment.dto");
let WechatPaymentController = WechatPaymentController_1 = class WechatPaymentController {
    wechatPaymentService;
    logger = new common_1.Logger(WechatPaymentController_1.name);
    constructor(wechatPaymentService) {
        this.wechatPaymentService = wechatPaymentService;
    }
    async createOrder(createOrderDto) {
        this.logger.log(`Creating payment order for openid: ${createOrderDto.openid}`);
        const data = await this.wechatPaymentService.createUnifiedOrder(createOrderDto);
        return {
            code: 200,
            message: 'Payment order created successfully',
            data,
        };
    }
    async handleCallback(callbackData, res) {
        try {
            this.logger.log(`Received payment callback for trade: ${callbackData.out_trade_no}`);
            await this.wechatPaymentService.handlePaymentCallback(callbackData);
            const response = `<xml>
        <return_code><![CDATA[SUCCESS]]></return_code>
        <return_msg><![CDATA[OK]]></return_msg>
      </xml>`;
            res.type('text/xml').send(response);
        }
        catch (error) {
            this.logger.error(`Payment callback error: ${error.message}`);
            const response = `<xml>
        <return_code><![CDATA[FAIL]]></return_code>
        <return_msg><![CDATA[${error.message}]]></return_msg>
      </xml>`;
            res.type('text/xml').send(response);
        }
    }
    async queryOrderStatus(tradeNo, openid) {
        const data = await this.wechatPaymentService.queryOrderStatus({
            tradeNo,
            openid,
        });
        return {
            code: 200,
            message: 'Order status retrieved successfully',
            data,
        };
    }
    async createRefund(refundDto) {
        this.logger.log(`Creating refund for trade: ${refundDto.outTradeNo}, amount: ${refundDto.refundFee}`);
        const data = await this.wechatPaymentService.createRefund(refundDto);
        return {
            code: 200,
            message: 'Refund request created successfully',
            data,
        };
    }
};
exports.WechatPaymentController = WechatPaymentController;
__decorate([
    (0, common_1.Post)('create-order'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Create WeChat payment order',
        description: 'Call WeChat unified order API to create prepaid order and generate payment parameters',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Payment order created successfully',
        type: wechat_payment_dto_1.CreatePaymentResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid request parameters or WeChat API error',
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_payment_dto_1.CreateUnifiedOrderDto]),
    __metadata("design:returntype", Promise)
], WechatPaymentController.prototype, "createOrder", null);
__decorate([
    (0, common_1.Post)('callback'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Handle WeChat payment callback',
        description: 'Process WeChat payment callback notification. Must be publicly accessible. Verify signature and update order status.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Callback processed successfully',
    }),
    __param(0, (0, common_1.Body)()),
    __param(1, (0, common_1.Res)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_payment_dto_1.WechatPaymentCallbackDto, Object]),
    __metadata("design:returntype", Promise)
], WechatPaymentController.prototype, "handleCallback", null);
__decorate([
    (0, common_1.Get)('query-status'),
    (0, swagger_1.ApiOperation)({
        summary: 'Query payment order status',
        description: 'Query if a payment order has been paid',
    }),
    (0, swagger_1.ApiQuery)({
        name: 'tradeNo',
        description: 'Trade number (商户订单号)',
        example: 'ORD20231225001',
    }),
    (0, swagger_1.ApiQuery)({
        name: 'openid',
        description: 'User openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Order status retrieved successfully',
        type: wechat_payment_dto_1.OrderStatusResponseDto,
    }),
    __param(0, (0, common_1.Query)('tradeNo')),
    __param(1, (0, common_1.Query)('openid')),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [String, String]),
    __metadata("design:returntype", Promise)
], WechatPaymentController.prototype, "queryOrderStatus", null);
__decorate([
    (0, common_1.Post)('refund'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Request refund',
        description: 'Request refund for a paid order. Only refund orders with successful payment.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Refund request created successfully',
        type: wechat_payment_dto_1.RefundResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Order not found or refund not allowed',
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_payment_dto_1.RefundRequestDto]),
    __metadata("design:returntype", Promise)
], WechatPaymentController.prototype, "createRefund", null);
exports.WechatPaymentController = WechatPaymentController = WechatPaymentController_1 = __decorate([
    (0, swagger_1.ApiTags)('WeChat Payment'),
    (0, common_1.Controller)('wechat/payment'),
    __metadata("design:paramtypes", [wechat_payment_service_1.WechatPaymentService])
], WechatPaymentController);
//# sourceMappingURL=wechat-payment.controller.js.map