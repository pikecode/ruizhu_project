"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var WechatNotificationController_1;
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatNotificationController = void 0;
const common_1 = require("@nestjs/common");
const swagger_1 = require("@nestjs/swagger");
const wechat_notification_service_1 = require("../services/wechat-notification.service");
const wechat_notification_dto_1 = require("../dto/wechat-notification.dto");
let WechatNotificationController = WechatNotificationController_1 = class WechatNotificationController {
    notificationService;
    logger = new common_1.Logger(WechatNotificationController_1.name);
    constructor(notificationService) {
        this.notificationService = notificationService;
    }
    async sendSubscribeMessage(sendMessageDto) {
        this.logger.log(`Sending subscription message to ${sendMessageDto.openid}, template: ${sendMessageDto.templateId}`);
        const data = await this.notificationService.sendSubscribeMessage(sendMessageDto);
        return {
            code: 200,
            message: 'Notification sent successfully',
            data,
        };
    }
    async sendBatchMessages(sendBatchDto) {
        this.logger.log(`Sending batch notifications to ${sendBatchDto.openids.length} users`);
        const data = await this.notificationService.sendBatchMessages(sendBatchDto);
        return {
            code: 200,
            message: 'Batch notifications sent',
            data,
        };
    }
    async getNotificationRecords(getRecordsDto) {
        const data = await this.notificationService.getNotificationRecords(getRecordsDto);
        return {
            code: 200,
            message: 'Notification records retrieved',
            data,
        };
    }
    async markNotificationAsRead(id) {
        await this.notificationService.markNotificationAsRead(id);
        return {
            code: 200,
            message: 'Notification marked as read',
        };
    }
    async retryFailedNotification(id) {
        this.logger.log(`Retrying notification ${id}`);
        const data = await this.notificationService.retryFailedNotification(id);
        return {
            code: 200,
            message: 'Notification retry sent',
            data,
        };
    }
};
exports.WechatNotificationController = WechatNotificationController;
__decorate([
    (0, common_1.Post)('send-subscribe'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Send WeChat subscription message',
        description: 'Send a subscription notification to a user. User must authorize this message type.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Notification sent successfully',
        type: wechat_notification_dto_1.SendMessageResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Invalid request parameters or WeChat API error',
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_notification_dto_1.SendSubscribeMessageDto]),
    __metadata("design:returntype", Promise)
], WechatNotificationController.prototype, "sendSubscribeMessage", null);
__decorate([
    (0, common_1.Post)('send-batch'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Send batch notifications',
        description: 'Send the same notification to multiple users. Concurrent sending with automatic limiting.',
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Batch notifications sent',
        type: wechat_notification_dto_1.SendBatchMessagesResponseDto,
    }),
    __param(0, (0, common_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_notification_dto_1.SendBatchMessagesDto]),
    __metadata("design:returntype", Promise)
], WechatNotificationController.prototype, "sendBatchMessages", null);
__decorate([
    (0, common_1.Get)('records'),
    (0, swagger_1.ApiOperation)({
        summary: 'Get notification records',
        description: 'Query user notification history with filtering and pagination',
    }),
    (0, swagger_1.ApiQuery)({
        name: 'openid',
        description: 'User openId',
        required: true,
    }),
    (0, swagger_1.ApiQuery)({
        name: 'notificationType',
        description: 'Filter by notification type: subscribe, template, uniform, all',
        required: false,
        enum: ['template', 'subscribe', 'uniform', 'all'],
    }),
    (0, swagger_1.ApiQuery)({
        name: 'status',
        description: 'Filter by status: pending, sent, failed, read, all',
        required: false,
        enum: ['pending', 'sent', 'failed', 'read', 'all'],
    }),
    (0, swagger_1.ApiQuery)({
        name: 'page',
        description: 'Page number',
        required: false,
        type: Number,
    }),
    (0, swagger_1.ApiQuery)({
        name: 'limit',
        description: 'Items per page',
        required: false,
        type: Number,
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Notification records retrieved',
        type: wechat_notification_dto_1.NotificationListResponseDto,
    }),
    __param(0, (0, common_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [wechat_notification_dto_1.GetNotificationRecordsDto]),
    __metadata("design:returntype", Promise)
], WechatNotificationController.prototype, "getNotificationRecords", null);
__decorate([
    (0, common_1.Put)('mark-read/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Mark notification as read',
        description: 'Update notification status to read',
    }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Notification ID',
        type: Number,
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Notification marked as read',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], WechatNotificationController.prototype, "markNotificationAsRead", null);
__decorate([
    (0, common_1.Post)('retry-failed/:id'),
    (0, common_1.HttpCode)(common_1.HttpStatus.OK),
    (0, swagger_1.ApiOperation)({
        summary: 'Retry failed notification',
        description: 'Retry sending a failed notification message',
    }),
    (0, swagger_1.ApiParam)({
        name: 'id',
        description: 'Notification ID',
        type: Number,
    }),
    (0, swagger_1.ApiResponse)({
        status: 200,
        description: 'Notification retry sent',
        type: wechat_notification_dto_1.SendMessageResponseDto,
    }),
    (0, swagger_1.ApiResponse)({
        status: 400,
        description: 'Notification not found or cannot be retried',
    }),
    __param(0, (0, common_1.Param)('id', common_1.ParseIntPipe)),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Number]),
    __metadata("design:returntype", Promise)
], WechatNotificationController.prototype, "retryFailedNotification", null);
exports.WechatNotificationController = WechatNotificationController = WechatNotificationController_1 = __decorate([
    (0, swagger_1.ApiTags)('WeChat Notification'),
    (0, common_1.Controller)('wechat/notify'),
    __metadata("design:paramtypes", [wechat_notification_service_1.WechatNotificationService])
], WechatNotificationController);
//# sourceMappingURL=wechat-notification.controller.js.map