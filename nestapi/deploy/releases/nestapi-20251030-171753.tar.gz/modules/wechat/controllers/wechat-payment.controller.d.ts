import type { Response } from 'express';
import { WechatPaymentService } from '../services/wechat-payment.service';
import { CreateUnifiedOrderDto, CreatePaymentResponseDto, WechatPaymentCallbackDto, OrderStatusResponseDto, RefundRequestDto, RefundResponseDto } from '../dto/wechat-payment.dto';
export declare class WechatPaymentController {
    private readonly wechatPaymentService;
    private readonly logger;
    constructor(wechatPaymentService: WechatPaymentService);
    createOrder(createOrderDto: CreateUnifiedOrderDto): Promise<{
        code: number;
        message: string;
        data: CreatePaymentResponseDto;
    }>;
    handleCallback(callbackData: WechatPaymentCallbackDto, res: Response): Promise<void>;
    queryOrderStatus(tradeNo: string, openid: string): Promise<{
        code: number;
        message: string;
        data: OrderStatusResponseDto;
    }>;
    createRefund(refundDto: RefundRequestDto): Promise<{
        code: number;
        message: string;
        data: RefundResponseDto;
    }>;
}
