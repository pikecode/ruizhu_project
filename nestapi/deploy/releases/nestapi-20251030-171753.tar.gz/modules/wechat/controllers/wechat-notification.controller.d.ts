import { WechatNotificationService } from '../services/wechat-notification.service';
import { SendSubscribeMessageDto, SendMessageResponseDto, SendBatchMessagesDto, SendBatchMessagesResponseDto, GetNotificationRecordsDto, NotificationListResponseDto } from '../dto/wechat-notification.dto';
export declare class WechatNotificationController {
    private readonly notificationService;
    private readonly logger;
    constructor(notificationService: WechatNotificationService);
    sendSubscribeMessage(sendMessageDto: SendSubscribeMessageDto): Promise<{
        code: number;
        message: string;
        data: SendMessageResponseDto;
    }>;
    sendBatchMessages(sendBatchDto: SendBatchMessagesDto): Promise<{
        code: number;
        message: string;
        data: SendBatchMessagesResponseDto;
    }>;
    getNotificationRecords(getRecordsDto: GetNotificationRecordsDto): Promise<{
        code: number;
        message: string;
        data: NotificationListResponseDto;
    }>;
    markNotificationAsRead(id: number): Promise<{
        code: number;
        message: string;
    }>;
    retryFailedNotification(id: number): Promise<{
        code: number;
        message: string;
        data: SendMessageResponseDto;
    }>;
}
