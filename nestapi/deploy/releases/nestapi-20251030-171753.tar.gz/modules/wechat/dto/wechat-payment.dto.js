"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RefundResponseDto = exports.RefundRequestDto = exports.OrderStatusResponseDto = exports.QueryOrderStatusDto = exports.WechatPaymentCallbackDto = exports.CreatePaymentResponseDto = exports.UnifiedOrderResponseDto = exports.CreateUnifiedOrderDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class CreateUnifiedOrderDto {
    openid;
    outTradeNo;
    totalFee;
    body;
    detail;
    goodsTag;
    metadata;
    remark;
}
exports.CreateUnifiedOrderDto = CreateUnifiedOrderDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "openid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商户订单号，需要在商户系统中唯一',
        example: 'ORD20231225001',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "outTradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付金额（分），最小为1',
        example: 100,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Number)
], CreateUnifiedOrderDto.prototype, "totalFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品描述',
        example: '商城购物',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "body", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品详情（可选）',
        example: '商品ID:123456 数量:2',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "detail", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品标签（可选）',
        example: 'goods',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "goodsTag", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务数据（JSON格式，可选），用于存储额外信息',
        example: { orderId: 123, userId: 456 },
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], CreateUnifiedOrderDto.prototype, "metadata", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '备注（可选）',
        example: '测试订单',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], CreateUnifiedOrderDto.prototype, "remark", void 0);
class UnifiedOrderResponseDto {
    return_code;
    return_msg;
    result_code;
    prepay_id;
    code_url;
}
exports.UnifiedOrderResponseDto = UnifiedOrderResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '返回码',
        example: 'SUCCESS',
    }),
    __metadata("design:type", String)
], UnifiedOrderResponseDto.prototype, "return_code", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '返回信息',
        example: 'OK',
    }),
    __metadata("design:type", String)
], UnifiedOrderResponseDto.prototype, "return_msg", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务结果码',
        example: 'SUCCESS',
        required: false,
    }),
    __metadata("design:type", String)
], UnifiedOrderResponseDto.prototype, "result_code", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预付交易会话标识',
        example: 'wx201512122015105a27612ec7cef79291',
    }),
    __metadata("design:type", String)
], UnifiedOrderResponseDto.prototype, "prepay_id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '二维码链接',
        example: 'weixin://wxpay/bizpayurl?pr=...',
        required: false,
    }),
    __metadata("design:type", String)
], UnifiedOrderResponseDto.prototype, "code_url", void 0);
class CreatePaymentResponseDto {
    outTradeNo;
    prepayId;
    timeStamp;
    nonceStr;
    signType;
    paySign;
    totalFee;
    body;
}
exports.CreatePaymentResponseDto = CreatePaymentResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商户订单号',
        example: 'ORD20231225001',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "outTradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '预付交易会话标识',
        example: 'wx201512122015105a27612ec7cef79291',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "prepayId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付时间戳',
        example: '1640000000',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "timeStamp", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '随机字符串',
        example: 'abc123',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "nonceStr", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '签名方式',
        example: 'MD5',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "signType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付签名',
        example: 'xxx...',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "paySign", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付金额（分）',
        example: 100,
    }),
    __metadata("design:type", Number)
], CreatePaymentResponseDto.prototype, "totalFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商品描述',
        example: '商城购物',
    }),
    __metadata("design:type", String)
], CreatePaymentResponseDto.prototype, "body", void 0);
class WechatPaymentCallbackDto {
    appid;
    mch_id;
    nonce_str;
    sign;
    result_code;
    prepay_id;
    openid;
    trade_type;
    bank_type;
    total_fee;
    spbill_create_ip;
    gmt_create;
    gmt_payment;
    transaction_id;
    out_trade_no;
    attach;
    time_end;
    trade_state;
    trade_state_desc;
    err_code;
    err_code_des;
}
exports.WechatPaymentCallbackDto = WechatPaymentCallbackDto;
class QueryOrderStatusDto {
    tradeNo;
    openid;
}
exports.QueryOrderStatusDto = QueryOrderStatusDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商户订单号或微信交易号',
        example: 'ORD20231225001',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], QueryOrderStatusDto.prototype, "tradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], QueryOrderStatusDto.prototype, "openid", void 0);
class OrderStatusResponseDto {
    outTradeNo;
    status;
    totalFee;
    payTime;
    transactionId;
}
exports.OrderStatusResponseDto = OrderStatusResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '订单号',
        example: 'ORD20231225001',
    }),
    __metadata("design:type", String)
], OrderStatusResponseDto.prototype, "outTradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付状态',
        enum: ['pending', 'success', 'failed', 'cancelled'],
    }),
    __metadata("design:type", String)
], OrderStatusResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付金额（分）',
        example: 100,
    }),
    __metadata("design:type", Number)
], OrderStatusResponseDto.prototype, "totalFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '支付完成时间',
        example: '2023-12-25T10:00:00Z',
        required: false,
    }),
    __metadata("design:type", Date)
], OrderStatusResponseDto.prototype, "payTime", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '微信交易号',
        example: '1234567890',
        required: false,
    }),
    __metadata("design:type", String)
], OrderStatusResponseDto.prototype, "transactionId", void 0);
class RefundRequestDto {
    outTradeNo;
    refundFee;
    reason;
    openid;
}
exports.RefundRequestDto = RefundRequestDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商户订单号',
        example: 'ORD20231225001',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RefundRequestDto.prototype, "outTradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '退款金额（分），为空则全额退款',
        example: 50,
        required: false,
    }),
    (0, class_validator_1.IsNumber)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], RefundRequestDto.prototype, "refundFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '退款原因',
        example: '用户申请退款',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RefundRequestDto.prototype, "reason", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], RefundRequestDto.prototype, "openid", void 0);
class RefundResponseDto {
    outTradeNo;
    status;
    refundFee;
    refundId;
}
exports.RefundResponseDto = RefundResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '商户订单号',
        example: 'ORD20231225001',
    }),
    __metadata("design:type", String)
], RefundResponseDto.prototype, "outTradeNo", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '退款状态',
        enum: ['processing', 'success', 'failed'],
    }),
    __metadata("design:type", String)
], RefundResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '退款金额（分）',
        example: 50,
    }),
    __metadata("design:type", Number)
], RefundResponseDto.prototype, "refundFee", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '微信退款单号',
        example: '50000000382018062301',
        required: false,
    }),
    __metadata("design:type", String)
], RefundResponseDto.prototype, "refundId", void 0);
//# sourceMappingURL=wechat-payment.dto.js.map