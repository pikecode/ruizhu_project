export declare class CreateUnifiedOrderDto {
    openid: string;
    outTradeNo: string;
    totalFee: number;
    body: string;
    detail?: string;
    goodsTag?: string;
    metadata?: Record<string, any>;
    remark?: string;
}
export declare class UnifiedOrderResponseDto {
    return_code: string;
    return_msg: string;
    result_code?: string;
    prepay_id?: string;
    code_url?: string;
}
export declare class CreatePaymentResponseDto {
    outTradeNo: string;
    prepayId: string;
    timeStamp: string;
    nonceStr: string;
    signType: string;
    paySign: string;
    totalFee: number;
    body: string;
}
export declare class WechatPaymentCallbackDto {
    appid: string;
    mch_id: string;
    nonce_str: string;
    sign: string;
    result_code: string;
    prepay_id?: string;
    openid?: string;
    trade_type?: string;
    bank_type?: string;
    total_fee?: number;
    spbill_create_ip?: string;
    gmt_create?: string;
    gmt_payment?: string;
    transaction_id?: string;
    out_trade_no?: string;
    attach?: string;
    time_end?: string;
    trade_state?: string;
    trade_state_desc?: string;
    err_code?: string;
    err_code_des?: string;
    [key: string]: any;
}
export declare class QueryOrderStatusDto {
    tradeNo: string;
    openid: string;
}
export declare class OrderStatusResponseDto {
    outTradeNo: string;
    status: string;
    totalFee: number;
    payTime?: Date;
    transactionId?: string;
}
export declare class RefundRequestDto {
    outTradeNo: string;
    refundFee?: number;
    reason: string;
    openid: string;
}
export declare class RefundResponseDto {
    outTradeNo: string;
    status: string;
    refundFee: number;
    refundId?: string;
}
