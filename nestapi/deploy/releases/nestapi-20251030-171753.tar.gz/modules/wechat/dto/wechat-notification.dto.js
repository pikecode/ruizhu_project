"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.NotificationListResponseDto = exports.NotificationRecordDto = exports.GetNotificationRecordsDto = exports.SendBatchMessagesResponseDto = exports.SendBatchMessagesDto = exports.SendMessageResponseDto = exports.SendSubscribeMessageDto = exports.SendTemplateMessageDto = void 0;
const class_validator_1 = require("class-validator");
const swagger_1 = require("@nestjs/swagger");
class SendTemplateMessageDto {
    openid;
    templateId;
    title;
    data;
    url;
    businessId;
    businessType;
}
exports.SendTemplateMessageDto = SendTemplateMessageDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "openid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '模板ID',
        example: 'ngcharlesme_4jb74tVwW4gC4c6DpWMvjqxQg-fXsWvKJ3NVLLzGAy0',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "templateId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息标题',
        example: '订单支付成功',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '模板数据，JSON格式',
        example: {
            first: { value: '订单号：123456' },
            keyword1: { value: '¥100.00' },
            keyword2: { value: '2023-12-25 10:00:00' },
            remark: { value: '点击查看订单详情' },
        },
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], SendTemplateMessageDto.prototype, "data", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '点击消息跳转的页面',
        example: '/pages/order/detail?id=123',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "url", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务ID（订单ID等）',
        example: '123456',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "businessId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务类型',
        example: 'order',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendTemplateMessageDto.prototype, "businessType", void 0);
class SendSubscribeMessageDto {
    openid;
    templateId;
    title;
    content;
    data;
    page;
    appid;
    businessId;
    businessType;
    immediate;
    scheduledAt;
}
exports.SendSubscribeMessageDto = SendSubscribeMessageDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "openid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '订阅消息模板ID',
        example: '_xW4gC4c6DpWMvjqxQg-fXsWvKJ3NVLLzGAy0',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "templateId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息标题',
        example: '订单支付成功',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息内容',
        example: '您的订单已支付成功，感谢您的购买',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "content", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息数据，JSON格式',
        example: {
            thing1: { value: '订单号123456' },
            amount2: { value: '¥100.00' },
            time3: { value: '2023-12-25 10:00:00' },
        },
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], SendSubscribeMessageDto.prototype, "data", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '点击消息跳转的页面路径',
        example: '/pages/order/detail?id=123',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '跳转小程序的appid',
        example: 'wx0377b6b22ea7e8fc',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "appid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务ID（订单ID等）',
        example: '123456',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "businessId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务类型',
        enum: ['order', 'payment', 'refund', 'delivery', 'system'],
        example: 'order',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "businessType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '是否立即发送，false表示定时发送',
        example: true,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Boolean)
], SendSubscribeMessageDto.prototype, "immediate", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '定时发送时间（ISO 8601格式）',
        example: '2023-12-25T15:00:00Z',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendSubscribeMessageDto.prototype, "scheduledAt", void 0);
class SendMessageResponseDto {
    msgId;
    status;
    errorMessage;
    sentAt;
}
exports.SendMessageResponseDto = SendMessageResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息ID',
        example: '1234567890',
    }),
    __metadata("design:type", String)
], SendMessageResponseDto.prototype, "msgId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送状态',
        enum: ['pending', 'sent', 'failed'],
        example: 'sent',
    }),
    __metadata("design:type", String)
], SendMessageResponseDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '错误信息（仅当发送失败时返回）',
        example: 'The template_id is invalid',
        required: false,
    }),
    __metadata("design:type", String)
], SendMessageResponseDto.prototype, "errorMessage", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送时间',
        example: '2023-12-25T10:00:00Z',
    }),
    __metadata("design:type", String)
], SendMessageResponseDto.prototype, "sentAt", void 0);
class SendBatchMessagesDto {
    openids;
    templateId;
    title;
    content;
    data;
    page;
    businessType;
}
exports.SendBatchMessagesDto = SendBatchMessagesDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId列表',
        example: ['oT8sGv0dAZWqB5jq7V_d-RM34xY8', 'oX8sGv0dAZWqB5jq7V_d-RM34xY9'],
    }),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", Array)
], SendBatchMessagesDto.prototype, "openids", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '订阅消息模板ID',
        example: '_xW4gC4c6DpWMvjqxQg-fXsWvKJ3NVLLzGAy0',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendBatchMessagesDto.prototype, "templateId", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息标题',
        example: '订单支付成功',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendBatchMessagesDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息内容',
        example: '您的订单已支付成功',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendBatchMessagesDto.prototype, "content", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息数据模板',
        example: {
            thing1: { value: '订单号{{orderId}}' },
            amount2: { value: '¥{{amount}}' },
        },
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Object)
], SendBatchMessagesDto.prototype, "data", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '点击消息跳转的页面路径',
        example: '/pages/order/list',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], SendBatchMessagesDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务类型',
        enum: ['order', 'payment', 'refund', 'delivery', 'system'],
        example: 'order',
        required: false,
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], SendBatchMessagesDto.prototype, "businessType", void 0);
class SendBatchMessagesResponseDto {
    successCount;
    failureCount;
    totalCount;
    details;
}
exports.SendBatchMessagesResponseDto = SendBatchMessagesResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '成功发送的消息数',
        example: 95,
    }),
    __metadata("design:type", Number)
], SendBatchMessagesResponseDto.prototype, "successCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送失败的消息数',
        example: 5,
    }),
    __metadata("design:type", Number)
], SendBatchMessagesResponseDto.prototype, "failureCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '总消息数',
        example: 100,
    }),
    __metadata("design:type", Number)
], SendBatchMessagesResponseDto.prototype, "totalCount", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息发送详情',
        example: [
            { openid: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8', status: 'sent', msgId: '123456' },
            { openid: 'oX8sGv0dAZWqB5jq7V_d-RM34xY9', status: 'failed', error: 'Invalid template' },
        ],
    }),
    __metadata("design:type", Array)
], SendBatchMessagesResponseDto.prototype, "details", void 0);
class GetNotificationRecordsDto {
    openid;
    notificationType;
    status;
    page;
    limit;
}
exports.GetNotificationRecordsDto = GetNotificationRecordsDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '用户openId',
        example: 'oT8sGv0dAZWqB5jq7V_d-RM34xY8',
    }),
    (0, class_validator_1.IsString)(),
    (0, class_validator_1.IsNotEmpty)(),
    __metadata("design:type", String)
], GetNotificationRecordsDto.prototype, "openid", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '通知类型筛选',
        enum: ['template', 'subscribe', 'uniform', 'all'],
        example: 'subscribe',
        required: false,
    }),
    (0, class_validator_1.IsEnum)(['template', 'subscribe', 'uniform', 'all']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], GetNotificationRecordsDto.prototype, "notificationType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送状态筛选',
        enum: ['pending', 'sent', 'failed', 'read', 'all'],
        example: 'sent',
        required: false,
    }),
    (0, class_validator_1.IsEnum)(['pending', 'sent', 'failed', 'read', 'all']),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", String)
], GetNotificationRecordsDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '页码',
        example: 1,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], GetNotificationRecordsDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '每页数量',
        example: 10,
        required: false,
    }),
    (0, class_validator_1.IsOptional)(),
    __metadata("design:type", Number)
], GetNotificationRecordsDto.prototype, "limit", void 0);
class NotificationRecordDto {
    id;
    title;
    content;
    status;
    sentAt;
    readAt;
    businessType;
    businessId;
}
exports.NotificationRecordDto = NotificationRecordDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '记录ID',
        example: 1,
    }),
    __metadata("design:type", Number)
], NotificationRecordDto.prototype, "id", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息标题',
        example: '订单支付成功',
    }),
    __metadata("design:type", String)
], NotificationRecordDto.prototype, "title", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息内容',
        example: '您的订单已支付成功',
    }),
    __metadata("design:type", String)
], NotificationRecordDto.prototype, "content", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送状态',
        enum: ['pending', 'sent', 'failed', 'read'],
    }),
    __metadata("design:type", String)
], NotificationRecordDto.prototype, "status", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '发送时间',
        example: '2023-12-25T10:00:00Z',
    }),
    __metadata("design:type", Date)
], NotificationRecordDto.prototype, "sentAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '读取时间',
        example: '2023-12-25T10:05:00Z',
        required: false,
    }),
    __metadata("design:type", Date)
], NotificationRecordDto.prototype, "readAt", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务类型',
        example: 'order',
    }),
    __metadata("design:type", String)
], NotificationRecordDto.prototype, "businessType", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '业务ID',
        example: '123456',
    }),
    __metadata("design:type", String)
], NotificationRecordDto.prototype, "businessId", void 0);
class NotificationListResponseDto {
    total;
    page;
    limit;
    items;
}
exports.NotificationListResponseDto = NotificationListResponseDto;
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '总记录数',
        example: 100,
    }),
    __metadata("design:type", Number)
], NotificationListResponseDto.prototype, "total", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '当前页码',
        example: 1,
    }),
    __metadata("design:type", Number)
], NotificationListResponseDto.prototype, "page", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '每页数量',
        example: 10,
    }),
    __metadata("design:type", Number)
], NotificationListResponseDto.prototype, "limit", void 0);
__decorate([
    (0, swagger_1.ApiProperty)({
        description: '消息记录列表',
        type: [NotificationRecordDto],
    }),
    __metadata("design:type", Array)
], NotificationListResponseDto.prototype, "items", void 0);
//# sourceMappingURL=wechat-notification.dto.js.map