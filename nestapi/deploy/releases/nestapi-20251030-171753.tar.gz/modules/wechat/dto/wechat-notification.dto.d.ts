export declare class SendTemplateMessageDto {
    openid: string;
    templateId: string;
    title: string;
    data?: Record<string, any>;
    url?: string;
    businessId?: string;
    businessType?: string;
}
export declare class SendSubscribeMessageDto {
    openid: string;
    templateId: string;
    title: string;
    content: string;
    data?: Record<string, any>;
    page: string;
    appid?: string;
    businessId?: string;
    businessType?: string;
    immediate?: boolean;
    scheduledAt?: string;
}
export declare class SendMessageResponseDto {
    msgId: string;
    status: 'pending' | 'sent' | 'failed';
    errorMessage?: string;
    sentAt: string;
}
export declare class SendBatchMessagesDto {
    openids: string[];
    templateId: string;
    title: string;
    content: string;
    data?: Record<string, any>;
    page: string;
    businessType?: string;
}
export declare class SendBatchMessagesResponseDto {
    successCount: number;
    failureCount: number;
    totalCount: number;
    details?: Array<{
        openid: string;
        status: 'sent' | 'failed';
        msgId?: string;
        error?: string;
    }>;
}
export declare class GetNotificationRecordsDto {
    openid: string;
    notificationType?: 'template' | 'subscribe' | 'uniform' | 'all';
    status?: 'pending' | 'sent' | 'failed' | 'read' | 'all';
    page?: number;
    limit?: number;
}
export declare class NotificationRecordDto {
    id: number;
    title: string;
    content: string;
    status: string;
    sentAt: Date;
    readAt?: Date;
    businessType?: string;
    businessId?: string;
}
export declare class NotificationListResponseDto {
    total: number;
    page: number;
    limit: number;
    items: NotificationRecordDto[];
}
