import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { WechatNotificationEntity } from '../entities/wechat-notification.entity';
import { SendSubscribeMessageDto, SendMessageResponseDto, SendBatchMessagesDto, SendBatchMessagesResponseDto, GetNotificationRecordsDto, NotificationListResponseDto } from '../dto/wechat-notification.dto';
export declare class WechatNotificationService {
    private readonly notificationRepository;
    private configService;
    private readonly WECHAT_TOKEN_API;
    private readonly WECHAT_SUBSCRIBE_MESSAGE_API;
    private readonly appId;
    private readonly appSecret;
    private accessToken;
    private tokenExpireTime;
    constructor(notificationRepository: Repository<WechatNotificationEntity>, configService: ConfigService);
    getAccessToken(): Promise<string>;
    sendSubscribeMessage(dto: SendSubscribeMessageDto): Promise<SendMessageResponseDto>;
    sendBatchMessages(dto: SendBatchMessagesDto): Promise<SendBatchMessagesResponseDto>;
    getNotificationRecords(dto: GetNotificationRecordsDto): Promise<NotificationListResponseDto>;
    private formatMessageData;
    private mapToRecord;
    getNotificationDetail(id: number): Promise<WechatNotificationEntity>;
    markNotificationAsRead(id: number): Promise<void>;
    retryFailedNotification(id: number): Promise<SendMessageResponseDto>;
}
