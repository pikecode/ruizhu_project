"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatPaymentService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const crypto = __importStar(require("crypto"));
const xml2js = __importStar(require("xml2js"));
const axios_1 = __importDefault(require("axios"));
const wechat_payment_entity_1 = require("../entities/wechat-payment.entity");
let WechatPaymentService = class WechatPaymentService {
    paymentRepository;
    configService;
    WECHAT_PAY_API = 'https://api.mch.weixin.qq.com/pay';
    WECHAT_UNIFIED_ORDER = 'https://api.mch.weixin.qq.com/pay/unifiedorder';
    WECHAT_ORDER_QUERY = 'https://api.mch.weixin.qq.com/pay/orderquery';
    WECHAT_REFUND = 'https://api.mch.weixin.qq.com/secapi/pay/refund';
    appId;
    mchId;
    mchKey;
    notifyUrl;
    constructor(paymentRepository, configService) {
        this.paymentRepository = paymentRepository;
        this.configService = configService;
        this.appId = configService.get('WECHAT_APP_ID') || '';
        this.mchId = configService.get('WECHAT_MCH_ID', '');
        this.mchKey = configService.get('WECHAT_MCH_KEY', '');
        this.notifyUrl = configService.get('WECHAT_PAY_NOTIFY_URL', '');
    }
    async createUnifiedOrder(dto) {
        try {
            const nonceStr = this.generateNonceStr();
            const timeStamp = Math.floor(Date.now() / 1000).toString();
            const orderData = {
                appid: this.appId,
                mch_id: this.mchId,
                nonce_str: nonceStr,
                body: dto.body,
                detail: dto.detail || '',
                out_trade_no: dto.outTradeNo,
                total_fee: dto.totalFee,
                spbill_create_ip: '127.0.0.1',
                notify_url: this.notifyUrl,
                trade_type: 'JSAPI',
                openid: dto.openid,
            };
            const sign = this.generateSign(orderData);
            orderData['sign'] = sign;
            const xmlData = this.jsonToXml(orderData);
            const response = await axios_1.default.post(this.WECHAT_UNIFIED_ORDER, xmlData, {
                headers: { 'Content-Type': 'application/xml' },
            });
            const result = await this.parseXmlResponse(response.data);
            if (result.return_code !== 'SUCCESS') {
                throw new common_1.BadRequestException(`微信支付API错误: ${result.return_msg}`);
            }
            if (result.result_code !== 'SUCCESS') {
                throw new common_1.BadRequestException(`微信支付业务错误: ${result.err_code_des || result.err_code}`);
            }
            const payment = this.paymentRepository.create({
                openid: dto.openid,
                outTradeNo: dto.outTradeNo,
                prepayId: result.prepay_id,
                totalFee: dto.totalFee,
                body: dto.body,
                detail: dto.detail,
                status: 'pending',
                metadata: dto.metadata,
                remark: dto.remark,
            });
            await this.paymentRepository.save(payment);
            const paySign = this.generatePaySign(result.prepay_id, nonceStr, timeStamp);
            return {
                outTradeNo: dto.outTradeNo,
                prepayId: result.prepay_id,
                timeStamp,
                nonceStr,
                signType: 'MD5',
                paySign,
                totalFee: dto.totalFee,
                body: dto.body,
            };
        }
        catch (error) {
            throw new common_1.HttpException(`创建支付订单失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async handlePaymentCallback(callbackData) {
        try {
            if (!this.verifyCallbackSign(callbackData)) {
                throw new common_1.BadRequestException('回调签名验证失败');
            }
            const payment = await this.paymentRepository.findOne({
                where: { outTradeNo: callbackData.out_trade_no },
            });
            if (!payment) {
                throw new common_1.BadRequestException('找不到对应的支付记录');
            }
            if (callbackData.result_code === 'SUCCESS') {
                payment.status = 'success';
                payment.transactionId = callbackData.transaction_id || '';
                if (callbackData.time_end) {
                    payment.payTime = new Date(callbackData.time_end.replace(/(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/, '$1-$2-$3T$4:$5:$6Z'));
                }
            }
            else {
                payment.status = 'failed';
            }
            payment.wechatCallback = callbackData;
            await this.paymentRepository.save(payment);
        }
        catch (error) {
            throw new common_1.HttpException(`处理支付回调失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async queryOrderStatus(dto) {
        try {
            const payment = await this.paymentRepository.findOne({
                where: { outTradeNo: dto.tradeNo },
            });
            if (!payment) {
                throw new common_1.BadRequestException('找不到对应的支付记录');
            }
            if (payment.openid !== dto.openid) {
                throw new common_1.BadRequestException('用户信息不匹配');
            }
            return {
                outTradeNo: payment.outTradeNo,
                status: payment.status,
                totalFee: payment.totalFee,
                payTime: payment.payTime,
                transactionId: payment.transactionId,
            };
        }
        catch (error) {
            throw new common_1.HttpException(`查询订单状态失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async createRefund(dto) {
        try {
            const payment = await this.paymentRepository.findOne({
                where: { outTradeNo: dto.outTradeNo },
            });
            if (!payment) {
                throw new common_1.BadRequestException('找不到对应的支付记录');
            }
            if (payment.openid !== dto.openid) {
                throw new common_1.BadRequestException('用户信息不匹配');
            }
            if (payment.status !== 'success') {
                throw new common_1.BadRequestException('只有已支付的订单才能退款');
            }
            const refundNo = `REF${Date.now()}`;
            const refundFee = dto.refundFee || payment.totalFee;
            const nonceStr = this.generateNonceStr();
            const refundData = {
                appid: this.appId,
                mch_id: this.mchId,
                nonce_str: nonceStr,
                transaction_id: payment.transactionId || '',
                out_trade_no: dto.outTradeNo,
                out_refund_no: refundNo,
                total_fee: payment.totalFee,
                refund_fee: refundFee,
                refund_desc: dto.reason,
            };
            const sign = this.generateSign(refundData);
            refundData['sign'] = sign;
            const xmlData = this.jsonToXml(refundData);
            const response = await axios_1.default.post(this.WECHAT_REFUND, xmlData, {
                headers: { 'Content-Type': 'application/xml' },
            });
            const result = await this.parseXmlResponse(response.data);
            if (result.return_code !== 'SUCCESS') {
                throw new common_1.BadRequestException(`微信支付API错误: ${result.return_msg}`);
            }
            if (result.result_code !== 'SUCCESS') {
                throw new common_1.BadRequestException(`微信支付业务错误: ${result.err_code_des || result.err_code}`);
            }
            return {
                outTradeNo: dto.outTradeNo,
                status: 'processing',
                refundFee,
                refundId: result.refund_id,
            };
        }
        catch (error) {
            throw new common_1.HttpException(`发起退款失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    generateNonceStr() {
        return crypto.randomBytes(16).toString('hex');
    }
    generateSign(data) {
        const filteredData = Object.keys(data)
            .filter((key) => data[key] !== '' && key !== 'sign')
            .sort()
            .reduce((acc, key) => {
            acc[key] = data[key];
            return acc;
        }, {});
        let signStr = Object.keys(filteredData)
            .map((key) => `${key}=${filteredData[key]}`)
            .join('&');
        signStr += `&key=${this.mchKey}`;
        return crypto.createHash('md5').update(signStr, 'utf8').digest('hex').toUpperCase();
    }
    generatePaySign(prepayId, nonceStr, timeStamp) {
        const payData = {
            appId: this.appId,
            timeStamp,
            nonceStr,
            package: `prepay_id=${prepayId}`,
            signType: 'MD5',
        };
        let signStr = Object.keys(payData)
            .sort()
            .map((key) => `${key}=${payData[key]}`)
            .join('&');
        signStr += `&key=${this.mchKey}`;
        return crypto.createHash('md5').update(signStr, 'utf8').digest('hex').toUpperCase();
    }
    verifyCallbackSign(data) {
        const sign = data.sign;
        const filteredData = { ...data };
        delete filteredData.sign;
        const calculatedSign = this.generateSign(filteredData);
        return sign === calculatedSign;
    }
    jsonToXml(data) {
        let xml = '<xml>';
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                xml += `<${key}><![CDATA[${data[key]}]]></${key}>`;
            }
        }
        xml += '</xml>';
        return xml;
    }
    async parseXmlResponse(xmlStr) {
        const parser = new xml2js.Parser({
            explicitArray: false,
            ignoreAttrs: true,
        });
        const result = await parser.parseStringPromise(xmlStr);
        return result.xml;
    }
};
exports.WechatPaymentService = WechatPaymentService;
exports.WechatPaymentService = WechatPaymentService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(wechat_payment_entity_1.WechatPaymentEntity)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService])
], WechatPaymentService);
//# sourceMappingURL=wechat-payment.service.js.map