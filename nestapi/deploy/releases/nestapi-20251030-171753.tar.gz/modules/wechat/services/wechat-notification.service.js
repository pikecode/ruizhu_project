"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.WechatNotificationService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const config_1 = require("@nestjs/config");
const axios_1 = __importDefault(require("axios"));
const wechat_notification_entity_1 = require("../entities/wechat-notification.entity");
let WechatNotificationService = class WechatNotificationService {
    notificationRepository;
    configService;
    WECHAT_TOKEN_API = 'https://api.weixin.qq.com/cgi-bin/token';
    WECHAT_SUBSCRIBE_MESSAGE_API = 'https://api.weixin.qq.com/inservice/servicestate/getkf_online_list';
    appId;
    appSecret;
    accessToken = '';
    tokenExpireTime = 0;
    constructor(notificationRepository, configService) {
        this.notificationRepository = notificationRepository;
        this.configService = configService;
        this.appId = configService.get('WECHAT_APP_ID') || '';
        this.appSecret = configService.get('WECHAT_APP_SECRET') || '';
    }
    async getAccessToken() {
        const now = Date.now();
        if (this.accessToken && now < this.tokenExpireTime) {
            return this.accessToken;
        }
        try {
            const response = await axios_1.default.get(this.WECHAT_TOKEN_API, {
                params: {
                    grant_type: 'client_credential',
                    appid: this.appId,
                    secret: this.appSecret,
                },
            });
            const data = response.data;
            if (data.errcode) {
                throw new Error(`获取access_token失败: ${data.errmsg}`);
            }
            this.accessToken = data.access_token;
            this.tokenExpireTime = now + (data.expires_in - 200) * 1000;
            return this.accessToken;
        }
        catch (error) {
            throw new common_1.HttpException(`获取访问令牌失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async sendSubscribeMessage(dto) {
        try {
            const accessToken = await this.getAccessToken();
            const messageData = {
                touser: dto.openid,
                template_id: dto.templateId,
                page: dto.page,
                data: this.formatMessageData(dto.data),
                emphasis_keyword: 'keyword1',
            };
            const response = await axios_1.default.post(`https://api.weixin.qq.com/cgi-bin/message/subscribe/send?access_token=${accessToken}`, messageData);
            const data = response.data;
            if (data.errcode !== 0) {
                throw new Error(`发送订阅消息失败: ${data.errmsg}`);
            }
            const notification = this.notificationRepository.create({
                openid: dto.openid,
                notificationType: 'subscribe',
                templateId: dto.templateId,
                title: dto.title,
                content: dto.content,
                data: dto.data,
                page: dto.page,
                status: 'sent',
                businessId: dto.businessId,
                businessType: dto.businessType,
                msgId: data.msgid,
                wechatResponse: data,
                sentAt: new Date(),
            });
            await this.notificationRepository.save(notification);
            return {
                msgId: data.msgid || '',
                status: 'sent',
                sentAt: new Date().toISOString(),
            };
        }
        catch (error) {
            const notification = this.notificationRepository.create({
                openid: dto.openid,
                notificationType: 'subscribe',
                templateId: dto.templateId,
                title: dto.title,
                content: dto.content,
                data: dto.data,
                page: dto.page,
                status: 'failed',
                businessId: dto.businessId,
                businessType: dto.businessType,
                errorMessage: error.message,
            });
            await this.notificationRepository.save(notification);
            throw new common_1.HttpException(`发送订阅消息失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    async sendBatchMessages(dto) {
        const results = [];
        let successCount = 0;
        let failureCount = 0;
        const concurrencyLimit = 10;
        for (let i = 0; i < dto.openids.length; i += concurrencyLimit) {
            const batch = dto.openids.slice(i, i + concurrencyLimit);
            const batchPromises = batch.map((openid) => this.sendSubscribeMessage({
                ...dto,
                openid,
            })
                .then((result) => {
                successCount++;
                results.push({
                    openid,
                    status: 'sent',
                    msgId: result.msgId,
                });
            })
                .catch((error) => {
                failureCount++;
                results.push({
                    openid,
                    status: 'failed',
                    error: error.message,
                });
            }));
            await Promise.all(batchPromises);
        }
        return {
            successCount,
            failureCount,
            totalCount: dto.openids.length,
            details: results,
        };
    }
    async getNotificationRecords(dto) {
        try {
            const page = dto.page || 1;
            const limit = dto.limit || 10;
            const skip = (page - 1) * limit;
            let query = this.notificationRepository.createQueryBuilder('notification');
            query = query.where('notification.openid = :openid', { openid: dto.openid });
            if (dto.notificationType && dto.notificationType !== 'all') {
                query = query.andWhere('notification.notificationType = :notificationType', {
                    notificationType: dto.notificationType,
                });
            }
            if (dto.status && dto.status !== 'all') {
                query = query.andWhere('notification.status = :status', { status: dto.status });
            }
            const [items, total] = await query
                .orderBy('notification.createdAt', 'DESC')
                .skip(skip)
                .take(limit)
                .getManyAndCount();
            const records = items.map((item) => this.mapToRecord(item));
            return {
                total,
                page,
                limit,
                items: records,
            };
        }
        catch (error) {
            throw new common_1.HttpException(`获取通知记录失败: ${error.message}`, common_1.HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
    formatMessageData(data) {
        if (!data) {
            return {};
        }
        const formattedData = {};
        for (const key in data) {
            if (data.hasOwnProperty(key)) {
                formattedData[key] = {
                    value: String(data[key]),
                };
            }
        }
        return formattedData;
    }
    mapToRecord(entity) {
        return {
            id: entity.id,
            title: entity.title,
            content: entity.content,
            status: entity.status,
            sentAt: entity.sentAt,
            readAt: entity.readAt,
            businessType: entity.businessType,
            businessId: entity.businessId,
        };
    }
    async getNotificationDetail(id) {
        const notification = await this.notificationRepository.findOne({
            where: { id },
        });
        if (!notification) {
            throw new common_1.BadRequestException('找不到该通知记录');
        }
        return notification;
    }
    async markNotificationAsRead(id) {
        const notification = await this.notificationRepository.findOne({
            where: { id },
        });
        if (!notification) {
            throw new common_1.BadRequestException('找不到该通知记录');
        }
        notification.status = 'read';
        notification.readAt = new Date();
        await this.notificationRepository.save(notification);
    }
    async retryFailedNotification(id) {
        const notification = await this.getNotificationDetail(id);
        if (notification.status !== 'failed') {
            throw new common_1.BadRequestException('只有失败的消息才能重试');
        }
        if (notification.retryCount >= notification.maxRetries) {
            throw new common_1.BadRequestException('已达到最大重试次数');
        }
        try {
            const dto = {
                openid: notification.openid,
                templateId: notification.templateId,
                title: notification.title,
                content: notification.content,
                data: notification.data,
                page: notification.page,
                businessId: notification.businessId,
                businessType: notification.businessType,
            };
            const result = await this.sendSubscribeMessage(dto);
            notification.retryCount++;
            notification.status = 'sent';
            notification.msgId = result.msgId;
            notification.sentAt = new Date();
            notification.errorMessage = '';
            await this.notificationRepository.save(notification);
            return result;
        }
        catch (error) {
            notification.retryCount++;
            notification.errorMessage = error.message;
            await this.notificationRepository.save(notification);
            throw error;
        }
    }
};
exports.WechatNotificationService = WechatNotificationService;
exports.WechatNotificationService = WechatNotificationService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(wechat_notification_entity_1.WechatNotificationEntity)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        config_1.ConfigService])
], WechatNotificationService);
//# sourceMappingURL=wechat-notification.service.js.map