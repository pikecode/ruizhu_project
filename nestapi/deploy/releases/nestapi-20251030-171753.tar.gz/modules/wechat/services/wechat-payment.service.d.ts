import { Repository } from 'typeorm';
import { ConfigService } from '@nestjs/config';
import { WechatPaymentEntity } from '../entities/wechat-payment.entity';
import { CreateUnifiedOrderDto, CreatePaymentResponseDto, WechatPaymentCallbackDto, QueryOrderStatusDto, OrderStatusResponseDto, RefundRequestDto, RefundResponseDto } from '../dto/wechat-payment.dto';
export declare class WechatPaymentService {
    private readonly paymentRepository;
    private configService;
    private readonly WECHAT_PAY_API;
    private readonly WECHAT_UNIFIED_ORDER;
    private readonly WECHAT_ORDER_QUERY;
    private readonly WECHAT_REFUND;
    private readonly appId;
    private readonly mchId;
    private readonly mchKey;
    private readonly notifyUrl;
    constructor(paymentRepository: Repository<WechatPaymentEntity>, configService: ConfigService);
    createUnifiedOrder(dto: CreateUnifiedOrderDto): Promise<CreatePaymentResponseDto>;
    handlePaymentCallback(callbackData: WechatPaymentCallbackDto): Promise<void>;
    queryOrderStatus(dto: QueryOrderStatusDto): Promise<OrderStatusResponseDto>;
    createRefund(dto: RefundRequestDto): Promise<RefundResponseDto>;
    private generateNonceStr;
    private generateSign;
    private generatePaySign;
    private verifyCallbackSign;
    private jsonToXml;
    private parseXmlResponse;
}
