import { ProductsService } from './products.service';
import { CreateCompleteProductDto, QueryProductDto, UpdateProductDto } from './dto';
import { ProductDetailResponseDto, ProductListResponseDto, ProductListItemDto } from './dto/product-response.dto';
export declare class ProductsController {
    private readonly productsService;
    constructor(productsService: ProductsService);
    createProduct(createDto: CreateCompleteProductDto): Promise<{
        code: number;
        message: string;
        data: ProductDetailResponseDto;
    }>;
    getProductList(query: QueryProductDto): Promise<{
        code: number;
        message: string;
        data: ProductListResponseDto;
    }>;
    searchProducts(keyword: string, limit?: string): Promise<{
        code: number;
        message: string;
        data: ProductListItemDto[];
    }>;
    getHotProducts(limit?: string): Promise<{
        code: number;
        message: string;
        data: ProductListItemDto[];
    }>;
    getProductsByCategory(categoryId: number, limit?: string): Promise<{
        code: number;
        message: string;
        data: ProductListItemDto[];
    }>;
    getProductDetail(id: number): Promise<{
        code: number;
        message: string;
        data: ProductDetailResponseDto;
    }>;
    updateProduct(id: number, updateDto: UpdateProductDto): Promise<{
        code: number;
        message: string;
        data: ProductDetailResponseDto;
    }>;
    deleteProduct(id: number): Promise<void>;
}
