import { Repository } from 'typeorm';
import { Product, ProductTag } from '../../entities/product.entity';
import { Category } from '../../entities/category.entity';
import { CreateCompleteProductDto, QueryProductDto, UpdateProductDto } from './dto';
import { ProductDetailResponseDto, ProductListItemDto, ProductListResponseDto } from './dto/product-response.dto';
export declare class ProductsService {
    private readonly productRepository;
    private readonly tagRepository;
    private readonly categoryRepository;
    constructor(productRepository: Repository<Product>, tagRepository: Repository<ProductTag>, categoryRepository: Repository<Category>);
    private convertStockStatusToFlags;
    private convertFlagsToStockStatus;
    createProduct(createDto: CreateCompleteProductDto): Promise<ProductDetailResponseDto>;
    getProductDetail(productId: number): Promise<ProductDetailResponseDto>;
    getProductList(query: QueryProductDto): Promise<ProductListResponseDto>;
    updateProduct(productId: number, updateDto: UpdateProductDto): Promise<ProductDetailResponseDto>;
    deleteProduct(productId: number): Promise<void>;
    getProductsByCategory(categoryId: number, limit?: number): Promise<ProductListItemDto[]>;
    getHotProducts(limit?: number): Promise<ProductListItemDto[]>;
    searchProducts(keyword: string, limit?: number): Promise<ProductListItemDto[]>;
}
