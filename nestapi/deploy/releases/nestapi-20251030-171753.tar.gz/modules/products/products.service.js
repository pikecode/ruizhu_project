"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProductsService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const product_entity_1 = require("../../entities/product.entity");
const category_entity_1 = require("../../entities/category.entity");
let ProductsService = class ProductsService {
    productRepository;
    tagRepository;
    categoryRepository;
    constructor(productRepository, tagRepository, categoryRepository) {
        this.productRepository = productRepository;
        this.tagRepository = tagRepository;
        this.categoryRepository = categoryRepository;
    }
    convertStockStatusToFlags(stockStatus) {
        if (stockStatus === 'outOfStock') {
            return { isOutOfStock: true, isSoldOut: false };
        }
        else if (stockStatus === 'soldOut') {
            return { isOutOfStock: false, isSoldOut: true };
        }
        return { isOutOfStock: false, isSoldOut: false };
    }
    convertFlagsToStockStatus(isOutOfStock, isSoldOut) {
        if (isSoldOut) {
            return 'soldOut';
        }
        else if (isOutOfStock) {
            return 'outOfStock';
        }
        return 'normal';
    }
    async createProduct(createDto) {
        const category = await this.categoryRepository.findOne({
            where: { id: createDto.categoryId },
        });
        if (!category) {
            throw new common_1.BadRequestException(`分类 ID ${createDto.categoryId} 不存在`);
        }
        if (createDto.sku) {
            const existingProduct = await this.productRepository.findOne({
                where: { sku: createDto.sku },
            });
            if (existingProduct) {
                throw new common_1.BadRequestException(`SKU ${createDto.sku} 已存在`);
            }
        }
        let isOutOfStock = createDto.isOutOfStock || false;
        let isSoldOut = createDto.isSoldOut || false;
        if (createDto.stockStatus) {
            const converted = this.convertStockStatusToFlags(createDto.stockStatus);
            isOutOfStock = converted.isOutOfStock;
            isSoldOut = converted.isSoldOut;
        }
        const product = this.productRepository.create({
            name: createDto.name,
            subtitle: createDto.subtitle,
            sku: createDto.sku,
            description: createDto.description,
            categoryId: createDto.categoryId,
            isNew: createDto.isNew || false,
            isSaleOn: createDto.isSaleOn !== false,
            isOutOfStock,
            isSoldOut,
            isVipOnly: createDto.isVipOnly || false,
            stockQuantity: createDto.stockQuantity || 0,
            lowStockThreshold: createDto.lowStockThreshold || 10,
            weight: createDto.weight,
            shippingTemplateId: createDto.shippingTemplateId,
            freeShippingThreshold: createDto.freeShippingThreshold,
            originalPrice: createDto.price.originalPrice ?? null,
            currentPrice: createDto.price.currentPrice ?? null,
            discountRate: createDto.price.discountRate || 100,
            currency: createDto.price.currency || 'CNY',
            vipDiscountRate: createDto.price.vipDiscountRate ?? null,
            coverImageUrl: createDto.url || createDto.coverImageUrl || null,
        });
        const savedProduct = await this.productRepository.save(product);
        return this.getProductDetail(savedProduct.id);
    }
    async getProductDetail(productId) {
        const product = await this.productRepository.findOne({
            where: { id: productId },
        });
        if (!product) {
            throw new common_1.NotFoundException(`商品 ID ${productId} 不存在`);
        }
        const tags = await this.tagRepository.find({ where: { productId } });
        const category = await this.categoryRepository.findOne({
            where: { id: product.categoryId },
        });
        product.viewsCount += 1;
        await this.productRepository.save(product);
        const stockStatus = this.convertFlagsToStockStatus(product.isOutOfStock, product.isSoldOut);
        return {
            id: product.id,
            name: product.name,
            subtitle: product.subtitle,
            sku: product.sku,
            description: product.description,
            categoryId: product.categoryId,
            categoryName: category?.name,
            isNew: product.isNew,
            isSaleOn: product.isSaleOn,
            isOutOfStock: product.isOutOfStock,
            isSoldOut: product.isSoldOut,
            isVipOnly: product.isVipOnly,
            stockStatus,
            stockQuantity: product.stockQuantity,
            lowStockThreshold: product.lowStockThreshold,
            weight: product.weight,
            shippingTemplateId: product.shippingTemplateId,
            freeShippingThreshold: product.freeShippingThreshold,
            coverImageUrl: product.coverImageUrl,
            price: {
                originalPrice: product.originalPrice ?? undefined,
                currentPrice: product.currentPrice ?? undefined,
                discountRate: product.discountRate,
                currency: product.currency,
                vipDiscountRate: product.vipDiscountRate ?? undefined,
            },
            stats: {
                salesCount: product.salesCount,
                viewsCount: product.viewsCount,
                averageRating: product.averageRating,
                reviewsCount: product.reviewsCount,
                favoritesCount: product.favoritesCount,
                conversionRate: product.conversionRate ?? undefined,
            },
            tags: tags.map((tag) => ({
                id: tag.id,
                tagName: tag.tagName,
            })),
            createdAt: product.createdAt,
            updatedAt: product.updatedAt,
        };
    }
    async getProductList(query) {
        const { page, limit, keyword, categoryId, minPrice, maxPrice, sort, isNew, onSale, tag } = query;
        let where = {};
        if (keyword) {
            where = {
                ...where,
                name: (0, typeorm_2.Like)(`%${keyword}%`),
            };
        }
        if (categoryId) {
            where.categoryId = categoryId;
        }
        if (isNew === 'true') {
            where.isNew = true;
        }
        if (onSale === 'false') {
            where.isSaleOn = false;
        }
        else if (onSale === 'true') {
            where.isSaleOn = true;
        }
        const skip = (page - 1) * limit;
        let query_obj = this.productRepository.createQueryBuilder('product')
            .leftJoinAndSelect('product.tags', 'tags');
        Object.entries(where).forEach(([key, value]) => {
            query_obj = query_obj.andWhere(`product.${key} = :${key}`, { [key]: value });
        });
        if (minPrice || maxPrice) {
            if (minPrice && maxPrice) {
                query_obj = query_obj.andWhere('product.currentPrice BETWEEN :minPrice AND :maxPrice', {
                    minPrice,
                    maxPrice,
                });
            }
            else if (minPrice) {
                query_obj = query_obj.andWhere('product.currentPrice >= :minPrice', { minPrice });
            }
            else if (maxPrice) {
                query_obj = query_obj.andWhere('product.currentPrice <= :maxPrice', { maxPrice });
            }
        }
        if (tag) {
            query_obj = query_obj.andWhere('tags.tagName = :tag', { tag });
        }
        let orderBy = 'product.createdAt';
        let orderDir = 'DESC';
        if (sort === 'price') {
            orderBy = 'product.currentPrice';
            orderDir = 'ASC';
        }
        else if (sort === '-price') {
            orderBy = 'product.currentPrice';
            orderDir = 'DESC';
        }
        else if (sort === 'sales') {
            orderBy = 'product.salesCount';
            orderDir = 'ASC';
        }
        else if (sort === '-sales') {
            orderBy = 'product.salesCount';
            orderDir = 'DESC';
        }
        else if (sort === 'rating') {
            orderBy = 'product.averageRating';
            orderDir = 'ASC';
        }
        else if (sort === '-rating') {
            orderBy = 'product.averageRating';
            orderDir = 'DESC';
        }
        else if (sort === '-created') {
            orderBy = 'product.createdAt';
            orderDir = 'DESC';
        }
        query_obj = query_obj.orderBy(orderBy, orderDir);
        query_obj = query_obj.skip(skip).take(limit);
        const [products, total] = await query_obj.getManyAndCount();
        const items = products.map((product) => {
            const stockStatus = this.convertFlagsToStockStatus(product.isOutOfStock, product.isSoldOut);
            return {
                id: product.id,
                name: product.name,
                subtitle: product.subtitle,
                sku: product.sku,
                categoryId: product.categoryId,
                currentPrice: product.currentPrice || 0,
                originalPrice: product.originalPrice || 0,
                discountRate: product.discountRate || 100,
                salesCount: product.salesCount || 0,
                averageRating: product.averageRating || 0,
                reviewsCount: product.reviewsCount || 0,
                isNew: product.isNew,
                isSaleOn: product.isSaleOn,
                isOutOfStock: product.isOutOfStock,
                isVipOnly: product.isVipOnly,
                stockStatus,
                stockQuantity: product.stockQuantity,
                coverImageUrl: product.coverImageUrl,
                coverImageId: product.coverImageId,
                tags: product.tags?.map((tag) => tag.tagName),
                createdAt: product.createdAt,
            };
        });
        return {
            items,
            total,
            page,
            limit,
            pages: Math.ceil(total / limit),
        };
    }
    async updateProduct(productId, updateDto) {
        const product = await this.productRepository.findOne({
            where: { id: productId },
        });
        if (!product) {
            throw new common_1.NotFoundException(`商品 ID ${productId} 不存在`);
        }
        if (updateDto.categoryId) {
            const category = await this.categoryRepository.findOne({
                where: { id: updateDto.categoryId },
            });
            if (!category) {
                throw new common_1.BadRequestException(`分类 ID ${updateDto.categoryId} 不存在`);
            }
        }
        const { url, coverImageUrl, stockStatus, ...otherUpdateData } = updateDto;
        if (stockStatus) {
            const converted = this.convertStockStatusToFlags(stockStatus);
            otherUpdateData.isOutOfStock = converted.isOutOfStock;
            otherUpdateData.isSoldOut = converted.isSoldOut;
        }
        const allowedFields = [
            'name', 'subtitle', 'sku', 'description', 'categoryId',
            'isNew', 'isSaleOn', 'isOutOfStock', 'isSoldOut', 'isVipOnly',
            'stockQuantity', 'lowStockThreshold', 'weight', 'shippingTemplateId',
            'freeShippingThreshold'
        ];
        const filteredUpdateData = {};
        allowedFields.forEach(field => {
            if (field in otherUpdateData) {
                filteredUpdateData[field] = otherUpdateData[field];
            }
        });
        Object.assign(product, filteredUpdateData);
        if (url) {
            product.coverImageUrl = url;
        }
        else if (coverImageUrl) {
            product.coverImageUrl = coverImageUrl;
        }
        if (updateDto.price) {
            product.originalPrice = updateDto.price.originalPrice ?? null;
            product.currentPrice = updateDto.price.currentPrice ?? null;
            product.discountRate = updateDto.price.discountRate || 100;
            product.currency = updateDto.price.currency || 'CNY';
            product.vipDiscountRate = updateDto.price.vipDiscountRate ?? null;
        }
        await this.productRepository.save(product);
        return this.getProductDetail(productId);
    }
    async deleteProduct(productId) {
        const product = await this.productRepository.findOne({
            where: { id: productId },
        });
        if (!product) {
            throw new common_1.NotFoundException(`商品 ID ${productId} 不存在`);
        }
        await this.productRepository.remove(product);
    }
    async getProductsByCategory(categoryId, limit = 12) {
        const products = await this.productRepository
            .createQueryBuilder('product')
            .leftJoinAndSelect('product.tags', 'tags')
            .where('product.categoryId = :categoryId', { categoryId })
            .andWhere('product.isSaleOn = :isSaleOn', { isSaleOn: true })
            .orderBy('product.createdAt', 'DESC')
            .take(limit)
            .getMany();
        return products.map((product) => {
            const stockStatus = this.convertFlagsToStockStatus(product.isOutOfStock, product.isSoldOut);
            return {
                id: product.id,
                name: product.name,
                subtitle: product.subtitle,
                sku: product.sku,
                categoryId: product.categoryId,
                currentPrice: product.currentPrice || 0,
                originalPrice: product.originalPrice || 0,
                discountRate: product.discountRate || 100,
                salesCount: product.salesCount || 0,
                averageRating: product.averageRating || 0,
                reviewsCount: product.reviewsCount || 0,
                isNew: product.isNew,
                isSaleOn: product.isSaleOn,
                isOutOfStock: product.isOutOfStock,
                isVipOnly: product.isVipOnly,
                stockStatus,
                stockQuantity: product.stockQuantity,
                coverImageUrl: product.coverImageUrl,
                coverImageId: product.coverImageId,
                tags: product.tags?.map((tag) => tag.tagName),
                createdAt: product.createdAt,
            };
        });
    }
    async getHotProducts(limit = 10) {
        const products = await this.productRepository
            .createQueryBuilder('product')
            .where('product.isSaleOn = :isSaleOn', { isSaleOn: true })
            .orderBy('product.salesCount', 'DESC')
            .take(limit)
            .getMany();
        return products.map((product) => {
            const stockStatus = this.convertFlagsToStockStatus(product.isOutOfStock, product.isSoldOut);
            return {
                id: product.id,
                name: product.name,
                subtitle: product.subtitle,
                sku: product.sku,
                categoryId: product.categoryId,
                currentPrice: product.currentPrice || 0,
                originalPrice: product.originalPrice || 0,
                discountRate: product.discountRate || 100,
                salesCount: product.salesCount || 0,
                averageRating: product.averageRating || 0,
                reviewsCount: product.reviewsCount || 0,
                isNew: product.isNew,
                isSaleOn: product.isSaleOn,
                isOutOfStock: product.isOutOfStock,
                isVipOnly: product.isVipOnly,
                stockStatus,
                stockQuantity: product.stockQuantity,
                coverImageUrl: product.coverImageUrl,
                coverImageId: product.coverImageId,
                createdAt: product.createdAt,
            };
        });
    }
    async searchProducts(keyword, limit = 20) {
        const products = await this.productRepository
            .createQueryBuilder('product')
            .where('product.name LIKE :keyword OR product.description LIKE :keyword', {
            keyword: `%${keyword}%`,
        })
            .andWhere('product.isSaleOn = :isSaleOn', { isSaleOn: true })
            .orderBy('product.createdAt', 'DESC')
            .take(limit)
            .getMany();
        return products.map((product) => {
            const stockStatus = this.convertFlagsToStockStatus(product.isOutOfStock, product.isSoldOut);
            return {
                id: product.id,
                name: product.name,
                subtitle: product.subtitle,
                sku: product.sku,
                categoryId: product.categoryId,
                currentPrice: product.currentPrice || 0,
                originalPrice: product.originalPrice || 0,
                discountRate: product.discountRate || 100,
                salesCount: product.salesCount || 0,
                averageRating: product.averageRating || 0,
                reviewsCount: product.reviewsCount || 0,
                isNew: product.isNew,
                isSaleOn: product.isSaleOn,
                isOutOfStock: product.isOutOfStock,
                isVipOnly: product.isVipOnly,
                stockStatus,
                stockQuantity: product.stockQuantity,
                coverImageUrl: product.coverImageUrl,
                coverImageId: product.coverImageId,
                createdAt: product.createdAt,
            };
        });
    }
};
exports.ProductsService = ProductsService;
exports.ProductsService = ProductsService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(product_entity_1.Product)),
    __param(1, (0, typeorm_1.InjectRepository)(product_entity_1.ProductTag)),
    __param(2, (0, typeorm_1.InjectRepository)(category_entity_1.Category)),
    __metadata("design:paramtypes", [typeorm_2.Repository,
        typeorm_2.Repository,
        typeorm_2.Repository])
], ProductsService);
//# sourceMappingURL=products.service.js.map