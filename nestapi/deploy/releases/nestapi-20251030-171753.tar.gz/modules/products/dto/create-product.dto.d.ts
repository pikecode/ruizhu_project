export declare class CreateProductDto {
    name: string;
    subtitle?: string;
    sku?: string;
    description?: string;
    categoryId: number;
    stockStatus?: 'normal' | 'outOfStock' | 'soldOut';
    isOutOfStock?: boolean;
    isSoldOut?: boolean;
    isNew?: boolean;
    isSaleOn?: boolean;
    isVipOnly?: boolean;
    stockQuantity?: number;
    lowStockThreshold?: number;
    weight?: number;
    shippingTemplateId?: number;
    freeShippingThreshold?: number;
}
export declare class CreateProductPriceDto {
    originalPrice: number;
    currentPrice: number;
    discountRate?: number;
    currency?: string;
    vipDiscountRate?: number;
}
export declare class CreateCompleteProductDto extends CreateProductDto {
    price: CreateProductPriceDto;
    url?: string;
    coverImageUrl?: string;
}
