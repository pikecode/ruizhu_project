"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UpdateProductDto = exports.ProductListResponseDto = exports.ProductListItemDto = exports.ProductDetailResponseDto = void 0;
class ProductDetailResponseDto {
    id;
    name;
    subtitle;
    sku;
    description;
    categoryId;
    categoryName;
    isNew;
    isSaleOn;
    isOutOfStock;
    isSoldOut;
    isVipOnly;
    stockStatus;
    stockQuantity;
    lowStockThreshold;
    weight;
    shippingTemplateId;
    freeShippingThreshold;
    coverImageUrl;
    price;
    stats;
    tags;
    createdAt;
    updatedAt;
}
exports.ProductDetailResponseDto = ProductDetailResponseDto;
class ProductListItemDto {
    id;
    name;
    subtitle;
    sku;
    categoryId;
    currentPrice;
    originalPrice;
    discountRate;
    salesCount;
    averageRating;
    reviewsCount;
    isNew;
    isSaleOn;
    isOutOfStock;
    isVipOnly;
    stockStatus;
    stockQuantity;
    coverImageUrl;
    tags;
    createdAt;
}
exports.ProductListItemDto = ProductListItemDto;
class ProductListResponseDto {
    items;
    total;
    page;
    limit;
    pages;
}
exports.ProductListResponseDto = ProductListResponseDto;
const class_validator_1 = require("class-validator");
const class_transformer_1 = require("class-transformer");
class UpdateProductDto {
    name;
    subtitle;
    sku;
    description;
    categoryId;
    stockStatus;
    isOutOfStock;
    isSoldOut;
    isNew;
    isSaleOn;
    isVipOnly;
    stockQuantity;
    lowStockThreshold;
    weight;
    shippingTemplateId;
    freeShippingThreshold;
    price;
    url;
    coverImageUrl;
}
exports.UpdateProductDto = UpdateProductDto;
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "name", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "subtitle", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "sku", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "description", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "categoryId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsIn)(['normal', 'outOfStock', 'soldOut'], { message: '库存状态必须是 normal、outOfStock 或 soldOut 之一' }),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "stockStatus", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined)
            return undefined;
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'string')
            return value.toLowerCase() === 'true' || value === '1';
        if (typeof value === 'number')
            return value === 1;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateProductDto.prototype, "isOutOfStock", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined)
            return undefined;
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'string')
            return value.toLowerCase() === 'true' || value === '1';
        if (typeof value === 'number')
            return value === 1;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateProductDto.prototype, "isSoldOut", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined)
            return undefined;
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'string')
            return value.toLowerCase() === 'true' || value === '1';
        if (typeof value === 'number')
            return value === 1;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateProductDto.prototype, "isNew", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined)
            return undefined;
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'string')
            return value.toLowerCase() === 'true' || value === '1';
        if (typeof value === 'number')
            return value === 1;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateProductDto.prototype, "isSaleOn", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_transformer_1.Transform)(({ value }) => {
        if (value === null || value === undefined)
            return undefined;
        if (typeof value === 'boolean')
            return value;
        if (typeof value === 'string')
            return value.toLowerCase() === 'true' || value === '1';
        if (typeof value === 'number')
            return value === 1;
        return value;
    }),
    (0, class_validator_1.IsBoolean)(),
    __metadata("design:type", Boolean)
], UpdateProductDto.prototype, "isVipOnly", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "stockQuantity", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "lowStockThreshold", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "weight", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "shippingTemplateId", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsNumber)(),
    __metadata("design:type", Number)
], UpdateProductDto.prototype, "freeShippingThreshold", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.ValidateNested)(),
    (0, class_transformer_1.Type)(() => Object),
    __metadata("design:type", Object)
], UpdateProductDto.prototype, "price", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "url", void 0);
__decorate([
    (0, class_validator_1.IsOptional)(),
    (0, class_validator_1.IsString)(),
    __metadata("design:type", String)
], UpdateProductDto.prototype, "coverImageUrl", void 0);
//# sourceMappingURL=product-response.dto.js.map