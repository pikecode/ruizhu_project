export declare class ProductDetailResponseDto {
    id: number;
    name: string;
    subtitle?: string;
    sku?: string | null;
    description?: string;
    categoryId: number;
    categoryName?: string;
    isNew: boolean;
    isSaleOn: boolean;
    isOutOfStock: boolean;
    isSoldOut: boolean;
    isVipOnly: boolean;
    stockStatus?: 'normal' | 'outOfStock' | 'soldOut';
    stockQuantity: number;
    lowStockThreshold: number;
    weight?: number;
    shippingTemplateId?: number;
    freeShippingThreshold?: number;
    coverImageUrl?: string | null;
    price?: {
        id?: number;
        originalPrice?: number;
        currentPrice?: number;
        discountRate?: number;
        currency?: string;
        vipDiscountRate?: number;
    };
    stats?: {
        salesCount: number;
        viewsCount: number;
        averageRating: number;
        reviewsCount: number;
        favoritesCount: number;
        conversionRate?: number;
    };
    tags: Array<{
        id: number;
        tagName: string;
    }>;
    createdAt: Date;
    updatedAt: Date;
}
export declare class ProductListItemDto {
    id: number;
    name: string;
    subtitle?: string;
    sku?: string | null;
    categoryId: number;
    currentPrice: number;
    originalPrice: number;
    discountRate: number;
    salesCount: number;
    averageRating: number;
    reviewsCount: number;
    isNew: boolean;
    isSaleOn: boolean;
    isOutOfStock: boolean;
    isVipOnly: boolean;
    stockStatus?: 'normal' | 'outOfStock' | 'soldOut';
    stockQuantity: number;
    coverImageUrl?: string | null;
    tags?: string[];
    createdAt: Date;
}
export declare class ProductListResponseDto {
    items: ProductListItemDto[];
    total: number;
    page: number;
    limit: number;
    pages: number;
}
export declare class UpdateProductDto {
    name?: string;
    subtitle?: string;
    sku?: string;
    description?: string;
    categoryId?: number;
    stockStatus?: 'normal' | 'outOfStock' | 'soldOut';
    isOutOfStock?: boolean;
    isSoldOut?: boolean;
    isNew?: boolean;
    isSaleOn?: boolean;
    isVipOnly?: boolean;
    stockQuantity?: number;
    lowStockThreshold?: number;
    weight?: number;
    shippingTemplateId?: number;
    freeShippingThreshold?: number;
    price?: {
        originalPrice?: number;
        currentPrice?: number;
        discountRate?: number;
        currency?: string;
        vipDiscountRate?: number;
    };
    url?: string;
    coverImageUrl?: string;
}
