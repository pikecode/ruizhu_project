export declare class QueryProductDto {
    page: number;
    limit: number;
    keyword?: string;
    categoryId?: number;
    minPrice?: number;
    maxPrice?: number;
    sort?: string;
    isNew?: string;
    onSale?: string;
    isOutOfStock?: string;
    tag?: string;
}
