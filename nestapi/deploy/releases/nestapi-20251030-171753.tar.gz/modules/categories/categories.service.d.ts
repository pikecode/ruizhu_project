import { Repository } from 'typeorm';
import { Category } from '../../entities/category.entity';
export declare class CategoriesService {
    private readonly categoryRepository;
    constructor(categoryRepository: Repository<Category>);
    getAllCategories(): Promise<Category[]>;
    getCategoryById(id: number): Promise<Category>;
    createCategory(data: {
        name: string;
        slug: string;
        description?: string;
        iconUrl?: string;
        sortOrder?: number;
        parentId?: number;
    }): Promise<Category>;
    updateCategory(id: number, data: {
        name?: string;
        slug?: string;
        description?: string;
        iconUrl?: string;
        sortOrder?: number;
        isActive?: boolean;
    }): Promise<Category>;
    deleteCategory(id: number): Promise<Category>;
    getSubcategories(parentId: number): Promise<Category[]>;
}
