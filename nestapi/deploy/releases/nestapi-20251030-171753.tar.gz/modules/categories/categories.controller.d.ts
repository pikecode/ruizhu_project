import { CategoriesService } from './categories.service';
export declare class CategoriesController {
    private readonly categoriesService;
    constructor(categoriesService: CategoriesService);
    getAllCategories(): Promise<{
        code: number;
        message: string;
        data: any[];
    }>;
    getCategoryById(id: number): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    getSubcategories(id: number): Promise<{
        code: number;
        message: string;
        data: any[];
    }>;
    createCategory(data: {
        name: string;
        slug: string;
        description?: string;
        iconUrl?: string;
        sortOrder?: number;
        parentId?: number;
    }): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    updateCategory(id: number, data: {
        name?: string;
        slug?: string;
        description?: string;
        iconUrl?: string;
        sortOrder?: number;
        isActive?: boolean;
    }): Promise<{
        code: number;
        message: string;
        data: any;
    }>;
    deleteCategory(id: number): Promise<void>;
}
