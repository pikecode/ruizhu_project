import { ConfigService } from '@nestjs/config';
import { CosService } from '../../common/services/cos.service';
export interface MediaUploadResponse {
    key: string;
    type: 'image' | 'video';
    size: number;
    width?: number;
    height?: number;
    url?: string;
}
export interface COSCredentials {
    cosUrl: string;
    bucket: string;
    region: string;
    credentials: {
        sessionToken: string;
        tmpSecretId: string;
        tmpSecretKey: string;
    };
    expiredTime: number;
}
export declare class MediaService {
    private configService;
    private cosService;
    constructor(configService: ConfigService, cosService: CosService);
    getUploadCredentials(): Promise<COSCredentials>;
    generateSignedUrl(key: string, expiresIn?: number): string;
    uploadMedia(file: any, type: 'image' | 'video'): Promise<MediaUploadResponse>;
    deleteMedia(mediaUrl: string): Promise<void>;
    getImageInfo(imageUrl: string): Promise<{
        width: number;
        height: number;
    }>;
    generateThumbnail(mediaUrl: string, width?: number, height?: number): Promise<string>;
}
