export declare class MediaModule {
}
