"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MediaService = void 0;
const common_1 = require("@nestjs/common");
const config_1 = require("@nestjs/config");
const cos_service_1 = require("../../common/services/cos.service");
let MediaService = class MediaService {
    configService;
    cosService;
    constructor(configService, cosService) {
        this.configService = configService;
        this.cosService = cosService;
    }
    async getUploadCredentials() {
        const bucket = this.configService.get('COS_BUCKET', 'ruizhu-1256655507');
        const region = this.configService.get('COS_REGION', 'ap-guangzhou');
        const secretId = this.configService.get('COS_SECRET_ID') || '';
        const secretKey = this.configService.get('COS_SECRET_KEY') || '';
        const cosUrl = `https://${bucket}.cos.${region}.myqcloud.com`;
        return {
            cosUrl,
            bucket,
            region,
            credentials: {
                sessionToken: '',
                tmpSecretId: secretId,
                tmpSecretKey: secretKey,
            },
            expiredTime: Math.floor(Date.now() / 1000) + 3600 * 24 * 7,
        };
    }
    generateSignedUrl(key, expiresIn = 3600) {
        return this.cosService.generateUrl(key);
    }
    async uploadMedia(file, type) {
        if (!file) {
            throw new Error('No file provided');
        }
        try {
            const uploadResult = await this.cosService.uploadFile(file.buffer, file.originalname, 'products');
            let width;
            let height;
            if (type === 'image') {
                width = 1920;
                height = 1080;
            }
            return {
                key: uploadResult.key,
                type,
                size: uploadResult.size,
                width,
                height,
                url: this.cosService.generateUrl(uploadResult.key),
            };
        }
        catch (error) {
            console.error('Media upload error:', error);
            throw new Error(`Upload failed: ${error.message}`);
        }
    }
    async deleteMedia(mediaUrl) {
        try {
            await this.cosService.deleteFile(mediaUrl);
        }
        catch (error) {
            console.error('Delete media error:', error);
        }
    }
    async getImageInfo(imageUrl) {
        return {
            width: 1920,
            height: 1080,
        };
    }
    async generateThumbnail(mediaUrl, width = 200, height = 200) {
        return mediaUrl;
    }
};
exports.MediaService = MediaService;
exports.MediaService = MediaService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [config_1.ConfigService,
        cos_service_1.CosService])
], MediaService);
//# sourceMappingURL=media.service.js.map