import { MediaService } from './media.service';
export declare class MediaController {
    private readonly mediaService;
    constructor(mediaService: MediaService);
    getCOSCredentials(): Promise<{
        code: number;
        message: string;
        data: import("./media.service").COSCredentials;
    }>;
    uploadMedia(file: any, body: {
        type?: 'image' | 'video';
    }): Promise<{
        code: number;
        message: string;
        data: import("./media.service").MediaUploadResponse;
    }>;
    deleteMedia(body: {
        url: string;
    }): Promise<{
        code: number;
        message: string;
    }>;
    getImageInfo(body: {
        url: string;
    }): Promise<{
        code: number;
        message: string;
        data: {
            width: number;
            height: number;
        };
    }>;
    generateThumbnail(body: {
        url: string;
        width?: number;
        height?: number;
    }): Promise<{
        code: number;
        message: string;
        data: {
            thumbnailUrl: string;
        };
    }>;
}
