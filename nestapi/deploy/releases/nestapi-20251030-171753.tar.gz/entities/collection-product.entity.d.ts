import { Collection } from './collection.entity';
export declare class CollectionProduct {
    id: number;
    collectionId: number;
    productId: number;
    sortOrder: number;
    createdAt: Date;
    collection: Collection;
}
