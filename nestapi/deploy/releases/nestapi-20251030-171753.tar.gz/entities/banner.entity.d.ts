export declare class Banner {
    id: number;
    mainTitle: string;
    subtitle: string | null;
    description: string | null;
    type: 'image' | 'video';
    imageUrl: string | null;
    imageKey: string | null;
    videoUrl: string | null;
    videoKey: string | null;
    videoThumbnailUrl: string | null;
    videoThumbnailKey: string | null;
    pageType: 'home' | 'custom';
    isActive: boolean;
    sortOrder: number;
    linkType: 'none' | 'product' | 'category' | 'collection' | 'url';
    linkValue: string | null;
    createdAt: Date;
    updatedAt: Date;
}
