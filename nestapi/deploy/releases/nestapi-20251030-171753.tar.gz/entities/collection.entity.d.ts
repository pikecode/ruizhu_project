import { CollectionProduct } from './collection-product.entity';
export declare class Collection {
    id: number;
    name: string;
    slug: string;
    description: string;
    coverImageUrl: string | null;
    iconUrl: string | null;
    sortOrder: number;
    isActive: boolean;
    isFeatured: boolean;
    remark: string;
    collectionProducts: CollectionProduct[];
    createdAt: Date;
    updatedAt: Date;
}
