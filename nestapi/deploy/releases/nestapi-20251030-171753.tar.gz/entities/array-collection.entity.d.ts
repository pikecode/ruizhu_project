import { ArrayCollectionItem } from './array-collection-item.entity';
export declare class ArrayCollection {
    id: number;
    title: string;
    description: string;
    sortOrder: number;
    isActive: boolean;
    remark: string;
    items: ArrayCollectionItem[];
    createdAt: Date;
    updatedAt: Date;
}
