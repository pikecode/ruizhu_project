export declare class User {
    id: number;
    phone: string | null;
    openId: string | null;
    username: string | null;
    email: string | null;
    password: string | null;
    nickname: string | null;
    avatarUrl: string | null;
    gender: 'male' | 'female' | 'unknown';
    province: string | null;
    city: string | null;
    country: string | null;
    isPhoneAuthorized: boolean;
    isProfileAuthorized: boolean;
    status: 'active' | 'banned' | 'deleted';
    registrationSource: 'wechat_mini_program' | 'web' | 'admin';
    lastLoginAt: Date | null;
    lastLoginIp: string | null;
    loginCount: number;
    createdAt: Date;
    updatedAt: Date;
}
