"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CollectionProduct = void 0;
const typeorm_1 = require("typeorm");
const collection_entity_1 = require("./collection.entity");
let CollectionProduct = class CollectionProduct {
    id;
    collectionId;
    productId;
    sortOrder;
    createdAt;
    collection;
};
exports.CollectionProduct = CollectionProduct;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], CollectionProduct.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'collection_id' }),
    __metadata("design:type", Number)
], CollectionProduct.prototype, "collectionId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], CollectionProduct.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sort_order' }),
    __metadata("design:type", Number)
], CollectionProduct.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], CollectionProduct.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)(() => collection_entity_1.Collection, (collection) => collection.collectionProducts, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'collection_id' }),
    __metadata("design:type", collection_entity_1.Collection)
], CollectionProduct.prototype, "collection", void 0);
exports.CollectionProduct = CollectionProduct = __decorate([
    (0, typeorm_1.Entity)('collection_products'),
    (0, typeorm_1.Unique)(['collectionId', 'productId']),
    (0, typeorm_1.Index)(['collectionId', 'sortOrder']),
    (0, typeorm_1.Index)(['productId'])
], CollectionProduct);
//# sourceMappingURL=collection-product.entity.js.map