import { ArrayCollectionItem } from './array-collection-item.entity';
export declare class ArrayCollectionItemProduct {
    id: number;
    arrayCollectionItemId: number;
    productId: number;
    sortOrder: number;
    createdAt: Date;
    item: ArrayCollectionItem;
}
