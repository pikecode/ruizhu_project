import { Product } from './product.entity';
export declare class Category {
    id: number;
    name: string;
    slug: string;
    description: string;
    iconUrl: string;
    sortOrder: number;
    isActive: boolean;
    parentId: number;
    parent: Category;
    children: Category[];
    products: Product[];
    createdAt: Date;
    updatedAt: Date;
}
