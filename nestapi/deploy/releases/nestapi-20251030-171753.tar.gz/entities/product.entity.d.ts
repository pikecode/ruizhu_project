export declare class Product {
    id: number;
    name: string;
    subtitle: string;
    sku: string | null;
    description: string;
    categoryId: number;
    isNew: boolean;
    isSaleOn: boolean;
    isOutOfStock: boolean;
    isSoldOut: boolean;
    stockStatus: 'normal' | 'outOfStock' | 'soldOut';
    isVipOnly: boolean;
    stockQuantity: number;
    lowStockThreshold: number;
    weight: number;
    shippingTemplateId: number;
    freeShippingThreshold: number;
    coverImageUrl: string | null;
    coverImageId: number | null;
    originalPrice: number | null;
    currentPrice: number | null;
    discountRate: number;
    currency: string;
    vipDiscountRate: number | null;
    salesCount: number;
    viewsCount: number;
    averageRating: number;
    reviewsCount: number;
    favoritesCount: number;
    conversionRate: number | null;
    lastSoldAt: Date | null;
    createdAt: Date;
    updatedAt: Date;
    category: any;
    images: any[];
    attributes: any[];
    details: any;
    tags: any[];
    reviews: any[];
}
export declare class ProductImage {
    id: number;
    productId: number;
    imageUrl: string;
    imageType: 'thumb' | 'cover' | 'list' | 'detail';
    altText: string;
    sortOrder: number;
    width: number;
    height: number;
    fileSize: number;
    createdAt: Date;
    product: any;
}
export declare class ProductStats {
    id: number;
    productId: number;
    salesCount: number;
    viewsCount: number;
    averageRating: number;
    reviewsCount: number;
    favoritesCount: number;
    conversionRate: number;
    lastSoldAt: Date;
    createdAt: Date;
    updatedAt: Date;
    product: any;
}
export declare class ProductAttribute {
    id: number;
    productId: number;
    attributeName: string;
    attributeValue: string;
    attributeSkuSuffix: string;
    additionalPrice: number;
    stockQuantity: number;
    colorHex: string;
    sizeSortOrder: number;
    createdAt: Date;
    product: any;
}
export declare class ProductDetails {
    id: number;
    productId: number;
    brand: string;
    material: string;
    origin: string;
    weightValue: number;
    length: number;
    width: number;
    height: number;
    fullDescription: string;
    highlights: string;
    careGuide: string;
    warranty: string;
    seoKeywords: string;
    seoDescription: string;
    createdAt: Date;
    updatedAt: Date;
    product: any;
}
export declare class ProductTag {
    id: number;
    productId: number;
    tagName: string;
    createdAt: Date;
    product: any;
}
export declare class ProductReview {
    id: number;
    productId: number;
    userId: number;
    orderItemId: number;
    rating: number;
    comment: string;
    reviewImages: string;
    helpfulCount: number;
    unhelpfulCount: number;
    isVerifiedPurchase: boolean;
    isApproved: boolean;
    createdAt: Date;
    updatedAt: Date;
    product: any;
}
export declare class CartItem {
    id: number;
    userId: number;
    productId: number;
    quantity: number;
    selectedAttributes: Record<string, string>;
    selectedColorId: string;
    selectedSizeId: string;
    cartPrice: number;
    createdAt: Date;
    updatedAt: Date;
    product: any;
}
export declare class Order {
    id: number;
    orderNo: string;
    userId: number;
    subtotal: number;
    shippingCost: number;
    discountAmount: number;
    totalAmount: number;
    status: string;
    paymentStatus: string;
    shippingAddress: Record<string, any>;
    receiverName: string;
    receiverPhone: string;
    notes: string;
    paidAt: Date;
    shippedAt: Date;
    deliveredAt: Date;
    createdAt: Date;
    updatedAt: Date;
    items: any[];
}
export declare class OrderItem {
    id: number;
    orderId: number;
    productId: number;
    quantity: number;
    selectedAttributes: Record<string, string>;
    productName: string;
    sku: string;
    priceSnapshot: number;
    subtotal: number;
    status: string;
    refundable: boolean;
    refundReason: string;
    createdAt: Date;
    updatedAt: Date;
    order: any;
    refunds: any[];
}
export declare class OrderRefund {
    id: number;
    refundNo: string;
    orderItemId: number;
    refundAmount: number;
    status: string;
    refundReason: string;
    refundDescription: string;
    returnTrackingNo: string;
    returnReceivedAt: Date;
    processedBy: number;
    processedNotes: string;
    processedAt: Date;
    createdAt: Date;
    updatedAt: Date;
    orderItem: any;
}
