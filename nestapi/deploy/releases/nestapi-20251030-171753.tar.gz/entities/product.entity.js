"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.OrderRefund = exports.OrderItem = exports.Order = exports.CartItem = exports.ProductReview = exports.ProductTag = exports.ProductDetails = exports.ProductAttribute = exports.ProductStats = exports.ProductImage = exports.Product = void 0;
const typeorm_1 = require("typeorm");
let Product = class Product {
    id;
    name;
    subtitle;
    sku;
    description;
    categoryId;
    isNew;
    isSaleOn;
    isOutOfStock;
    isSoldOut;
    stockStatus;
    isVipOnly;
    stockQuantity;
    lowStockThreshold;
    weight;
    shippingTemplateId;
    freeShippingThreshold;
    coverImageUrl;
    coverImageId;
    originalPrice;
    currentPrice;
    discountRate;
    currency;
    vipDiscountRate;
    salesCount;
    viewsCount;
    averageRating;
    reviewsCount;
    favoritesCount;
    conversionRate;
    lastSoldAt;
    createdAt;
    updatedAt;
    category;
    images;
    attributes;
    details;
    tags;
    reviews;
};
exports.Product = Product;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Product.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200 }),
    __metadata("design:type", String)
], Product.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], Product.prototype, "subtitle", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", Object)
], Product.prototype, "sku", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], Product.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'category_id' }),
    __metadata("design:type", Number)
], Product.prototype, "categoryId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0, name: 'is_new' }),
    __metadata("design:type", Boolean)
], Product.prototype, "isNew", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 1, name: 'is_sale_on' }),
    __metadata("design:type", Boolean)
], Product.prototype, "isSaleOn", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0, name: 'is_out_of_stock' }),
    __metadata("design:type", Boolean)
], Product.prototype, "isOutOfStock", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0, name: 'is_sold_out' }),
    __metadata("design:type", Boolean)
], Product.prototype, "isSoldOut", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['normal', 'outOfStock', 'soldOut'],
        default: 'normal',
        name: 'stock_status',
    }),
    __metadata("design:type", String)
], Product.prototype, "stockStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0, name: 'is_vip_only' }),
    __metadata("design:type", Boolean)
], Product.prototype, "isVipOnly", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'stock_quantity' }),
    __metadata("design:type", Number)
], Product.prototype, "stockQuantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 10, name: 'low_stock_threshold' }),
    __metadata("design:type", Number)
], Product.prototype, "lowStockThreshold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], Product.prototype, "weight", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'shipping_template_id' }),
    __metadata("design:type", Number)
], Product.prototype, "shippingTemplateId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 10, scale: 2, nullable: true, name: 'free_shipping_threshold' }),
    __metadata("design:type", Number)
], Product.prototype, "freeShippingThreshold", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, name: 'cover_image_url' }),
    __metadata("design:type", Object)
], Product.prototype, "coverImageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'cover_image_id' }),
    __metadata("design:type", Object)
], Product.prototype, "coverImageId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'original_price' }),
    __metadata("design:type", Object)
], Product.prototype, "originalPrice", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'current_price' }),
    __metadata("design:type", Object)
], Product.prototype, "currentPrice", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 100, name: 'discount_rate' }),
    __metadata("design:type", Number)
], Product.prototype, "discountRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'char', length: 3, default: 'CNY', name: 'currency' }),
    __metadata("design:type", String)
], Product.prototype, "currency", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', nullable: true, name: 'vip_discount_rate' }),
    __metadata("design:type", Object)
], Product.prototype, "vipDiscountRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sales_count' }),
    __metadata("design:type", Number)
], Product.prototype, "salesCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'views_count' }),
    __metadata("design:type", Number)
], Product.prototype, "viewsCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 3, scale: 2, default: 0, name: 'average_rating' }),
    __metadata("design:type", Number)
], Product.prototype, "averageRating", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'reviews_count' }),
    __metadata("design:type", Number)
], Product.prototype, "reviewsCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'favorites_count' }),
    __metadata("design:type", Number)
], Product.prototype, "favoritesCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, nullable: true, name: 'conversion_rate' }),
    __metadata("design:type", Object)
], Product.prototype, "conversionRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'last_sold_at' }),
    __metadata("design:type", Object)
], Product.prototype, "lastSoldAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Product.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Product.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Category', (category) => category.products, {
        onDelete: 'RESTRICT',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'category_id' }),
    __metadata("design:type", Object)
], Product.prototype, "category", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('ProductImage', (image) => image.product, { eager: true }),
    __metadata("design:type", Array)
], Product.prototype, "images", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('ProductAttribute', (attr) => attr.product),
    __metadata("design:type", Array)
], Product.prototype, "attributes", void 0);
__decorate([
    (0, typeorm_1.OneToOne)('ProductDetails', (details) => details.product),
    __metadata("design:type", Object)
], Product.prototype, "details", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('ProductTag', (tag) => tag.product),
    __metadata("design:type", Array)
], Product.prototype, "tags", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('ProductReview', (review) => review.product),
    __metadata("design:type", Array)
], Product.prototype, "reviews", void 0);
exports.Product = Product = __decorate([
    (0, typeorm_1.Entity)('products'),
    (0, typeorm_1.Index)(['category']),
    (0, typeorm_1.Index)(['isSaleOn', 'stockStatus']),
    (0, typeorm_1.Index)(['stockStatus']),
    (0, typeorm_1.Index)(['createdAt'])
], Product);
let ProductImage = class ProductImage {
    id;
    productId;
    imageUrl;
    imageType;
    altText;
    sortOrder;
    width;
    height;
    fileSize;
    createdAt;
    product;
};
exports.ProductImage = ProductImage;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductImage.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], ProductImage.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, name: 'image_url' }),
    __metadata("design:type", String)
], ProductImage.prototype, "imageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['thumb', 'cover', 'list', 'detail'],
        default: 'cover',
        name: 'image_type',
    }),
    __metadata("design:type", String)
], ProductImage.prototype, "imageType", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true, name: 'alt_text' }),
    __metadata("design:type", String)
], ProductImage.prototype, "altText", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sort_order' }),
    __metadata("design:type", Number)
], ProductImage.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductImage.prototype, "width", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true }),
    __metadata("design:type", Number)
], ProductImage.prototype, "height", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'file_size' }),
    __metadata("design:type", Number)
], ProductImage.prototype, "fileSize", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductImage.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Product', (product) => product.images, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductImage.prototype, "product", void 0);
exports.ProductImage = ProductImage = __decorate([
    (0, typeorm_1.Entity)('product_images'),
    (0, typeorm_1.Index)(['productId', 'imageType']),
    (0, typeorm_1.Index)(['sortOrder'])
], ProductImage);
let ProductStats = class ProductStats {
    id;
    productId;
    salesCount;
    viewsCount;
    averageRating;
    reviewsCount;
    favoritesCount;
    conversionRate;
    lastSoldAt;
    createdAt;
    updatedAt;
    product;
};
exports.ProductStats = ProductStats;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductStats.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', unique: true, name: 'product_id' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sales_count' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "salesCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'views_count' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "viewsCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 3, scale: 2, default: 0, name: 'average_rating' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "averageRating", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'reviews_count' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "reviewsCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'favorites_count' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "favoritesCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 5, scale: 2, nullable: true, name: 'conversion_rate' }),
    __metadata("design:type", Number)
], ProductStats.prototype, "conversionRate", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'last_sold_at' }),
    __metadata("design:type", Date)
], ProductStats.prototype, "lastSoldAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductStats.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProductStats.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.OneToOne)('Product', (product) => product.stats, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductStats.prototype, "product", void 0);
exports.ProductStats = ProductStats = __decorate([
    (0, typeorm_1.Entity)('product_stats'),
    (0, typeorm_1.Index)(['productId'], { unique: true }),
    (0, typeorm_1.Index)(['salesCount']),
    (0, typeorm_1.Index)(['averageRating']),
    (0, typeorm_1.Index)(['favoritesCount'])
], ProductStats);
let ProductAttribute = class ProductAttribute {
    id;
    productId;
    attributeName;
    attributeValue;
    attributeSkuSuffix;
    additionalPrice;
    stockQuantity;
    colorHex;
    sizeSortOrder;
    createdAt;
    product;
};
exports.ProductAttribute = ProductAttribute;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductAttribute.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], ProductAttribute.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, name: 'attribute_name' }),
    __metadata("design:type", String)
], ProductAttribute.prototype, "attributeName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, name: 'attribute_value' }),
    __metadata("design:type", String)
], ProductAttribute.prototype, "attributeValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, nullable: true, name: 'attribute_sku_suffix' }),
    __metadata("design:type", String)
], ProductAttribute.prototype, "attributeSkuSuffix", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'additional_price' }),
    __metadata("design:type", Number)
], ProductAttribute.prototype, "additionalPrice", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'stock_quantity' }),
    __metadata("design:type", Number)
], ProductAttribute.prototype, "stockQuantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 7, nullable: true, name: 'color_hex' }),
    __metadata("design:type", String)
], ProductAttribute.prototype, "colorHex", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'size_sort_order' }),
    __metadata("design:type", Number)
], ProductAttribute.prototype, "sizeSortOrder", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductAttribute.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Product', (product) => product.attributes, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductAttribute.prototype, "product", void 0);
exports.ProductAttribute = ProductAttribute = __decorate([
    (0, typeorm_1.Entity)('product_attributes'),
    (0, typeorm_1.Index)(['productId', 'attributeName']),
    (0, typeorm_1.Index)(['productId', 'attributeName', 'attributeValue'], { unique: true })
], ProductAttribute);
let ProductDetails = class ProductDetails {
    id;
    productId;
    brand;
    material;
    origin;
    weightValue;
    length;
    width;
    height;
    fullDescription;
    highlights;
    careGuide;
    warranty;
    seoKeywords;
    seoDescription;
    createdAt;
    updatedAt;
    product;
};
exports.ProductDetails = ProductDetails;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductDetails.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', unique: true, name: 'product_id' }),
    __metadata("design:type", Number)
], ProductDetails.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], ProductDetails.prototype, "brand", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, nullable: true }),
    __metadata("design:type", String)
], ProductDetails.prototype, "material", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], ProductDetails.prototype, "origin", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 8, scale: 2, nullable: true, name: 'weight_value' }),
    __metadata("design:type", Number)
], ProductDetails.prototype, "weightValue", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ProductDetails.prototype, "length", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ProductDetails.prototype, "width", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'decimal', precision: 8, scale: 2, nullable: true }),
    __metadata("design:type", Number)
], ProductDetails.prototype, "height", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'longtext', nullable: true, name: 'full_description' }),
    __metadata("design:type", String)
], ProductDetails.prototype, "fullDescription", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'longtext', nullable: true }),
    __metadata("design:type", String)
], ProductDetails.prototype, "highlights", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'care_guide' }),
    __metadata("design:type", String)
], ProductDetails.prototype, "careGuide", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProductDetails.prototype, "warranty", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, name: 'seo_keywords' }),
    __metadata("design:type", String)
], ProductDetails.prototype, "seoKeywords", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, name: 'seo_description' }),
    __metadata("design:type", String)
], ProductDetails.prototype, "seoDescription", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductDetails.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProductDetails.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.OneToOne)('Product', (product) => product.details, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductDetails.prototype, "product", void 0);
exports.ProductDetails = ProductDetails = __decorate([
    (0, typeorm_1.Entity)('product_details')
], ProductDetails);
let ProductTag = class ProductTag {
    id;
    productId;
    tagName;
    createdAt;
    product;
};
exports.ProductTag = ProductTag;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductTag.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], ProductTag.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 50, name: 'tag_name' }),
    __metadata("design:type", String)
], ProductTag.prototype, "tagName", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductTag.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Product', (product) => product.tags, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductTag.prototype, "product", void 0);
exports.ProductTag = ProductTag = __decorate([
    (0, typeorm_1.Entity)('product_tags'),
    (0, typeorm_1.Index)(['productId', 'tagName'], { unique: true }),
    (0, typeorm_1.Index)(['tagName'])
], ProductTag);
let ProductReview = class ProductReview {
    id;
    productId;
    userId;
    orderItemId;
    rating;
    comment;
    reviewImages;
    helpfulCount;
    unhelpfulCount;
    isVerifiedPurchase;
    isApproved;
    createdAt;
    updatedAt;
    product;
};
exports.ProductReview = ProductReview;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], ProductReview.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'user_id' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'order_item_id' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "orderItemId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "rating", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], ProductReview.prototype, "comment", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'longtext', nullable: true, name: 'review_images' }),
    __metadata("design:type", String)
], ProductReview.prototype, "reviewImages", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'helpful_count' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "helpfulCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'unhelpful_count' }),
    __metadata("design:type", Number)
], ProductReview.prototype, "unhelpfulCount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 1, name: 'is_verified_purchase' }),
    __metadata("design:type", Boolean)
], ProductReview.prototype, "isVerifiedPurchase", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 1, name: 'is_approved' }),
    __metadata("design:type", Boolean)
], ProductReview.prototype, "isApproved", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], ProductReview.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], ProductReview.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Product', (product) => product.reviews, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], ProductReview.prototype, "product", void 0);
exports.ProductReview = ProductReview = __decorate([
    (0, typeorm_1.Entity)('product_reviews'),
    (0, typeorm_1.Index)(['productId', 'rating']),
    (0, typeorm_1.Index)(['userId']),
    (0, typeorm_1.Index)(['isApproved', 'createdAt'])
], ProductReview);
let CartItem = class CartItem {
    id;
    userId;
    productId;
    quantity;
    selectedAttributes;
    selectedColorId;
    selectedSizeId;
    cartPrice;
    createdAt;
    updatedAt;
    product;
};
exports.CartItem = CartItem;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], CartItem.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'user_id' }),
    __metadata("design:type", Number)
], CartItem.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], CartItem.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 1 }),
    __metadata("design:type", Number)
], CartItem.prototype, "quantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true, name: 'selected_attributes' }),
    __metadata("design:type", Object)
], CartItem.prototype, "selectedAttributes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true, name: 'selected_color_id' }),
    __metadata("design:type", String)
], CartItem.prototype, "selectedColorId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true, name: 'selected_size_id' }),
    __metadata("design:type", String)
], CartItem.prototype, "selectedSizeId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'cart_price' }),
    __metadata("design:type", Number)
], CartItem.prototype, "cartPrice", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], CartItem.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], CartItem.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Product', { onDelete: 'CASCADE' }),
    (0, typeorm_1.JoinColumn)({ name: 'product_id' }),
    __metadata("design:type", Object)
], CartItem.prototype, "product", void 0);
exports.CartItem = CartItem = __decorate([
    (0, typeorm_1.Entity)('cart_items'),
    (0, typeorm_1.Index)(['userId']),
    (0, typeorm_1.Index)(['updatedAt']),
    (0, typeorm_1.Unique)(['userId', 'productId'])
], CartItem);
let Order = class Order {
    id;
    orderNo;
    userId;
    subtotal;
    shippingCost;
    discountAmount;
    totalAmount;
    status;
    paymentStatus;
    shippingAddress;
    receiverName;
    receiverPhone;
    notes;
    paidAt;
    shippedAt;
    deliveredAt;
    createdAt;
    updatedAt;
    items;
};
exports.Order = Order;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Order.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, unique: true, name: 'order_no' }),
    __metadata("design:type", String)
], Order.prototype, "orderNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'user_id' }),
    __metadata("design:type", Number)
], Order.prototype, "userId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], Order.prototype, "subtotal", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'shipping_cost' }),
    __metadata("design:type", Number)
], Order.prototype, "shippingCost", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'discount_amount' }),
    __metadata("design:type", Number)
], Order.prototype, "discountAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'total_amount' }),
    __metadata("design:type", Number)
], Order.prototype, "totalAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: [
            'pending',
            'paid',
            'processing',
            'shipped',
            'delivered',
            'completed',
            'cancelled',
            'refunded',
        ],
        default: 'pending',
    }),
    __metadata("design:type", String)
], Order.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['unpaid', 'paid', 'refunded'],
        default: 'unpaid',
        name: 'payment_status',
    }),
    __metadata("design:type", String)
], Order.prototype, "paymentStatus", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true, name: 'shipping_address' }),
    __metadata("design:type", Object)
], Order.prototype, "shippingAddress", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true, name: 'receiver_name' }),
    __metadata("design:type", String)
], Order.prototype, "receiverName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 20, nullable: true, name: 'receiver_phone' }),
    __metadata("design:type", String)
], Order.prototype, "receiverPhone", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], Order.prototype, "notes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'paid_at' }),
    __metadata("design:type", Date)
], Order.prototype, "paidAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'shipped_at' }),
    __metadata("design:type", Date)
], Order.prototype, "shippedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'delivered_at' }),
    __metadata("design:type", Date)
], Order.prototype, "deliveredAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Order.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Order.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('OrderItem', (item) => item.order),
    __metadata("design:type", Array)
], Order.prototype, "items", void 0);
exports.Order = Order = __decorate([
    (0, typeorm_1.Entity)('orders'),
    (0, typeorm_1.Index)(['userId', 'createdAt']),
    (0, typeorm_1.Index)(['status']),
    (0, typeorm_1.Index)(['orderNo'], { unique: true })
], Order);
let OrderItem = class OrderItem {
    id;
    orderId;
    productId;
    quantity;
    selectedAttributes;
    productName;
    sku;
    priceSnapshot;
    subtotal;
    status;
    refundable;
    refundReason;
    createdAt;
    updatedAt;
    order;
    refunds;
};
exports.OrderItem = OrderItem;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], OrderItem.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'order_id' }),
    __metadata("design:type", Number)
], OrderItem.prototype, "orderId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'product_id' }),
    __metadata("design:type", Number)
], OrderItem.prototype, "productId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], OrderItem.prototype, "quantity", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'json', nullable: true, name: 'selected_attributes' }),
    __metadata("design:type", Object)
], OrderItem.prototype, "selectedAttributes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 200, name: 'product_name' }),
    __metadata("design:type", String)
], OrderItem.prototype, "productName", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true }),
    __metadata("design:type", String)
], OrderItem.prototype, "sku", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'price_snapshot' }),
    __metadata("design:type", Number)
], OrderItem.prototype, "priceSnapshot", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int' }),
    __metadata("design:type", Number)
], OrderItem.prototype, "subtotal", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['pending', 'shipped', 'delivered', 'returned', 'refunded'],
        default: 'pending',
    }),
    __metadata("design:type", String)
], OrderItem.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 1 }),
    __metadata("design:type", Boolean)
], OrderItem.prototype, "refundable", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'refund_reason' }),
    __metadata("design:type", String)
], OrderItem.prototype, "refundReason", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], OrderItem.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], OrderItem.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('Order', (order) => order.items, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'order_id' }),
    __metadata("design:type", Object)
], OrderItem.prototype, "order", void 0);
__decorate([
    (0, typeorm_1.OneToMany)('OrderRefund', (refund) => refund.orderItem),
    __metadata("design:type", Array)
], OrderItem.prototype, "refunds", void 0);
exports.OrderItem = OrderItem = __decorate([
    (0, typeorm_1.Entity)('order_items'),
    (0, typeorm_1.Index)(['orderId']),
    (0, typeorm_1.Index)(['status'])
], OrderItem);
let OrderRefund = class OrderRefund {
    id;
    refundNo;
    orderItemId;
    refundAmount;
    status;
    refundReason;
    refundDescription;
    returnTrackingNo;
    returnReceivedAt;
    processedBy;
    processedNotes;
    processedAt;
    createdAt;
    updatedAt;
    orderItem;
};
exports.OrderRefund = OrderRefund;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], OrderRefund.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, unique: true, name: 'refund_no' }),
    __metadata("design:type", String)
], OrderRefund.prototype, "refundNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'order_item_id' }),
    __metadata("design:type", Number)
], OrderRefund.prototype, "orderItemId", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', name: 'refund_amount' }),
    __metadata("design:type", Number)
], OrderRefund.prototype, "refundAmount", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['pending', 'approved', 'processing', 'completed', 'rejected'],
        default: 'pending',
    }),
    __metadata("design:type", String)
], OrderRefund.prototype, "status", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, name: 'refund_reason' }),
    __metadata("design:type", String)
], OrderRefund.prototype, "refundReason", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'refund_description' }),
    __metadata("design:type", String)
], OrderRefund.prototype, "refundDescription", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: true, name: 'return_tracking_no' }),
    __metadata("design:type", String)
], OrderRefund.prototype, "returnTrackingNo", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'return_received_at' }),
    __metadata("design:type", Date)
], OrderRefund.prototype, "returnReceivedAt", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', nullable: true, name: 'processed_by' }),
    __metadata("design:type", Number)
], OrderRefund.prototype, "processedBy", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true, name: 'processed_notes' }),
    __metadata("design:type", String)
], OrderRefund.prototype, "processedNotes", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'timestamp', nullable: true, name: 'processed_at' }),
    __metadata("design:type", Date)
], OrderRefund.prototype, "processedAt", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], OrderRefund.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], OrderRefund.prototype, "updatedAt", void 0);
__decorate([
    (0, typeorm_1.ManyToOne)('OrderItem', (item) => item.refunds, {
        onDelete: 'CASCADE',
    }),
    (0, typeorm_1.JoinColumn)({ name: 'order_item_id' }),
    __metadata("design:type", Object)
], OrderRefund.prototype, "orderItem", void 0);
exports.OrderRefund = OrderRefund = __decorate([
    (0, typeorm_1.Entity)('order_refunds'),
    (0, typeorm_1.Index)(['status']),
    (0, typeorm_1.Index)(['orderItemId']),
    (0, typeorm_1.Index)(['refundNo'], { unique: true })
], OrderRefund);
//# sourceMappingURL=product.entity.js.map