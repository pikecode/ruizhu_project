"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Banner = void 0;
const typeorm_1 = require("typeorm");
let Banner = class Banner {
    id;
    mainTitle;
    subtitle;
    description;
    type;
    imageUrl;
    imageKey;
    videoUrl;
    videoKey;
    videoThumbnailUrl;
    videoThumbnailKey;
    pageType;
    isActive;
    sortOrder;
    linkType;
    linkValue;
    createdAt;
    updatedAt;
};
exports.Banner = Banner;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Banner.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
        name: 'main_title',
        comment: '大标题',
    }),
    __metadata("design:type", String)
], Banner.prototype, "mainTitle", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
        nullable: true,
        comment: '小标题',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "subtitle", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'text',
        nullable: true,
        comment: '描述',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['image', 'video'],
        default: 'image',
        comment: '类型：image或video',
    }),
    __metadata("design:type", String)
], Banner.prototype, "type", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 500,
        nullable: true,
        name: 'image_url',
        comment: '图片URL (COS)',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "imageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
        nullable: true,
        name: 'image_key',
        comment: '图片文件Key (COS)',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "imageKey", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 500,
        nullable: true,
        name: 'video_url',
        comment: '视频URL (COS) - webp格式',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "videoUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
        nullable: true,
        name: 'video_key',
        comment: '视频文件Key (COS)',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "videoKey", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 500,
        nullable: true,
        name: 'video_thumbnail_url',
        comment: '视频封面图URL',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "videoThumbnailUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 255,
        nullable: true,
        name: 'video_thumbnail_key',
        comment: '视频封面文件Key',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "videoThumbnailKey", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['home', 'custom'],
        default: 'home',
        name: 'page_type',
        comment: '页面类型：home(首页) custom(私人定制)',
    }),
    __metadata("design:type", String)
], Banner.prototype, "pageType", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'boolean',
        default: true,
        name: 'is_active',
        comment: '是否启用',
    }),
    __metadata("design:type", Boolean)
], Banner.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'int',
        default: 0,
        name: 'sort_order',
        comment: '排序顺序',
    }),
    __metadata("design:type", Number)
], Banner.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'enum',
        enum: ['none', 'product', 'category', 'collection', 'url'],
        default: 'none',
        name: 'link_type',
        comment: '链接类型',
    }),
    __metadata("design:type", String)
], Banner.prototype, "linkType", void 0);
__decorate([
    (0, typeorm_1.Column)({
        type: 'varchar',
        length: 500,
        nullable: true,
        name: 'link_value',
        comment: '链接值（产品ID、分类ID、URL等）',
    }),
    __metadata("design:type", Object)
], Banner.prototype, "linkValue", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({
        name: 'created_at',
    }),
    __metadata("design:type", Date)
], Banner.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({
        name: 'updated_at',
    }),
    __metadata("design:type", Date)
], Banner.prototype, "updatedAt", void 0);
exports.Banner = Banner = __decorate([
    (0, typeorm_1.Entity)('banners'),
    (0, typeorm_1.Index)('idx_sort_order', ['sortOrder']),
    (0, typeorm_1.Index)('idx_is_active', ['isActive']),
    (0, typeorm_1.Index)('idx_type', ['type']),
    (0, typeorm_1.Index)('idx_page_type', ['pageType']),
    (0, typeorm_1.Index)('idx_page_type_sort', ['pageType', 'sortOrder']),
    (0, typeorm_1.Index)('idx_created_at', ['createdAt'])
], Banner);
//# sourceMappingURL=banner.entity.js.map