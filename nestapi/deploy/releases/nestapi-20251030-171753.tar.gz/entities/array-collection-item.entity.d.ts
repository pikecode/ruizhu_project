import { ArrayCollection } from './array-collection.entity';
import { ArrayCollectionItemProduct } from './array-collection-item-product.entity';
export declare class ArrayCollectionItem {
    id: number;
    arrayCollectionId: number;
    title: string;
    description: string;
    coverImageUrl: string | null;
    sortOrder: number;
    createdAt: Date;
    updatedAt: Date;
    arrayCollection: ArrayCollection;
    products: ArrayCollectionItemProduct[];
}
