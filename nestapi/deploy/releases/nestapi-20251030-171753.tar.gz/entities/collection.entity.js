"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.Collection = void 0;
const typeorm_1 = require("typeorm");
const collection_product_entity_1 = require("./collection-product.entity");
let Collection = class Collection {
    id;
    name;
    slug;
    description;
    coverImageUrl;
    iconUrl;
    sortOrder;
    isActive;
    isFeatured;
    remark;
    collectionProducts;
    createdAt;
    updatedAt;
};
exports.Collection = Collection;
__decorate([
    (0, typeorm_1.PrimaryGeneratedColumn)(),
    __metadata("design:type", Number)
], Collection.prototype, "id", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, nullable: false }),
    __metadata("design:type", String)
], Collection.prototype, "name", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 100, unique: true, nullable: false }),
    __metadata("design:type", String)
], Collection.prototype, "slug", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true }),
    __metadata("design:type", String)
], Collection.prototype, "description", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 500, nullable: true, name: 'cover_image_url' }),
    __metadata("design:type", Object)
], Collection.prototype, "coverImageUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'varchar', length: 255, nullable: true, name: 'icon_url' }),
    __metadata("design:type", Object)
], Collection.prototype, "iconUrl", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'int', default: 0, name: 'sort_order' }),
    __metadata("design:type", Number)
], Collection.prototype, "sortOrder", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 1, name: 'is_active' }),
    __metadata("design:type", Boolean)
], Collection.prototype, "isActive", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'tinyint', default: 0, name: 'is_featured' }),
    __metadata("design:type", Boolean)
], Collection.prototype, "isFeatured", void 0);
__decorate([
    (0, typeorm_1.Column)({ type: 'text', nullable: true }),
    __metadata("design:type", String)
], Collection.prototype, "remark", void 0);
__decorate([
    (0, typeorm_1.OneToMany)(() => collection_product_entity_1.CollectionProduct, (cp) => cp.collection, {
        cascade: true,
        onDelete: 'CASCADE',
    }),
    __metadata("design:type", Array)
], Collection.prototype, "collectionProducts", void 0);
__decorate([
    (0, typeorm_1.CreateDateColumn)({ name: 'created_at' }),
    __metadata("design:type", Date)
], Collection.prototype, "createdAt", void 0);
__decorate([
    (0, typeorm_1.UpdateDateColumn)({ name: 'updated_at' }),
    __metadata("design:type", Date)
], Collection.prototype, "updatedAt", void 0);
exports.Collection = Collection = __decorate([
    (0, typeorm_1.Entity)('collections'),
    (0, typeorm_1.Unique)(['slug']),
    (0, typeorm_1.Index)(['isActive', 'sortOrder']),
    (0, typeorm_1.Index)(['isFeatured']),
    (0, typeorm_1.Index)(['createdAt'])
], Collection);
//# sourceMappingURL=collection.entity.js.map