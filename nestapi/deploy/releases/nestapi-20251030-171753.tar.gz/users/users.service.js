"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsersService = void 0;
const common_1 = require("@nestjs/common");
const typeorm_1 = require("@nestjs/typeorm");
const typeorm_2 = require("typeorm");
const user_entity_1 = require("../entities/user.entity");
let UsersService = class UsersService {
    usersRepository;
    constructor(usersRepository) {
        this.usersRepository = usersRepository;
    }
    async create(createUserDto) {
        const existingUser = await this.usersRepository.findOne({
            where: [{ username: createUserDto.username }, { email: createUserDto.email }],
        });
        if (existingUser) {
            throw new common_1.BadRequestException('用户名或邮箱已存在');
        }
        const user = this.usersRepository.create({
            ...createUserDto,
            registrationSource: 'web',
            status: 'active',
        });
        const savedUser = await this.usersRepository.save(user);
        const { password, ...result } = savedUser;
        return result;
    }
    async findAll() {
        const users = await this.usersRepository.find({
            where: { status: 'active' },
        });
        return users.map(user => {
            const { password, ...result } = user;
            return result;
        });
    }
    async findOne(id) {
        const user = await this.usersRepository.findOne({
            where: { id, status: 'active' },
        });
        if (!user)
            return null;
        const { password, ...result } = user;
        return result;
    }
    async findByUsername(username) {
        return this.usersRepository.findOne({
            where: { username, status: 'active' },
        });
    }
    async findByPhone(phone) {
        return this.usersRepository.findOne({
            where: { phone, status: 'active' },
        });
    }
    async findByOpenId(openId) {
        return this.usersRepository.findOne({
            where: { openId, status: 'active' },
        });
    }
    async findByEmail(email) {
        return this.usersRepository.findOne({
            where: { email, status: 'active' },
        });
    }
    async remove(id) {
        const user = await this.usersRepository.findOne({ where: { id } });
        if (!user) {
            throw new common_1.NotFoundException('用户不存在');
        }
        await this.usersRepository.update(id, { status: 'deleted' });
        return true;
    }
    async createOrUpdateByPhone(phone, openId, userData) {
        let user = phone ? await this.usersRepository.findOne({
            where: { phone },
        }) : null;
        if (user) {
            await this.usersRepository.update(user.id, {
                ...userData,
                openId,
                isPhoneAuthorized: true,
                status: 'active',
            });
            const updatedUser = await this.usersRepository.findOne({ where: { id: user.id } });
            if (!updatedUser) {
                throw new common_1.NotFoundException('用户不存在');
            }
            return updatedUser;
        }
        user = this.usersRepository.create({
            phone,
            openId,
            isPhoneAuthorized: true,
            registrationSource: 'wechat_mini_program',
            status: 'active',
            ...userData,
        });
        return this.usersRepository.save(user);
    }
    async bindPhoneToOpenId(openId, phone) {
        const user = await this.usersRepository.findOne({
            where: { openId },
        });
        if (!user) {
            throw new common_1.NotFoundException('用户不存在');
        }
        const existingPhoneUser = await this.usersRepository.findOne({
            where: { phone },
        });
        if (existingPhoneUser && existingPhoneUser.id !== user.id) {
            throw new common_1.BadRequestException('该手机号已绑定其他账户');
        }
        await this.usersRepository.update(user.id, {
            phone,
            isPhoneAuthorized: true,
        });
        const updatedUser = await this.usersRepository.findOne({ where: { id: user.id } });
        if (!updatedUser) {
            throw new common_1.NotFoundException('用户不存在');
        }
        return updatedUser;
    }
    async updateLastLogin(userId, ip) {
        await this.usersRepository.update(userId, {
            lastLoginAt: new Date(),
            lastLoginIp: ip,
            loginCount: () => 'login_count + 1',
        });
    }
};
exports.UsersService = UsersService;
exports.UsersService = UsersService = __decorate([
    (0, common_1.Injectable)(),
    __param(0, (0, typeorm_1.InjectRepository)(user_entity_1.User)),
    __metadata("design:paramtypes", [typeorm_2.Repository])
], UsersService);
//# sourceMappingURL=users.service.js.map