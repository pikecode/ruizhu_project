import { Repository } from 'typeorm';
import { User } from '../entities/user.entity';
import { CreateUserDto } from './dto/create-user.dto';
export declare class UsersService {
    private usersRepository;
    constructor(usersRepository: Repository<User>);
    create(createUserDto: CreateUserDto): Promise<Omit<User, 'password'>>;
    findAll(): Promise<Omit<User, 'password'>[]>;
    findOne(id: number): Promise<Omit<User, 'password'> | null>;
    findByUsername(username: string): Promise<User | null>;
    findByPhone(phone: string): Promise<User | null>;
    findByOpenId(openId: string): Promise<User | null>;
    findByEmail(email: string): Promise<User | null>;
    remove(id: number): Promise<boolean>;
    createOrUpdateByPhone(phone: string | null, openId: string, userData?: Partial<User>): Promise<User>;
    bindPhoneToOpenId(openId: string, phone: string): Promise<User>;
    updateLastLogin(userId: number, ip: string): Promise<void>;
}
