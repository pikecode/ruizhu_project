export declare class WechatPhoneLoginDto {
    openId: string;
    encryptedPhone: string;
    iv: string;
    sessionKey: string;
}
export declare class WechatAuthDataDto {
    openId: string;
    nickName?: string;
    gender?: number;
    province?: string;
    city?: string;
    country?: string;
    avatarUrl?: string;
    phoneNumber?: string;
    countryCode?: string;
}
