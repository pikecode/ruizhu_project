import { JwtService } from '@nestjs/jwt';
import { UsersService } from '../users/users.service';
export declare class AuthService {
    private usersService;
    private jwtService;
    constructor(usersService: UsersService, jwtService: JwtService);
    validateUser(username: string, password: string): Promise<any>;
    login(username: string, password: string): Promise<{
        access_token: string;
        user: any;
    }>;
    register(registerDto: {
        username: string;
        password: string;
        email: string;
    }): Promise<Omit<import("../entities/user.entity").User, "password">>;
    decryptWechatData(encryptedData: string, iv: string, sessionKey: string): any;
    wechatPhoneLogin(openId: string, encryptedPhone: string, iv: string, sessionKey: string): Promise<{
        access_token: string;
        user: {
            id: number;
            phone: string | null;
            openId: string | null;
            username: string | null;
            email: string | null;
            nickname: string | null;
            avatarUrl: string | null;
            gender: "male" | "female" | "unknown";
            province: string | null;
            city: string | null;
            country: string | null;
            isPhoneAuthorized: boolean;
            isProfileAuthorized: boolean;
            status: "active" | "banned" | "deleted";
            registrationSource: "wechat_mini_program" | "web" | "admin";
            lastLoginAt: Date | null;
            lastLoginIp: string | null;
            loginCount: number;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
    wechatOpenIdLogin(openId: string, userData?: {
        nickName?: string;
        avatarUrl?: string;
        gender?: number;
        province?: string;
        city?: string;
        country?: string;
    }): Promise<{
        access_token: string;
        user: {
            id: number;
            phone: string | null;
            openId: string | null;
            username: string | null;
            email: string | null;
            nickname: string | null;
            avatarUrl: string | null;
            gender: "male" | "female" | "unknown";
            province: string | null;
            city: string | null;
            country: string | null;
            isPhoneAuthorized: boolean;
            isProfileAuthorized: boolean;
            status: "active" | "banned" | "deleted";
            registrationSource: "wechat_mini_program" | "web" | "admin";
            lastLoginAt: Date | null;
            lastLoginIp: string | null;
            loginCount: number;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
    wechatLoginWithCode(code: string): Promise<{
        openId: any;
        sessionKey: any;
    }>;
}
