"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const common_1 = require("@nestjs/common");
const jwt_1 = require("@nestjs/jwt");
const users_service_1 = require("../users/users.service");
const bcrypt = __importStar(require("bcryptjs"));
const crypto = __importStar(require("crypto"));
let AuthService = class AuthService {
    usersService;
    jwtService;
    constructor(usersService, jwtService) {
        this.usersService = usersService;
        this.jwtService = jwtService;
    }
    async validateUser(username, password) {
        const user = await this.usersService.findByUsername(username);
        if (user && user.password && await bcrypt.compare(password, user.password)) {
            const { password, ...result } = user;
            return result;
        }
        return null;
    }
    async login(username, password) {
        const user = await this.validateUser(username, password);
        if (!user) {
            throw new common_1.UnauthorizedException('Invalid credentials');
        }
        const payload = { username: user.username, sub: user.id };
        return {
            access_token: this.jwtService.sign(payload),
            user,
        };
    }
    async register(registerDto) {
        const hashedPassword = await bcrypt.hash(registerDto.password, 10);
        return this.usersService.create({
            ...registerDto,
            password: hashedPassword,
        });
    }
    decryptWechatData(encryptedData, iv, sessionKey) {
        try {
            const encryptedDataBuf = Buffer.from(encryptedData, 'base64');
            const ivBuf = Buffer.from(iv, 'base64');
            const sessionKeyBuf = Buffer.from(sessionKey, 'base64');
            const decipher = crypto.createDecipheriv('aes-128-cbc', sessionKeyBuf, ivBuf);
            decipher.setAutoPadding(false);
            let decoded = decipher.update(encryptedDataBuf, undefined, 'utf8');
            decoded += decipher.final('utf8');
            const pad = decoded.charCodeAt(decoded.length - 1);
            if (pad < 1 || pad > 16) {
                throw new Error('Invalid padding');
            }
            decoded = decoded.slice(0, -pad);
            return JSON.parse(decoded);
        }
        catch (error) {
            throw new common_1.BadRequestException(`手机号解密失败: ${error.message}`);
        }
    }
    async wechatPhoneLogin(openId, encryptedPhone, iv, sessionKey) {
        const phoneData = this.decryptWechatData(encryptedPhone, iv, sessionKey);
        if (!phoneData.phoneNumber) {
            throw new common_1.BadRequestException('无法获取手机号');
        }
        const phone = phoneData.phoneNumber;
        let user = await this.usersService.findByPhone(phone);
        if (user) {
            if (user.openId !== openId) {
                user = await this.usersService.bindPhoneToOpenId(openId, phone);
            }
        }
        else {
            user = await this.usersService.createOrUpdateByPhone(phone, openId, {
                nickname: phoneData.name || `用户_${phone.slice(-4)}`,
            });
        }
        const ip = '0.0.0.0';
        await this.usersService.updateLastLogin(user.id, ip);
        const payload = { phone: user.phone, sub: user.id, openId: user.openId };
        const { password, ...userWithoutPassword } = user;
        return {
            access_token: this.jwtService.sign(payload),
            user: userWithoutPassword,
        };
    }
    async wechatOpenIdLogin(openId, userData) {
        let user = await this.usersService.findByOpenId(openId);
        if (!user) {
            user = await this.usersService.createOrUpdateByPhone(null, openId, {
                nickname: userData?.nickName,
                avatarUrl: userData?.avatarUrl,
                gender: userData?.gender ? (userData.gender === 1 ? 'male' : userData.gender === 2 ? 'female' : 'unknown') : 'unknown',
                province: userData?.province,
                city: userData?.city,
                country: userData?.country,
                isProfileAuthorized: true,
            });
        }
        else {
            if (userData && user.phone) {
                user = await this.usersService.bindPhoneToOpenId(openId, user.phone);
            }
        }
        const ip = '0.0.0.0';
        await this.usersService.updateLastLogin(user.id, ip);
        const payload = { sub: user.id, openId: user.openId };
        const { password, ...userWithoutPassword } = user;
        return {
            access_token: this.jwtService.sign(payload),
            user: userWithoutPassword,
        };
    }
    async wechatLoginWithCode(code) {
        if (!code) {
            throw new common_1.BadRequestException('授权码不能为空');
        }
        try {
            const appId = process.env.WECHAT_APP_ID || '';
            const appSecret = process.env.WECHAT_APP_SECRET || '';
            if (!appId || !appSecret) {
                throw new common_1.BadRequestException('微信配置不完整');
            }
            const wechatUrl = 'https://api.weixin.qq.com/sns/jscode2session';
            const params = new URLSearchParams();
            params.append('appid', appId);
            params.append('secret', appSecret);
            params.append('js_code', code);
            params.append('grant_type', 'authorization_code');
            const response = await fetch(`${wechatUrl}?${params.toString()}`);
            const data = await response.json();
            if (data.errcode) {
                throw new common_1.BadRequestException(`微信登录失败: ${data.errmsg || '未知错误'}`);
            }
            if (!data.openid || !data.session_key) {
                throw new common_1.BadRequestException('微信返回数据不完整');
            }
            return {
                openId: data.openid,
                sessionKey: data.session_key,
            };
        }
        catch (error) {
            if (error instanceof common_1.BadRequestException) {
                throw error;
            }
            throw new common_1.BadRequestException(`微信登录失败: ${error?.message || '网络错误'}`);
        }
    }
};
exports.AuthService = AuthService;
exports.AuthService = AuthService = __decorate([
    (0, common_1.Injectable)(),
    __metadata("design:paramtypes", [users_service_1.UsersService,
        jwt_1.JwtService])
], AuthService);
//# sourceMappingURL=auth.service.js.map