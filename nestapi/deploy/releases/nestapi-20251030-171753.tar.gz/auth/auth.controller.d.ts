import { AuthService } from './auth.service';
import { WechatPhoneLoginDto } from '../users/dto/wechat-phone-login.dto';
export declare class AuthController {
    private authService;
    constructor(authService: AuthService);
    login(loginDto: {
        username: string;
        password: string;
    }): Promise<{
        access_token: string;
        user: any;
    }>;
    register(registerDto: {
        username: string;
        password: string;
        email: string;
    }): Promise<Omit<import("../entities/user.entity").User, "password">>;
    wechatPhoneLogin(dto: WechatPhoneLoginDto): Promise<{
        access_token: string;
        user: {
            id: number;
            phone: string | null;
            openId: string | null;
            username: string | null;
            email: string | null;
            nickname: string | null;
            avatarUrl: string | null;
            gender: "male" | "female" | "unknown";
            province: string | null;
            city: string | null;
            country: string | null;
            isPhoneAuthorized: boolean;
            isProfileAuthorized: boolean;
            status: "active" | "banned" | "deleted";
            registrationSource: "wechat_mini_program" | "web" | "admin";
            lastLoginAt: Date | null;
            lastLoginIp: string | null;
            loginCount: number;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
    wechatOpenIdLogin(dto: {
        openId: string;
        nickName?: string;
        avatarUrl?: string;
        gender?: number;
        province?: string;
        city?: string;
        country?: string;
    }): Promise<{
        access_token: string;
        user: {
            id: number;
            phone: string | null;
            openId: string | null;
            username: string | null;
            email: string | null;
            nickname: string | null;
            avatarUrl: string | null;
            gender: "male" | "female" | "unknown";
            province: string | null;
            city: string | null;
            country: string | null;
            isPhoneAuthorized: boolean;
            isProfileAuthorized: boolean;
            status: "active" | "banned" | "deleted";
            registrationSource: "wechat_mini_program" | "web" | "admin";
            lastLoginAt: Date | null;
            lastLoginIp: string | null;
            loginCount: number;
            createdAt: Date;
            updatedAt: Date;
        };
    }>;
    wechatLoginWithCode(dto: {
        code: string;
    }): Promise<{
        openId: any;
        sessionKey: any;
    }>;
}
