"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.COLLECTION_SLUG_METADATA = exports.VALID_COLLECTION_SLUGS = exports.COLLECTION_SLUGS = void 0;
exports.COLLECTION_SLUGS = {
    PREMIUM_CLOTHING: 'premium-clothing',
    PREMIUM_JEWELRY: 'premium-jewelry',
    RECOMMENDED_PRODUCTS: 'recommended-products',
    GUESS_YOU_LIKE: 'guess-you-like',
};
exports.VALID_COLLECTION_SLUGS = Object.values(exports.COLLECTION_SLUGS);
exports.COLLECTION_SLUG_METADATA = {
    [exports.COLLECTION_SLUGS.PREMIUM_CLOTHING]: {
        label: '精品服饰',
        description: '显示在首页精品服饰区域',
    },
    [exports.COLLECTION_SLUGS.PREMIUM_JEWELRY]: {
        label: '精品珠宝',
        description: '显示在首页精品珠宝区域',
    },
    [exports.COLLECTION_SLUGS.RECOMMENDED_PRODUCTS]: {
        label: '推荐商品',
        description: '显示在首页推荐商品区域',
    },
    [exports.COLLECTION_SLUGS.GUESS_YOU_LIKE]: {
        label: '猜你喜欢',
        description: '显示在首页猜你喜欢区域',
    },
};
//# sourceMappingURL=collection-slugs.js.map