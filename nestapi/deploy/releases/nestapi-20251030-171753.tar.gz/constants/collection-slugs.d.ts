export declare const COLLECTION_SLUGS: {
    readonly PREMIUM_CLOTHING: "premium-clothing";
    readonly PREMIUM_JEWELRY: "premium-jewelry";
    readonly RECOMMENDED_PRODUCTS: "recommended-products";
    readonly GUESS_YOU_LIKE: "guess-you-like";
};
export declare const VALID_COLLECTION_SLUGS: ("premium-clothing" | "premium-jewelry" | "recommended-products" | "guess-you-like")[];
export declare const COLLECTION_SLUG_METADATA: {
    readonly "premium-clothing": {
        readonly label: "精品服饰";
        readonly description: "显示在首页精品服饰区域";
    };
    readonly "premium-jewelry": {
        readonly label: "精品珠宝";
        readonly description: "显示在首页精品珠宝区域";
    };
    readonly "recommended-products": {
        readonly label: "推荐商品";
        readonly description: "显示在首页推荐商品区域";
    };
    readonly "guess-you-like": {
        readonly label: "猜你喜欢";
        readonly description: "显示在首页猜你喜欢区域";
    };
};
